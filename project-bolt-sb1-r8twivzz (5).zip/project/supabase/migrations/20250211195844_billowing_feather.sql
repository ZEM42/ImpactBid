/*
  # AI Training Data Schema

  1. New Tables
    - `ai_training_data`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `business_description` (text)
      - `common_services` (jsonb)
      - `suggest_pricing` (boolean)
      - `pricing_notes` (text)
      - `scope_templates` (jsonb)
      - `images` (jsonb)
      - `past_bids` (jsonb)
      - `bid_history` (jsonb)
      - `common_patterns` (jsonb)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - `last_synced` (timestamptz)

  2. Security
    - Enable RLS on `ai_training_data` table
    - Add policies for authenticated users to manage their own data
*/

-- Create AI training data table
CREATE TABLE IF NOT EXISTS ai_training_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  business_description text,
  common_services jsonb DEFAULT '[]'::jsonb,
  suggest_pricing boolean DEFAULT false,
  pricing_notes text,
  scope_templates jsonb DEFAULT '[]'::jsonb,
  images jsonb DEFAULT '[]'::jsonb,
  past_bids jsonb DEFAULT '[]'::jsonb,
  bid_history jsonb DEFAULT '[]'::jsonb,
  common_patterns jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  last_synced timestamptz DEFAULT now(),
  CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES auth.users (id) ON DELETE CASCADE
);

-- Enable RLS
ALTER TABLE ai_training_data ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own training data"
  ON ai_training_data
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own training data"
  ON ai_training_data
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own training data"
  ON ai_training_data
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own training data"
  ON ai_training_data
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_ai_training_data_user_id ON ai_training_data(user_id);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_ai_training_data_updated_at
  BEFORE UPDATE ON ai_training_data
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();