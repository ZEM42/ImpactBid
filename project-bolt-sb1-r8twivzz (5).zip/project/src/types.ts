// Add Supabase table types
export interface AITrainingDataRow {
  id: string;
  user_id: string;
  business_description: string;
  common_services: string[];
  suggest_pricing: boolean;
  pricing_notes: string;
  scope_templates: {
    id: string;
    name: string;
    description: string;
    common_tasks: string[];
    frequency?: number;
  }[];
  images: {
    id: string;
    url: string;
    description: string;
    category: 'completed';
  }[];
  past_bids: {
    id: string;
    url: string;
    description: string;
    type: 'file' | 'image';
    file_name?: string;
  }[];
  bid_history: {
    id: string;
    original_bid: Record<string, any>;
    modified_bid?: Record<string, any>;
    changes?: {
      type: 'scope_added' | 'scope_removed' | 'task_added' | 'task_removed' | 'price_changed';
      scope_id: string;
      task_id?: string;
      description: string;
    }[];
    timestamp: string;
  }[];
  common_patterns: {
    id: string;
    type: 'scope_combination' | 'task_dependency' | 'frequent_addition';
    description: string;
    frequency: number;
    last_seen: string;
    examples: string[];
  }[];
  created_at: string;
  updated_at: string;
  last_synced: string;
}

export interface AIConversationContext {
  identifiedType?: string;
  requiredScopes: Set<string>;
  missingInformation: Set<string>;
  suggestedQuestions: string[];
  commonPatternMatches: {
    patternId: string;
    confidence: number;
    reason: string;
  }[];
}

export interface AIMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  context?: AIConversationContext;
}

export interface AIConversation {
  id: string;
  messages: AIMessage[];
  context?: AIConversationContext;
  createdAt: Date;
}