export const sampleBid = {
  id: crypto.randomUUID(),
  clientName: "John & Sarah Thompson",
  clientAddress: "4521 Pine Valley Drive\nSpokane, WA 99223",
  projectDescription: "Complete basement finishing project including a family room, bedroom, bathroom, and small home office. Approximately 1,000 square feet of living space. Project includes all necessary electrical, plumbing, HVAC modifications, insulation, drywall, flooring, and finishes. The space will be transformed into a fully functional living area with high-quality materials and craftsmanship throughout.",
  lineItems: [
    {
      id: crypto.randomUUID(),
      scopeName: "Demolition and Preparation",
      tasks: [
        { id: crypto.randomUUID(), description: "Remove existing partial walls and old materials", price: 1200 },
        { id: crypto.randomUUID(), description: "Clean and prepare concrete floor", price: 800 },
        { id: crypto.randomUUID(), description: "Inspect for moisture issues and apply sealant if needed", price: 1500 },
        { id: crypto.randomUUID(), description: "Install moisture barrier system on concrete floor", price: 1200 },
        { id: crypto.randomUUID(), description: "Remove old electrical and plumbing fixtures", price: 600 }
      ],
      overridePrice: null,
      showPrices: true,
      showTaskPrices: true,
      images: [],
      showImages: false
    },
    {
      id: crypto.randomUUID(),
      scopeName: "Framing and Insulation",
      tasks: [
        { id: crypto.randomUUID(), description: "Frame exterior walls with 2x4 construction", price: 4200 },
        { id: crypto.randomUUID(), description: "Frame interior walls for bedroom, bathroom, and office", price: 3800 },
        { id: crypto.randomUUID(), description: "Install R-13 wall insulation and vapor barrier", price: 2800 },
        { id: crypto.randomUUID(), description: "Sound insulation for bathroom and office walls", price: 1200 },
        { id: crypto.randomUUID(), description: "Frame soffits for HVAC and plumbing runs", price: 1600 },
        { id: crypto.randomUUID(), description: "Install blocking for TV mount and cabinets", price: 800 },
        { id: crypto.randomUUID(), description: "Frame double door opening for office", price: 900 }
      ],
      overridePrice: null,
      showPrices: true,
      showTaskPrices: true,
      images: [],
      showImages: false
    },
    {
      id: crypto.randomUUID(),
      scopeName: "Electrical",
      tasks: [
        { id: crypto.randomUUID(), description: "Install new 100-amp sub-panel", price: 2200 },
        { id: crypto.randomUUID(), description: "Install LED recessed lighting throughout (18 fixtures)", price: 2800 },
        { id: crypto.randomUUID(), description: "Add outlets and switches per code requirements", price: 1900 },
        { id: crypto.randomUUID(), description: "Install ceiling fan rough-ins in bedroom and family room", price: 800 },
        { id: crypto.randomUUID(), description: "Add dedicated circuits for office equipment", price: 600 },
        { id: crypto.randomUUID(), description: "Install USB outlets in office and family room", price: 400 },
        { id: crypto.randomUUID(), description: "Add motion sensor switches in storage areas", price: 300 }
      ],
      overridePrice: null,
      showPrices: true,
      showTaskPrices: true,
      images: [],
      showImages: false
    }
  ],
  applyTax: true,
  createdAt: new Date(),
  hasPaymentPlan: true,
  payments: [
    {
      id: crypto.randomUUID(),
      label: "Deposit",
      percentage: 25,
      amount: null
    },
    {
      id: crypto.randomUUID(),
      label: "Payment 2",
      percentage: 25,
      amount: null
    },
    {
      id: crypto.randomUUID(),
      label: "Payment 3",
      percentage: 25,
      amount: null
    },
    {
      id: crypto.randomUUID(),
      label: "Final",
      percentage: 25,
      amount: null
    }
  ],
  additionalImages: [],
  showAdditionalImages: false,
  notes: '',
  contractId: null,
  showContract: true,
  showClientSignature: true,
  showMySignature: false
};