export const sampleInvoice = {
  id: crypto.randomUUID(),
  bidId: null,
  clientName: "John & Sarah Thompson",
  clientAddress: "4521 Pine Valley Drive\nSpokane, WA 99223",
  projectDescription: "Complete basement finishing project including a family room, bedroom, bathroom, and small home office.",
  lineItems: [
    {
      id: crypto.randomUUID(),
      scopeName: "Initial Payment",
      tasks: [
        { id: crypto.randomUUID(), description: "Project Deposit - 25% of total project cost", price: 12500 }
      ],
      overridePrice: null,
      showPrices: true,
      showTaskPrices: true,
      images: [],
      showImages: false
    }
  ],
  applyTax: true,
  createdAt: new Date(),
  status: 'sent',
  invoiceNumber: `INV-${new Date().getFullYear()}-0001`,
  notes: 'Please make payment within 30 days.',
  additionalImages: [],
  showAdditionalImages: false,
  hasPaymentPlan: true,
  payments: [
    {
      id: crypto.randomUUID(),
      label: "Initial Payment",
      percentage: 25,
      amount: 12500,
      status: 'due',
      includeDueDate: true,
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      paidDate: null
    }
  ]
};