export const sampleContract = {
  id: crypto.randomUUID(),
  title: "Standard Construction Agreement",
  content: `CONSTRUCTION AGREEMENT

This Construction Agreement ("Agreement") is made between ZEM Construction ("Contractor") and the Client identified in the accompanying bid document.

1. SCOPE OF WORK
The Contractor agrees to perform the work as detailed in the attached bid document ("Work"). The Work shall be performed in a good and workmanlike manner and in accordance with industry standards.

2. PAYMENT
Payment shall be made according to the schedule outlined in the bid document. Final payment shall be due upon completion of the Work and after final inspection by the Client.

3. CHANGES
Any alterations or deviations from the specifications involving extra costs will be executed only upon written change orders, and will become an extra charge over and above the estimate.

4. WARRANTIES
Contractor warrants that all Work will be performed in accordance with applicable building codes and industry standards. All materials and workmanship are warranted for one year from date of completion.

5. INSURANCE
Contractor shall maintain appropriate insurance coverage, including worker's compensation and general liability insurance.

6. PERMITS
Contractor shall obtain all necessary permits and licenses required for the Work. Associated costs are included in the bid price unless otherwise specified.

7. TERMINATION
Either party may terminate this Agreement for cause upon written notice if the other party fails to perform its obligations. In such event, the Contractor shall be paid for Work completed to date.

8. DISPUTE RESOLUTION
Any disputes arising from this Agreement shall first be subject to mediation before pursuing other legal remedies.

9. GOVERNING LAW
This Agreement shall be governed by and construed in accordance with the laws of Washington State.

10. ENTIRE AGREEMENT
This Agreement, together with the attached bid document, constitutes the entire agreement between the parties and supersedes all prior negotiations and agreements.`,
  createdAt: new Date()
};