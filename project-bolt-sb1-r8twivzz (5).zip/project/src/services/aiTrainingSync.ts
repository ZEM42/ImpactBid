import { createClient } from '@supabase/supabase-js';
import type { AITrainingData, AITrainingDataRow } from '../types';

export class AITrainingSync {
  private supabase;
  private userId: string;

  constructor(supabaseUrl: string, supabaseKey: string, userId: string) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.userId = userId;
  }

  private convertToRow(data: AITrainingData): Omit<AITrainingDataRow, 'id' | 'user_id'> {
    return {
      business_description: data.businessDescription,
      common_services: data.commonServices,
      suggest_pricing: data.suggestPricing,
      pricing_notes: data.pricingNotes,
      scope_templates: data.scopeTemplates,
      images: data.images,
      past_bids: data.pastBids,
      bid_history: data.bidHistory.map(h => ({
        ...h,
        timestamp: h.timestamp.toISOString(),
        original_bid: h.originalBid,
        modified_bid: h.modifiedBid
      })),
      common_patterns: data.commonPatterns.map(p => ({
        ...p,
        last_seen: p.lastSeen.toISOString()
      })),
      created_at: data.createdAt.toISOString(),
      updated_at: data.updatedAt.toISOString(),
      last_synced: new Date().toISOString()
    };
  }

  private convertFromRow(row: AITrainingDataRow): AITrainingData {
    return {
      id: row.id,
      businessDescription: row.business_description,
      commonServices: row.common_services,
      suggestPricing: row.suggest_pricing,
      pricingNotes: row.pricing_notes,
      scopeTemplates: row.scope_templates,
      images: row.images,
      pastBids: row.past_bids,
      bidHistory: row.bid_history.map(h => ({
        ...h,
        timestamp: new Date(h.timestamp),
        originalBid: h.original_bid,
        modifiedBid: h.modified_bid
      })),
      commonPatterns: row.common_patterns.map(p => ({
        ...p,
        lastSeen: new Date(p.last_seen)
      })),
      createdAt: new Date(row.created_at),
      updatedAt: new Date(row.updated_at)
    };
  }

  async sync(localData: AITrainingData): Promise<AITrainingData> {
    try {
      // Get remote data
      const { data: remoteData, error } = await this.supabase
        .from('ai_training_data')
        .select('*')
        .eq('user_id', this.userId)
        .single();

      if (error && error.code !== 'PGRST116') { // PGRST116 is "not found"
        throw error;
      }

      if (!remoteData) {
        // First sync - create remote data
        const { data: newData, error: insertError } = await this.supabase
          .from('ai_training_data')
          .insert({
            user_id: this.userId,
            ...this.convertToRow(localData)
          })
          .select()
          .single();

        if (insertError) throw insertError;
        return this.convertFromRow(newData);
      }

      // Merge local and remote data
      const mergedData = this.mergeData(localData, this.convertFromRow(remoteData));

      // Update remote data
      const { data: updatedData, error: updateError } = await this.supabase
        .from('ai_training_data')
        .update(this.convertToRow(mergedData))
        .eq('id', remoteData.id)
        .select()
        .single();

      if (updateError) throw updateError;
      return this.convertFromRow(updatedData);

    } catch (error) {
      console.error('Sync error:', error);
      return localData; // Return local data if sync fails
    }
  }

  private mergeData(local: AITrainingData, remote: AITrainingData): AITrainingData {
    // Merge based on timestamps
    const isLocalNewer = local.updatedAt > remote.updatedAt;

    return {
      ...remote,
      ...local,
      // Merge arrays and objects
      commonServices: [...new Set([...remote.commonServices, ...local.commonServices])],
      scopeTemplates: this.mergeScopeTemplates(
        isLocalNewer ? local.scopeTemplates : remote.scopeTemplates,
        isLocalNewer ? remote.scopeTemplates : local.scopeTemplates
      ),
      bidHistory: this.mergeBidHistory(local.bidHistory, remote.bidHistory),
      commonPatterns: this.mergeCommonPatterns(local.commonPatterns, remote.commonPatterns),
      // Keep newer timestamps
      updatedAt: new Date(Math.max(local.updatedAt.getTime(), remote.updatedAt.getTime()))
    };
  }

  private mergeScopeTemplates(primary: AITrainingData['scopeTemplates'], secondary: AITrainingData['scopeTemplates']) {
    const merged = [...primary];
    
    secondary.forEach(secondaryScope => {
      const existingIndex = merged.findIndex(p => p.id === secondaryScope.id);
      if (existingIndex === -1) {
        merged.push(secondaryScope);
      } else {
        // Merge tasks
        merged[existingIndex].commonTasks = [
          ...new Set([...merged[existingIndex].commonTasks, ...secondaryScope.commonTasks])
        ];
        // Take higher frequency
        merged[existingIndex].frequency = Math.max(
          merged[existingIndex].frequency || 0,
          secondaryScope.frequency || 0
        );
      }
    });

    return merged;
  }

  private mergeBidHistory(local: AITrainingData['bidHistory'], remote: AITrainingData['bidHistory']): AITrainingData['bidHistory'] {
    const mergedMap = new Map();
    
    [...local, ...remote].forEach(bid => {
      const existing = mergedMap.get(bid.id);
      if (!existing || new Date(bid.timestamp) > new Date(existing.timestamp)) {
        mergedMap.set(bid.id, bid);
      }
    });

    return Array.from(mergedMap.values());
  }

  private mergeCommonPatterns(local: AITrainingData['commonPatterns'], remote: AITrainingData['commonPatterns']): AITrainingData['commonPatterns'] {
    const merged = new Map();

    [...local, ...remote].forEach(pattern => {
      const existing = merged.get(pattern.id);
      if (existing) {
        merged.set(pattern.id, {
          ...pattern,
          frequency: Math.max(pattern.frequency, existing.frequency),
          examples: [...new Set([...pattern.examples, ...existing.examples])],
          lastSeen: new Date(Math.max(
            new Date(pattern.lastSeen).getTime(),
            new Date(existing.lastSeen).getTime()
          ))
        });
      } else {
        merged.set(pattern.id, pattern);
      }
    });

    return Array.from(merged.values());
  }
}