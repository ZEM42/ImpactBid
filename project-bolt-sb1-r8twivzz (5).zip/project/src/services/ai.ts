import { AITrainingSync } from './aiTrainingSync';
import type { Profile, AITrainingData, Bid, AIConversation, AIMessage, AIConversationContext } from '../types';

interface OpenAIResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

interface AIResponse {
  role: 'assistant';
  content: string;
  bid?: Partial<Bid>;
  context?: AIConversationContext;
}

export class AIService {
  private apiKey: string;
  private profile: Profile;
  private systemPrompt: string;
  private bidGenerationPrompt: string;
  private trainingSync?: AITrainingSync;
  private conversationContext: AIConversationContext = {
    requiredScopes: new Set(),
    missingInformation: new Set(),
    suggestedQuestions: [],
    commonPatternMatches: []
  };

  constructor(apiKey: string | undefined, profile: Profile) {
    if (!apiKey) {
      throw new Error('OpenAI API key is required. Please check your environment variables.');
    }
    
    // Validate API key format
    if (!apiKey.startsWith('sk-') || apiKey.length < 20) {
      throw new Error('Invalid OpenAI API key format. Please check your configuration.');
    }

    this.apiKey = apiKey;
    this.profile = profile;
    this.bidGenerationPrompt = this.generateBidPrompt();
    this.systemPrompt = this.generateSystemPrompt(profile);
  }

  async sendMessage(conversation: AIConversation, message: string): Promise<AIResponse> {
    if (!message.trim()) {
      throw new Error('Message cannot be empty');
    }

    try {
      // Update context based on the new message
      this.updateContext(message, this.profile.aiTrainingData);

      const messages = [
        ...conversation.messages.map(msg => ({
          role: msg.role,
          content: msg.content
        })),
        { role: 'user', content: message }
      ];

      // Add relevant patterns to the conversation
      if (this.conversationContext.commonPatternMatches.length > 0) {
        messages.push({
          role: 'system',
          content: `Consider these patterns:\n${
            this.conversationContext.commonPatternMatches
              .map(m => `- ${m.reason}`)
              .join('\n')
          }`
        });
      }

      const response = await this.makeRequest(messages);

      // Check if we have enough information to generate a bid
      const canGenerateBid = this.canGenerateBid(message, conversation.messages);
      if (canGenerateBid) {
        try {
          const bidData = await this.extractBidData(response.content);
          if (bidData) {
            response.bid = bidData;
          }
        } catch (error) {
          console.error('Failed to extract bid data:', error);
        }
      }

      return response;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      console.error('AI Service Error:', { message: errorMessage });
      throw new Error(`Failed to process message: ${errorMessage}`);
    }
  }

  private canGenerateBid(message: string, messages: AIMessage[]): boolean {
    // Check if we have project description
    const hasProjectDescription = messages.some(msg => 
      msg.content.toLowerCase().includes('project') || 
      msg.content.toLowerCase().includes('scope')
    );

    // Check if the current message indicates completion
    const completionIndicators = [
      'that sounds good',
      'looks good',
      'perfect',
      'great',
      'yes',
      'correct',
      'exactly',
      'that\'s right',
      'that is correct',
      'generate',
      'create bid'
    ];

    const isConfirmation = completionIndicators.some(indicator => 
      message.toLowerCase().includes(indicator)
    );

    // Check if we have enough details
    const hasEnoughDetails = messages.length >= 3;

    return hasProjectDescription && isConfirmation && hasEnoughDetails;
  }

  private async makeRequest(messages: { role: string; content: string }[]): Promise<AIResponse> {
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            { role: 'system', content: this.systemPrompt },
            ...messages,
            // Add explicit instruction to format response as JSON
            { role: 'system', content: 'Please format your response as valid JSON wrapped in ```json``` code blocks.' }
          ],
          temperature: 0.7,
          max_tokens: 2000
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        throw new Error(
          errorData?.error?.message || 
          `API request failed with status ${response.status}`
        );
      }

      const data = await response.json() as OpenAIResponse;
      
      if (!data.choices?.[0]?.message?.content) {
        throw new Error('Invalid response format from API');
      }

      return {
        role: 'assistant',
        content: data.choices[0].message.content,
        context: this.conversationContext
      };
    } catch (error) {
      if (error instanceof Error) {
        // Handle specific error cases
        if (error.message.includes('Failed to fetch')) {
          throw new Error('Network error. Please check your internet connection.');
        }
        if (error.message.includes('401')) {
          throw new Error('Invalid API key. Please check your OpenAI API key configuration.');
        }
        if (error.message.includes('429')) {
          throw new Error('Rate limit exceeded. Please try again in a few moments.');
        }
        throw error;
      }
      throw new Error('An unexpected error occurred');
    }
  }

  private generateSystemPrompt(profile: Profile): string {
    const trainingData = profile.aiTrainingData;
    const basePrompt = `You are an AI assistant for ${profile.businessName}, a construction company. Your role is to help create detailed construction bids based on client requirements.

CRITICAL REQUIREMENTS:
1. NEVER combine separate scopes unless they were combined in past bids
2. ALWAYS maintain exact scope names and structures from past bids
3. Ask for missing REQUIRED information only (client name and project description)
4. NEVER ask for optional information unless the user mentions it
5. ALWAYS follow the exact format of previous bids
6. If client name or address is not provided, exclude them from the bid

CONVERSATION STRATEGY:
1. Focus on understanding the project requirements first
2. Only ask for client name if not provided and ready to generate bid
3. Keep optional details optional (address, timeline, etc)
4. Match project details with similar past bids
5. Allow iterative refinements to generated bids

REQUIRED INFORMATION:
- Project description/requirements
- Client name (only when ready to generate bid)

OPTIONAL INFORMATION (don't ask unless mentioned):
- Client address
- Timeline
- Material preferences
- Budget
- Special requirements

Your responses must be in natural language only. No code blocks or JSON in chat messages.`;

    if (!trainingData) return basePrompt;

    let prompt = `${basePrompt}

BUSINESS PROFILE:
${trainingData.businessDescription}

STANDARD SCOPE STRUCTURE:
${trainingData.scopeTemplates?.map(scope => `
${scope.name}:
- Description: ${scope.description}
- Common Tasks:
${scope.commonTasks.map(task => `  • ${task}`).join('\n')}`).join('\n')}

COMMON PATTERNS TO CHECK:
${trainingData.commonPatterns?.map(pattern => `
${pattern.type.toUpperCase()}:
- Pattern: ${pattern.description}
- Frequency: ${pattern.frequency} occurrences
- Examples: ${pattern.examples.join(', ')}`).join('\n')}

LEARNING PRIORITIES:
1. Track commonly paired scopes
2. Note frequently added items
3. Learn from price adjustments
4. Identify project-specific patterns
5. Remember user preferences

BID GENERATION RULES:
1. NEVER merge separate scopes
2. Use EXACT terminology from past bids
3. Maintain consistent pricing structure
4. Follow established task groupings
5. Include commonly forgotten items`;

    return prompt;
  }

  private generateBidPrompt(): string {
    return `Based on our conversation and historical patterns, generate a complete bid that EXACTLY matches our company's established format. The bid must:

1. Use EXACT scope names from past bids
2. Maintain separate scopes (never combine unless historically combined)
3. Follow established pricing structures
4. Include commonly paired items based on history
5. Match task groupings from similar past bids
6. Exclude client name/address if not provided

Format the bid data as JSON wrapped in code blocks. Include only information that was explicitly discussed or can be confidently inferred from historical patterns.

Example format:
\`\`\`json
{
  "clientName": "John Smith",
  "projectDescription": "Complete bathroom remodel...",
  "lineItems": [
    {
      "scopeName": "Demolition",
      "tasks": [
        {
          "description": "Remove existing fixtures",
          "price": 800
        }
      ],
      "showPrices": true,
      "showTaskPrices": true
    }
  ],
  "applyTax": true,
  "hasPaymentPlan": true,
  "payments": [
    {
      "label": "Deposit",
      "percentage": 25
    }
  ]
}
\`\`\``;
  }

  private extractBidData(content: string): Promise<Partial<Bid> | undefined> {
    return new Promise((resolve, reject) => {
      try {
        // Look for JSON block in the content
        const jsonMatch = content.match(/```json\n([\s\S]*?)\n```/);
        if (!jsonMatch) {
          console.warn('No JSON block found in response');
          reject(new Error('Failed to find bid data in response'));
          return;
        }

        let bidData: any;
        try {
          bidData = JSON.parse(jsonMatch[1]);
        } catch (parseError) {
          console.error('JSON parse error:', parseError);
          reject(new Error('Failed to parse bid data'));
          return;
        }
        
        // Validate required fields
        if (!bidData.projectDescription || !bidData.lineItems || !Array.isArray(bidData.lineItems)) {
          console.warn('Missing required bid data fields');
          reject(new Error('Invalid bid data structure'));
          return;
        }

        // Validate and clean up line items
        bidData.lineItems = bidData.lineItems.map((item: any) => ({
          ...item,
          id: crypto.randomUUID(),
          tasks: (item.tasks || []).map((task: any) => ({
            id: crypto.randomUUID(),
            description: task.description,
            price: typeof task.price === 'number' ? task.price : null
          })),
          overridePrice: null,
          showPrices: true,
          showTaskPrices: true,
          images: [],
          showImages: false
        }));

        // Ensure payments are properly structured
        if (bidData.hasPaymentPlan && (!bidData.payments || !Array.isArray(bidData.payments))) {
          bidData.payments = [
            {
              id: crypto.randomUUID(),
              label: 'Deposit',
              percentage: 25,
              amount: null
            }
          ];
        } else if (bidData.payments) {
          bidData.payments = bidData.payments.map((payment: any) => ({
            id: crypto.randomUUID(),
            label: payment.label || 'Payment',
            percentage: payment.percentage || null,
            amount: payment.amount || null
          }));
        }

        resolve(bidData);
      } catch (error) {
        console.error('Error extracting bid data:', error);
        reject(new Error('Failed to process bid data'));
      }
    });
  }

  async generateBid(conversation: AIConversation): Promise<Bid> {
    if (conversation.messages.length === 0) {
      throw new Error('Cannot generate bid without any conversation history');
    }

    try {
      const response = await this.makeRequest([
        ...conversation.messages.map(msg => ({
          role: msg.role,
          content: msg.content
        })),
        {
          role: 'user',
          content: this.bidGenerationPrompt
        }
      ]);

      const bidData = await this.extractBidData(response.content);
      if (!bidData) {
        throw new Error('Failed to generate valid bid data');
      }

      return {
        id: crypto.randomUUID(),
        createdAt: new Date(),
        clientName: bidData.clientName || '',
        clientAddress: bidData.clientAddress || '',
        projectDescription: bidData.projectDescription || '',
        lineItems: bidData.lineItems || [],
        applyTax: bidData.applyTax ?? true,
        hasPaymentPlan: bidData.hasPaymentPlan ?? true,
        payments: bidData.payments || [],
        additionalImages: [],
        showAdditionalImages: false,
        notes: bidData.notes || '',
        contractId: this.profile.contracts[0]?.id || null,
        showContract: true,
        showClientSignature: true,
        showMySignature: false,
        ...bidData
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to generate bid';
      console.error('Error generating bid:', errorMessage);
      throw new Error(errorMessage);
    }
  }

  private updateContext(message: string, trainingData?: AITrainingData) {
    if (!trainingData) return;

    // Reset missing information tracking
    this.conversationContext.missingInformation.clear();
    this.conversationContext.suggestedQuestions = [];

    // Check for required information
    if (!message.toLowerCase().includes('project') && !message.toLowerCase().includes('scope')) {
      this.conversationContext.missingInformation.add('projectDescription');
    }

    // Identify project type and required scopes
    const projectTypes = new Set(trainingData.commonPatterns
      ?.filter(p => p.type === 'scope_combination')
      .map(p => p.description.toLowerCase()));

    for (const type of projectTypes) {
      if (message.toLowerCase().includes(type)) {
        this.conversationContext.identifiedType = type;
        break;
      }
    }

    // Match scopes from training data
    if (this.conversationContext.identifiedType) {
      const relevantPatterns = trainingData.commonPatterns
        ?.filter(p => p.description.toLowerCase().includes(this.conversationContext.identifiedType!));

      relevantPatterns?.forEach(pattern => {
        pattern.examples.forEach(example => {
          const matchingScope = trainingData.scopeTemplates
            .find(s => s.name.toLowerCase().includes(example.toLowerCase()));
          if (matchingScope) {
            this.conversationContext.requiredScopes.add(matchingScope.id);
          }
        });
      });
    }

    // Generate next question based on missing information
    if (this.conversationContext.missingInformation.size > 0) {
      const nextQuestion = this.generateNextQuestion();
      if (nextQuestion) {
        this.conversationContext.suggestedQuestions = [nextQuestion];
      }
    }

    // Match common patterns
    this.conversationContext.commonPatternMatches = trainingData.commonPatterns
      ?.filter(pattern => {
        const matchesExample = pattern.examples.some(ex => 
          message.toLowerCase().includes(ex.toLowerCase())
        );
        return matchesExample && pattern.frequency > 2;
      })
      .map(pattern => ({
        patternId: pattern.id,
        confidence: pattern.frequency / (trainingData.bidHistory?.length || 1),
        reason: `This appears in ${pattern.frequency} similar projects`
      })) || [];
  }

  private generateNextQuestion(): string | null {
    if (this.conversationContext.missingInformation.size === 0) return null;

    const questions: { [key: string]: string } = {
      projectDescription: "Could you describe the project requirements in detail?"
    };

    for (const [key, question] of Object.entries(questions)) {
      if (this.conversationContext.missingInformation.has(key)) {
        return question;
      }
    }

    return null;
  }

  async learnFromBidModification(originalBid: Bid, modifiedBid: Bid) {
    if (!this.profile.aiTrainingData) return;

    const changes: NonNullable<AITrainingData['bidHistory'][0]['changes']> = [];

    // Compare scopes
    const originalScopeIds = new Set(originalBid.lineItems.map(item => item.id));
    const modifiedScopeIds = new Set(modifiedBid.lineItems.map(item => item.id));

    // Track scope combinations
    const combinedScopes = new Set<string>();

    // Find added and removed scopes
    for (const scope of modifiedBid.lineItems) {
      if (!originalScopeIds.has(scope.id)) {
        changes.push({
          type: 'scope_added',
          scopeId: scope.id,
          description: `Added scope: ${scope.scopeName}`
        });

        // Check for scope combinations
        const relatedScopes = originalBid.lineItems
          .filter(s => s.scopeName.toLowerCase().includes(scope.scopeName.toLowerCase()) ||
                      scope.scopeName.toLowerCase().includes(s.scopeName.toLowerCase()));
        
        relatedScopes.forEach(related => {
          combinedScopes.add(`${related.scopeName} + ${scope.scopeName}`);
        });
      }
    }

    // Update common patterns with scope combinations
    if (combinedScopes.size > 0) {
      this.profile.aiTrainingData.commonPatterns = [
        ...(this.profile.aiTrainingData.commonPatterns || []),
        ...Array.from(combinedScopes).map(combination => ({
          id: crypto.randomUUID(),
          type: 'scope_combination',
          description: `Common scope combination: ${combination}`,
          frequency: 1,
          lastSeen: new Date(),
          examples: combination.split(' + ')
        }))
      ];
    }

    // Update bid history
    this.profile.aiTrainingData.bidHistory = [
      ...(this.profile.aiTrainingData.bidHistory || []),
        {
          id: crypto.randomUUID(),
          originalBid,
          modifiedBid,
          changes,
          timestamp: new Date()
        }
    ];

    // Sync training data
    await this.syncTrainingData();
  }

  private async syncTrainingData() {
    if (!this.trainingSync || !this.profile.aiTrainingData) return;

    try {
      const synced = await this.trainingSync.sync(this.profile.aiTrainingData);
      this.profile.aiTrainingData = synced;
    } catch (error) {
      console.error('Failed to sync training data:', error);
    }
  }
}