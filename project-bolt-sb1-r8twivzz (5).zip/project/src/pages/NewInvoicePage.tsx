import React from 'react';
import { useNavigate } from 'react-router-dom';
import { InvoiceForm } from '../components/InvoiceForm';
import type { Profile, Invoice } from '../types';

interface NewInvoicePageProps {
  profile: Profile;
  onSave: (invoice: Invoice) => void;
}

export function NewInvoicePage({ profile, onSave }: NewInvoicePageProps) {
  const navigate = useNavigate();

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Create New Invoice</h1>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <InvoiceForm 
          profile={profile} 
          onSave={(invoice) => {
            onSave(invoice);
            navigate(`/invoices/${invoice.id}/preview`);
          }}
        />
      </div>
    </div>
  );
}