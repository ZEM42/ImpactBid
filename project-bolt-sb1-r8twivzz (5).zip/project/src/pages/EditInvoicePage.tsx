import React from 'react';
import { useNavigate, useParams, Navigate } from 'react-router-dom';
import { InvoiceForm } from '../components/InvoiceForm';
import type { Profile, Invoice } from '../types';

interface EditInvoicePageProps {
  profile: Profile;
  invoices: Invoice[];
  onSave: (invoice: Invoice) => void;
}

export function EditInvoicePage({ profile, invoices, onSave }: EditInvoicePageProps) {
  const navigate = useNavigate();
  const { invoiceId } = useParams();
  const currentInvoice = invoices.find(i => i.id === invoiceId);

  if (!currentInvoice) {
    return <Navigate to="/invoices" replace />;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Edit Invoice</h1>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <InvoiceForm 
          profile={profile} 
          onSave={(invoice) => {
            onSave(invoice);
            navigate(`/invoices/${invoice.id}/preview`);
          }}
          existingInvoice={currentInvoice}
        />
      </div>
    </div>
  );
}