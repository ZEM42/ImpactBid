import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Upload, Trash2, FileText, Save, PlusCircle } from 'lucide-react';
import type { Profile, AITrainingData } from '../types';

interface AITrainingPageProps {
  profile: Profile;
  onSave: (profile: Profile) => void;
}

export function AITrainingPage({ profile, onSave }: AITrainingPageProps) {
  const navigate = useNavigate();
  const [trainingData, setTrainingData] = useState<AITrainingData>(
    profile.aiTrainingData || {
      id: crypto.randomUUID(),
      businessDescription: profile.businessName ? 
        `${profile.businessName} is a licensed construction company (License #${profile.licenseNumber}) based in ${profile.businessAddress.split('\n')[0]}.` : '',
      commonServices: [],
      suggestPricing: false,
      pricingNotes: '',
      scopeTemplates: [],
      images: [],
      pastBids: [],
      createdAt: new Date(),
      updatedAt: new Date()
    }
  );

  const handleSave = () => {
    onSave({
      ...profile,
      aiTrainingData: {
        ...trainingData,
        updatedAt: new Date()
      }
    });
    navigate('/profile');
  };

  const handleAddService = (service: string) => {
    if (!service.trim()) return;
    setTrainingData(prev => ({
      ...prev,
      commonServices: [...prev.commonServices, service.trim()]
    }));
  };

  const handleRemoveService = (index: number) => {
    setTrainingData(prev => ({
      ...prev,
      commonServices: prev.commonServices.filter((_, i) => i !== index)
    }));
  };

  const handleAddScopeTemplate = () => {
    setTrainingData(prev => ({
      ...prev,
      scopeTemplates: [
        ...prev.scopeTemplates,
        {
          id: crypto.randomUUID(),
          name: '',
          description: '',
          commonTasks: []
        }
      ]
    }));
  };

  const handleRemoveScopeTemplate = (id: string) => {
    setTrainingData(prev => ({
      ...prev,
      scopeTemplates: prev.scopeTemplates.filter(scope => scope.id !== id)
    }));
  };

  const handleAddTaskToScope = (scopeId: string, task: string) => {
    if (!task.trim()) return;
    setTrainingData(prev => ({
      ...prev,
      scopeTemplates: prev.scopeTemplates.map(scope =>
        scope.id === scopeId
          ? { ...scope, commonTasks: [...scope.commonTasks, task.trim()] }
          : scope
      )
    }));
  };

  const handleRemoveTaskFromScope = (scopeId: string, taskIndex: number) => {
    setTrainingData(prev => ({
      ...prev,
      scopeTemplates: prev.scopeTemplates.map(scope =>
        scope.id === scopeId
          ? { ...scope, commonTasks: scope.commonTasks.filter((_, i) => i !== taskIndex) }
          : scope
      )
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => navigate('/profile')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-gray-900">Train AI Assistant</h1>
            <p className="text-sm text-gray-600 mt-1">
              Help the AI understand your business better
            </p>
          </div>
          <button
            onClick={handleSave}
            className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Changes
          </button>
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Business Description</h2>
            <textarea
              value={trainingData.businessDescription}
              onChange={(e) => setTrainingData(prev => ({
                ...prev,
                businessDescription: e.target.value
              }))}
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              rows={4}
              placeholder="Describe your business, experience, and typical projects..."
            />
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Common Services</h2>
            <div className="space-y-4">
              <div className="flex gap-4">
                <input
                  type="text"
                  placeholder="Add a service..."
                  className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddService((e.target as HTMLInputElement).value);
                      (e.target as HTMLInputElement).value = '';
                    }
                  }}
                />
                <button
                  onClick={() => {
                    const input = document.querySelector('input[placeholder="Add a service..."]') as HTMLInputElement;
                    handleAddService(input.value);
                    input.value = '';
                  }}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Add
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {trainingData.commonServices.map((service, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800"
                  >
                    {service}
                    <button
                      onClick={() => handleRemoveService(index)}
                      className="ml-2 text-blue-600 hover:text-blue-800"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-medium text-gray-900">Scope Templates</h2>
              <button
                onClick={handleAddScopeTemplate}
                className="flex items-center px-3 py-2 text-sm font-medium text-blue-900 hover:text-blue-800"
              >
                <PlusCircle className="w-4 h-4 mr-2" />
                Add Scope Template
              </button>
            </div>
            
            <div className="space-y-6">
              {trainingData.scopeTemplates.map(scope => (
                <div key={scope.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1 space-y-4">
                      <input
                        type="text"
                        value={scope.name}
                        onChange={(e) => setTrainingData(prev => ({
                          ...prev,
                          scopeTemplates: prev.scopeTemplates.map(s =>
                            s.id === scope.id ? { ...s, name: e.target.value } : s
                          )
                        }))}
                        placeholder="Scope name (e.g., Demolition, Framing, Electrical)"
                        className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      />
                      <textarea
                        value={scope.description}
                        onChange={(e) => setTrainingData(prev => ({
                          ...prev,
                          scopeTemplates: prev.scopeTemplates.map(s =>
                            s.id === scope.id ? { ...s, description: e.target.value } : s
                          )
                        }))}
                        placeholder="Describe this scope of work..."
                        className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        rows={2}
                      />
                    </div>
                    <button
                      onClick={() => handleRemoveScopeTemplate(scope.id)}
                      className="ml-4 p-1 text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="space-y-4">
                    <div className="flex gap-4">
                      <input
                        type="text"
                        placeholder="Add common task for this scope..."
                        className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddTaskToScope(scope.id, (e.target as HTMLInputElement).value);
                            (e.target as HTMLInputElement).value = '';
                          }
                        }}
                      />
                      <button
                        onClick={() => {
                          const input = e.target.parentElement?.querySelector('input') as HTMLInputElement;
                          handleAddTaskToScope(scope.id, input.value);
                          input.value = '';
                        }}
                        className="px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                      >
                        Add Task
                      </button>
                    </div>
                    <div className="space-y-2">
                      {scope.commonTasks.map((task, index) => (
                        <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                          <span className="text-sm text-gray-700">{task}</span>
                          <button
                            onClick={() => handleRemoveTaskFromScope(scope.id, index)}
                            className="text-gray-400 hover:text-red-600"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium text-gray-900">Pricing Information</h2>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  className="sr-only peer"
                  checked={trainingData.suggestPricing}
                  onChange={(e) => setTrainingData(prev => ({
                    ...prev,
                    suggestPricing: e.target.checked
                  }))}
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-900"></div>
                <span className="ml-3 text-sm font-medium text-gray-700">
                  Allow AI to suggest pricing
                </span>
              </label>
            </div>
            {trainingData.suggestPricing && (
              <textarea
                value={trainingData.pricingNotes}
                onChange={(e) => setTrainingData(prev => ({
                  ...prev,
                  pricingNotes: e.target.value
                }))}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                rows={4}
                placeholder="Add notes about your typical pricing, rates, or any other pricing guidelines..."
              />
            )}
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Past Bids</h2>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Upload past bids to help train the AI (PDF, images, or documents)
              </label>
              <div className="flex items-center justify-center w-full">
                <label className="w-full flex flex-col items-center px-4 py-6 bg-white text-blue rounded-lg shadow-lg tracking-wide uppercase border border-blue cursor-pointer hover:bg-blue-50">
                  <Upload className="w-8 h-8 text-blue-900" />
                  <span className="mt-2 text-base leading-normal">Select files</span>
                  <input
                    type="file"
                    className="hidden"
                    accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                    multiple
                    onChange={(e) => {
                      const files = Array.from(e.target.files || []);
                      
                      files.forEach(file => {
                        const reader = new FileReader();
                        reader.onload = (event) => {
                          if (event.target?.result) {
                            const isImage = file.type.startsWith('image/');
                            setTrainingData(prev => ({
                              ...prev,
                              pastBids: [
                                ...prev.pastBids,
                                {
                                  id: crypto.randomUUID(),
                                  url: event.target!.result as string,
                                  description: '',
                                  type: isImage ? 'image' : 'file',
                                  fileName: file.name
                                }
                              ]
                            }));
                          }
                        };
                        reader.readAsDataURL(file);
                      });
                    }}
                  />
                </label>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {trainingData.pastBids.map((bid, index) => (
                <div key={bid.id} className="relative group">
                  {bid.type === 'image' ? (
                    <img
                      src={bid.url}
                      alt={bid.description}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                  ) : (
                    <div className="w-full h-48 bg-gray-100 rounded-lg flex flex-col items-center justify-center">
                      <FileText className="w-12 h-12 text-gray-400" />
                      <span className="mt-2 text-sm text-gray-600">{bid.fileName}</span>
                    </div>
                  )}
                  <textarea
                    value={bid.description}
                    onChange={(e) => setTrainingData(prev => ({
                      ...prev,
                      pastBids: prev.pastBids.map((b, i) =>
                        i === index ? { ...b, description: e.target.value } : b
                      )
                    }))}
                    className="mt-2 w-full text-sm border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder="Describe this bid..."
                    rows={2}
                  />
                  <button
                    onClick={() => setTrainingData(prev => ({
                      ...prev,
                      pastBids: prev.pastBids.filter((_, i) => i !== index)
                    }))}
                    className="absolute top-2 right-2 p-1 bg-red-100 rounded-full text-red-600 hover:bg-red-200"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}