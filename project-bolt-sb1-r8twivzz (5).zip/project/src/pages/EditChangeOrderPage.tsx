import React from 'react';
import { useNavigate, useParams, Navigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import type { Profile, Invoice, ChangeOrder } from '../types';
import { ChangeOrderForm } from '../components/ChangeOrderForm';

interface EditChangeOrderPageProps {
  profile: Profile;
  invoices: Invoice[];
  changeOrders: ChangeOrder[];
  onSave: (changeOrder: ChangeOrder) => void;
}

export function EditChangeOrderPage({ profile, invoices, changeOrders, onSave }: EditChangeOrderPageProps) {
  const navigate = useNavigate();
  const { invoiceId, changeOrderId } = useParams();
  const invoice = invoices.find(i => i.id === invoiceId);
  const changeOrder = changeOrders.find(co => co.id === changeOrderId);

  if (!invoice || !changeOrder) {
    return <Navigate to="/invoices" replace />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => navigate(`/invoices/${invoice.id}/change-orders`)}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Edit Change Order</h1>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <ChangeOrderForm 
            invoice={invoice}
            onSave={(updatedChangeOrder) => {
              onSave(updatedChangeOrder);
              navigate(`/invoices/${invoice.id}/change-orders`);
            }}
            existingChangeOrder={changeOrder}
          />
        </div>
      </div>
    </div>
  );
}