import React from 'react';
import { useNavigate, useParams, Navigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import type { Profile, Invoice, ChangeOrder } from '../types';
import { ChangeOrderForm } from '../components/ChangeOrderForm';

interface ChangeOrderFormPageProps {
  profile: Profile;
  invoices: Invoice[];
  onSave: (changeOrder: ChangeOrder) => void;
}

export function ChangeOrderFormPage({ profile, invoices, onSave }: ChangeOrderFormPageProps) {
  const navigate = useNavigate();
  const { invoiceId } = useParams();
  const invoice = invoices.find(i => i.id === invoiceId);

  if (!invoice) {
    return <Navigate to="/invoices" replace />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => navigate(`/invoices/${invoice.id}/change-orders`)}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">New Change Order</h1>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <ChangeOrderForm 
            invoice={invoice}
            onSave={(changeOrder) => {
              onSave(changeOrder);
              navigate(`/invoices/${invoice.id}/change-orders`);
            }}
          />
        </div>
      </div>
    </div>
  );
}