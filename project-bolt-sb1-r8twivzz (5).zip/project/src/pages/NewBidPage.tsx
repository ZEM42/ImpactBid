import React from 'react';
import { useNavigate } from 'react-router-dom';
import BidForm from '../components/BidForm';
import type { Profile, Bid } from '../types';

interface NewBidPageProps {
  profile: Profile;
  onSave: (bid: Bid) => void;
}

export function NewBidPage({ profile, onSave }: NewBidPageProps) {
  const navigate = useNavigate();

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Create New Bid</h1>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <BidForm 
          profile={profile} 
          onSave={(bid) => {
            onSave(bid);
            navigate(`/bids/${bid.id}/preview`);
          }}
        />
      </div>
    </div>
  );
}