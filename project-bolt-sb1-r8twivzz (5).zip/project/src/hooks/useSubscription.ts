import { useState } from 'react';
import type { SubscriptionTier } from '../types';

interface UseSubscriptionResult {
  showUpgradeModal: (feature: string, requiredTier: SubscriptionTier) => void;
  hideUpgradeModal: () => void;
  isModalOpen: boolean;
  modalFeature: string;
  modalRequiredTier: SubscriptionTier;
  checkFeatureAccess: (
    feature: string, 
    requiredTier: SubscriptionTier, 
    currentTier: SubscriptionTier,
    context?: { isFirstItem?: boolean }
  ) => boolean;
}

export function useSubscription(): UseSubscriptionResult {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalFeature, setModalFeature] = useState('');
  const [modalRequiredTier, setModalRequiredTier] = useState<SubscriptionTier>('free');

  const tierLevels: Record<SubscriptionTier, number> = {
    'free': 0,
    'pro': 1,
    'elite': 2
  };

  const checkFeatureAccess = (
    feature: string, 
    requiredTier: SubscriptionTier, 
    currentTier: SubscriptionTier,
    context?: { isFirstItem?: boolean }
  ): boolean => {
    // Special case for free tier editing
    if (currentTier === 'free' && (feature === 'Edit Documents' || feature === 'Save Documents')) {
      return context?.isFirstItem ?? false;
    }

    return tierLevels[currentTier] >= tierLevels[requiredTier];
  };

  const showUpgradeModal = (feature: string, requiredTier: SubscriptionTier) => {
    setModalFeature(feature);
    setModalRequiredTier(requiredTier);
    setIsModalOpen(true);
  };

  const hideUpgradeModal = () => {
    setIsModalOpen(false);
  };

  return {
    showUpgradeModal,
    hideUpgradeModal,
    isModalOpen,
    modalFeature,
    modalRequiredTier,
    checkFeatureAccess
  };
}