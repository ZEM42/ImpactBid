import { useState, useCallback, useRef } from 'react';

interface UseVoiceProps {
  onResult: (transcript: string) => void;
  onError?: (error: string) => void;
  onStart?: () => void;
}

export function useVoice({ onResult, onError, onStart }: UseVoiceProps) {
  const [isListening, setIsListening] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);
  const silenceTimeoutRef = useRef<any>(null);
  const transcriptRef = useRef<string>('');

  const startListening = useCallback(() => {
    if (!('webkitSpeechRecognition' in window)) {
      const error = 'Speech recognition is not supported in this browser.';
      setError(error);
      onError?.(error);
      return;
    }

    try {
      // Create a new recognition instance
      const recognition = new (window as any).webkitSpeechRecognition();
      recognitionRef.current = recognition;
      
      // Configure for optimal conversation
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        setError(null);
        transcriptRef.current = '';
        onStart?.();
      };

      recognition.onerror = (event: any) => {
        const error = 'Error occurred in recognition: ' + event.error;
        setError(error);
        onError?.(error);
        if (event.error === 'no-speech') {
          return;
        }
        setIsListening(false);
      };

      recognition.onend = () => {
        if (recognitionRef.current) {
          recognition.start();
        } else {
          setIsListening(false);
          if (transcriptRef.current.trim()) {
            onResult(transcriptRef.current.trim());
            transcriptRef.current = '';
          }
        }
      };

      recognition.onresult = (event: any) => {
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            transcriptRef.current += ' ' + transcript;
          }
        }

        // Clear any existing silence timeout
        if (silenceTimeoutRef.current) {
          clearTimeout(silenceTimeoutRef.current);
        }

        // Set new silence timeout
        silenceTimeoutRef.current = setTimeout(() => {
          if (transcriptRef.current.trim()) {
            onResult(transcriptRef.current.trim());
            transcriptRef.current = '';
          }
        }, 2000); // Wait 2 seconds of silence before sending
      };

      recognition.start();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to start voice recognition';
      setError(errorMessage);
      onError?.(errorMessage);
    }
  }, [onResult, onError, onStart]);

  const stopListening = useCallback(() => {
    if (silenceTimeoutRef.current) {
      clearTimeout(silenceTimeoutRef.current);
    }
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }
    setIsListening(false);
    if (transcriptRef.current.trim()) {
      onResult(transcriptRef.current.trim());
      transcriptRef.current = '';
    }
  }, [onResult]);

  return {
    isListening,
    error,
    startListening,
    stopListening
  };
}