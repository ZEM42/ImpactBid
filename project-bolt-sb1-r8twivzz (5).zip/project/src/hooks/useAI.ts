import { useState, useCallback, useMemo } from 'react';
import { AIService } from '../services/ai';
import type { Profile, AIConversation, Bid } from '../types';

export function useAI(profile: Profile) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Get API key from environment variable
  const API_KEY = import.meta.env.VITE_OPENAI_API_KEY;

  // Initialize AI service with the API key and profile
  const aiService = useMemo(() => {
    try {
      return new AIService(API_KEY, profile);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to initialize AI service';
      setError(errorMessage);
      console.error('AI Service Initialization Error:', { message: errorMessage });
      return null;
    }
  }, [API_KEY, profile]);

  const sendMessage = useCallback(async (
    conversation: AIConversation,
    message: string
  ): Promise<AIResponse> => {
    if (!aiService) {
      throw new Error('AI service not initialized. Please check your API key configuration.');
    }

    if (!message.trim()) {
      throw new Error('Message cannot be empty');
    }

    setIsProcessing(true);
    setError(null);

    try {
      const response = await aiService.sendMessage(conversation, message);
      return response;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to get AI response';
      console.error('AI Service Error:', { message: errorMessage });
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsProcessing(false);
    }
  }, [aiService]);

  const generateBid = useCallback(async (conversation: AIConversation): Promise<Bid> => {
    if (!aiService) {
      throw new Error('AI service not initialized. Please check your API key configuration.');
    }

    if (conversation.messages.length === 0) {
      throw new Error('Cannot generate bid without any conversation history');
    }

    setIsProcessing(true);
    setError(null);

    try {
      return await aiService.generateBid(conversation);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to generate bid';
      console.error('AI Service Error:', { message: errorMessage });
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsProcessing(false);
    }
  }, [aiService]);

  return {
    sendMessage,
    generateBid,
    isProcessing,
    error
  };
}