import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Navigation } from './components/Navigation';
import { AIAssistantButton } from './components/AIAssistantButton';
import { HomePage } from './pages/HomePage';
import { BidsPage } from './pages/BidsPage';
import { ProfilePage } from './pages/ProfilePage';
import { BidPreviewPage } from './pages/BidPreviewPage';
import { InvoicesPage } from './pages/InvoicesPage';
import { InvoicePreviewPage } from './pages/InvoicePreviewPage';
import { NewBidPage } from './pages/NewBidPage';
import { EditBidPage } from './pages/EditBidPage';
import { NewInvoicePage } from './pages/NewInvoicePage';
import { EditInvoicePage } from './pages/EditInvoicePage';
import { ChangeOrdersPage } from './pages/ChangeOrdersPage';
import { ChangeOrderFormPage } from './pages/ChangeOrderFormPage';
import { EditChangeOrderPage } from './pages/EditChangeOrderPage';
import { ChangeOrderPreviewPage } from './pages/ChangeOrderPreviewPage';
import { AITrainingPage } from './pages/AITrainingPage';
import { AIBidAssistantPage } from './pages/AIBidAssistantPage';
import { SubscriptionPage } from './pages/SubscriptionPage';
import type { Profile, Bid, Invoice, ChangeOrder } from './types';
import { sampleProfile, sampleBid, sampleInvoice, sampleChangeOrder, sampleContract } from './samples';

function App() {
  const [profile, setProfile] = useState<Profile>({
    ...sampleProfile,
    contracts: [sampleContract],
    showBanners: true,
    subscriptionTier: 'free',
    aiConversations: []
  });
  
  const [bids, setBids] = useState<Bid[]>([sampleBid]);
  const [invoices, setInvoices] = useState<Invoice[]>([sampleInvoice]);
  const [changeOrders, setChangeOrders] = useState<ChangeOrder[]>([sampleChangeOrder]);

  const handleSaveProfile = (newProfile: Profile) => {
    setProfile(newProfile);
  };

  const handleSaveBid = (newBid: Bid) => {
    setBids(prevBids => {
      if (newBid.id && prevBids.some(bid => bid.id === newBid.id)) {
        return prevBids.map(bid => bid.id === newBid.id ? newBid : bid);
      }
      return [newBid, ...prevBids];
    });
  };

  const handleCreateInvoice = (invoice: Invoice) => {
    setInvoices(prevInvoices => [invoice, ...prevInvoices]);
  };

  const handleSaveChangeOrder = (changeOrder: ChangeOrder) => {
    setChangeOrders(prevChangeOrders => {
      if (changeOrder.id && prevChangeOrders.some(co => co.id === changeOrder.id)) {
        return prevChangeOrders.map(co => co.id === changeOrder.id ? changeOrder : co);
      }
      return [changeOrder, ...prevChangeOrders];
    });
  };

  const handleUpdateSubscription = (tier: Profile['subscriptionTier']) => {
    setProfile(prev => ({
      ...prev,
      subscriptionTier: tier
    }));
  };

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/bids" element={<BidsPage bids={bids} profile={profile} />} />
          <Route path="/profile" element={<ProfilePage profile={profile} onSaveProfile={handleSaveProfile} />} />
          <Route path="/new-bid" element={profile ? <NewBidPage profile={profile} onSave={handleSaveBid} /> : <Navigate to="/profile" replace />} />
          <Route path="/bids/:bidId/edit" element={<EditBidPage profile={profile} bids={bids} onSave={handleSaveBid} />} />
          <Route 
            path="/bids/:bidId/preview" 
            element={
              <BidPreviewPage 
                profile={profile} 
                bids={bids} 
                invoices={invoices}
                onCreateInvoice={handleCreateInvoice} 
              />
            } 
          />
          <Route path="/invoices" element={<InvoicesPage invoices={invoices} bids={bids} />} />
          <Route path="/new-invoice" element={profile ? <NewInvoicePage profile={profile} onSave={handleCreateInvoice} /> : <Navigate to="/profile" replace />} />
          <Route path="/invoices/:invoiceId/edit" element={<EditInvoicePage profile={profile} invoices={invoices} onSave={handleCreateInvoice} />} />
          <Route path="/invoices/:invoiceId/preview" element={<InvoicePreviewPage profile={profile} invoices={invoices} changeOrders={changeOrders} />} />
          
          {/* Change Order Routes */}
          <Route 
            path="/invoices/:invoiceId/change-orders" 
            element={
              <ChangeOrdersPage 
                profile={profile} 
                invoices={invoices} 
                changeOrders={changeOrders} 
              />
            } 
          />
          <Route 
            path="/invoices/:invoiceId/change-orders/new" 
            element={
              <ChangeOrderFormPage 
                profile={profile} 
                invoices={invoices} 
                onSave={handleSaveChangeOrder} 
              />
            } 
          />
          <Route 
            path="/invoices/:invoiceId/change-orders/:changeOrderId/edit" 
            element={
              <EditChangeOrderPage 
                profile={profile} 
                invoices={invoices}
                changeOrders={changeOrders}
                onSave={handleSaveChangeOrder} 
              />
            } 
          />
          <Route 
            path="/invoices/:invoiceId/change-orders/:changeOrderId/preview" 
            element={
              <ChangeOrderPreviewPage 
                profile={profile} 
                invoices={invoices} 
                changeOrders={changeOrders} 
              />
            } 
          />

          {/* AI Routes */}
          <Route 
            path="/ai-training" 
            element={<AITrainingPage profile={profile} onSave={handleSaveProfile} />} 
          />
          <Route 
            path="/ai-assistant" 
            element={
              <AIBidAssistantPage 
                profile={profile} 
                onCreateBid={handleSaveBid}
                onSaveConversation={(conversation) => {
                  setProfile(prev => ({
                    ...prev,
                    aiConversations: [conversation, ...(prev.aiConversations || [])]
                  }));
                }}
              />
            } 
          />

          {/* Subscription Route */}
          <Route
            path="/subscription"
            element={
              <SubscriptionPage
                profile={profile}
                onUpdateSubscription={handleUpdateSubscription}
              />
            }
          />
        </Routes>

        {/* Floating AI Assistant Button */}
        <AIAssistantButton profile={profile} />
      </div>
    </Router>
  );
}

export default App;