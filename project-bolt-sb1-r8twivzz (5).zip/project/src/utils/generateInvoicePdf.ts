// This file is now deprecated. Import from utils/pdf/invoice/generator instead.
import { generateInvoicePdf } from './pdf/invoice/generator';
export { generateInvoicePdf };