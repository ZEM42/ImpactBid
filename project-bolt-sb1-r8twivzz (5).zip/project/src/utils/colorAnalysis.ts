interface RGB {
  r: number;
  g: number;
  b: number;
}

interface ColorCount {
  color: RGB;
  count: number;
}

const rgbToHex = (r: number, g: number, b: number): string => {
  return '#' + [r, g, b].map(x => {
    const hex = x.toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  }).join('');
};

const getColorBrightness = (color: RGB): number => {
  // Using relative luminance formula
  return (0.299 * color.r + 0.587 * color.g + 0.114 * color.b) / 255;
};

const getColorDistance = (color1: RGB, color2: RGB): number => {
  // Using CIEDE2000 color difference formula
  const l1 = getColorBrightness(color1);
  const l2 = getColorBrightness(color2);
  const c1 = Math.sqrt(color1.r * color1.r + color1.g * color1.g);
  const c2 = Math.sqrt(color2.r * color2.r + color2.g * color2.g);
  const dc = c1 - c2;
  const dl = l1 - l2;
  const da = color1.r - color2.r;
  const db = color1.g - color2.g;
  return Math.sqrt(dl * dl + dc * dc + da * da + db * db);
};

const quantizeColor = (color: RGB): RGB => {
  // Quantize to 6 bits per channel for better grouping
  const factor = 4;
  return {
    r: Math.round(color.r / factor) * factor,
    g: Math.round(color.g / factor) * factor,
    b: Math.round(color.b / factor) * factor
  };
};

export const analyzeImageColors = (imageUrl: string): Promise<[string, string]> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "Anonymous";
    
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (!ctx) {
          throw new Error('Could not get canvas context');
        }

        // Scale down image for faster processing
        const maxSize = 200;
        const scale = Math.min(maxSize / img.width, maxSize / img.height);
        canvas.width = Math.max(1, Math.floor(img.width * scale));
        canvas.height = Math.max(1, Math.floor(img.height * scale));

        // Draw and get image data
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const pixels = imageData.data;

        // Count color frequencies
        const colorCounts = new Map<string, ColorCount>();
        const minPixels = 10; // Minimum number of pixels for a color to be considered

        for (let i = 0; i < pixels.length; i += 4) {
          // Skip transparent or nearly transparent pixels
          if (pixels[i + 3] < 200) continue;

          const rgb: RGB = {
            r: pixels[i],
            g: pixels[i + 1],
            b: pixels[i + 2]
          };

          // Skip very light and very dark colors
          const brightness = getColorBrightness(rgb);
          if (brightness < 0.1 || brightness > 0.9) continue;

          // Quantize the color
          const quantized = quantizeColor(rgb);
          const key = `${quantized.r},${quantized.g},${quantized.b}`;

          const existing = colorCounts.get(key);
          if (existing) {
            existing.count++;
          } else {
            colorCounts.set(key, { color: quantized, count: 1 });
          }
        }

        // Filter out colors with too few pixels
        const significantColors = Array.from(colorCounts.values())
          .filter(({ count }) => count >= minPixels)
          .sort((a, b) => b.count - a.count);

        if (significantColors.length === 0) {
          // Fallback to default colors
          resolve(['#1A365D', '#4A5568']);
          return;
        }

        // Get primary color
        const primaryColor = rgbToHex(
          significantColors[0].color.r,
          significantColors[0].color.g,
          significantColors[0].color.b
        );

        // Find a contrasting secondary color
        let secondaryColor = '#4A5568'; // Default fallback
        let maxContrast = 0;

        for (let i = 1; i < significantColors.length; i++) {
          const contrast = getColorDistance(significantColors[0].color, significantColors[i].color);
          if (contrast > maxContrast) {
            maxContrast = contrast;
            secondaryColor = rgbToHex(
              significantColors[i].color.r,
              significantColors[i].color.g,
              significantColors[i].color.b
            );
          }
        }

        resolve([primaryColor, secondaryColor]);
      } catch (error) {
        console.error('Error analyzing colors:', error);
        // Fallback to default colors
        resolve(['#1A365D', '#4A5568']);
      }
    };

    img.onerror = () => {
      console.error('Failed to load image:', imageUrl);
      // Fallback to default colors
      resolve(['#1A365D', '#4A5568']);
    };

    img.src = imageUrl;
  });
};