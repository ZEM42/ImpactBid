import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { Bid, Profile, LineItem, BidImage } from '../types';
import { addWatermark } from './pdf/common/watermark';

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
};

const hexToRgb = (hex: string): { r: number, g: number, b: number } | null => {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null;
};

const addPageStripes = (doc: jsPDF, primaryColor: string, secondaryColor: string, showBanners: boolean = true) => {
  if (!showBanners) return;
  
  const pageCount = doc.internal.getNumberOfPages();
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  
  // Convert hex colors to RGB for jsPDF
  const primary = hexToRgb(primaryColor) || { r: 26, g: 54, b: 93 }; // Default blue if conversion fails
  const secondary = hexToRgb(secondaryColor) || { r: 74, g: 85, b: 104 }; // Default gray if conversion fails

  // Stripe configuration for top and bottom areas
  const stripeHeight = 8; // Height of the stripe area
  const stripeWidths = [8, 6, 4, 2]; // Larger widths for the secondary color stripes
  const stripeGap = 2; // Gap between stripes
  const rightMargin = 20; // Distance from right edge
  const topMargin = 5; // Add margin before the top stripe

  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);

    // Add primary color background for top and bottom
    doc.setFillColor(primary.r, primary.g, primary.b);
    doc.rect(0, topMargin, pageWidth, stripeHeight, 'F'); // Top stripe with margin
    doc.rect(0, pageHeight - stripeHeight - 2, pageWidth, stripeHeight, 'F'); // Bottom stripe moved up slightly

    // Add secondary color stripes on the right side
    doc.setFillColor(secondary.r, secondary.g, secondary.b);
    let currentX = pageWidth - rightMargin;

    // Add stripes from right to left
    stripeWidths.forEach(width => {
      // Top stripes - adjusted for top margin
      doc.rect(currentX - width, topMargin, width, stripeHeight, 'F');
      // Bottom stripes - moved up slightly
      doc.rect(currentX - width, pageHeight - stripeHeight - 2, width, stripeHeight, 'F');
      currentX -= (width + stripeGap);
    });

    // Add page number with larger font size
    doc.setFontSize(10);
    doc.setTextColor(255, 255, 255);
    doc.text(
      `Page ${i} of ${pageCount}`,
      pageWidth / 2,
      pageHeight - (stripeHeight / 2) - 2,
      { align: 'center', baseline: 'middle' }
    );
  }
};

const loadImage = (src: string): Promise<HTMLImageElement> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
};

const processLogo = async (
  pdfDoc: jsPDF,
  logoUrl: string,
  margin: number,
  yPos: number,
  maxWidth: number
): Promise<{ width: number; height: number }> => {
  const img = await loadImage(logoUrl);
  
  // Create a canvas for image processing
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Could not get canvas context');
  }

  // Set canvas size to match image
  canvas.width = img.width;
  canvas.height = img.height;

  // Draw image on canvas
  ctx.drawImage(img, 0, 0);

  // Get image data
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;

  // Find the actual content boundaries
  let minX = canvas.width;
  let maxX = 0;
  let minY = canvas.height;
  let maxY = 0;

  // Scan pixels to find content boundaries (ignoring white/very light pixels)
  for (let y = 0; y < canvas.height; y++) {
    for (let x = 0; x < canvas.width; x++) {
      const i = (y * canvas.width + x) * 4;
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      const a = data[i + 3];

      // Check if pixel is not white/very light and has sufficient opacity
      if (a > 20 && (r < 245 || g < 245 || b < 245)) {
        minX = Math.min(minX, x);
        maxX = Math.max(maxX, x);
        minY = Math.min(minY, y);
        maxY = Math.max(maxY, y);
      }
    }
  }

  // Add padding around the content
  const padding = 10;
  minX = Math.max(0, minX - padding);
  maxX = Math.min(canvas.width, maxX + padding);
  minY = Math.max(0, minY - padding);
  maxY = Math.min(canvas.height, maxY + padding);

  // Calculate dimensions of the content
  const contentWidth = maxX - minX;
  const contentHeight = maxY - minY;
  const aspectRatio = contentWidth / contentHeight;

  // Calculate optimal dimensions for PDF
  const maxHeight = 35; // Maximum height in the header area
  let finalWidth = maxWidth;
  let finalHeight = finalWidth / aspectRatio;

  // Adjust if height exceeds maximum
  if (finalHeight > maxHeight) {
    finalHeight = maxHeight;
    finalWidth = finalHeight * aspectRatio;
  }

  // Create new canvas with only the content
  const outputCanvas = document.createElement('canvas');
  outputCanvas.width = contentWidth;
  outputCanvas.height = contentHeight;
  const outputCtx = outputCanvas.getContext('2d');
  if (!outputCtx) {
    throw new Error('Could not get canvas context');
  }

  // Draw only the content portion
  outputCtx.drawImage(
    canvas,
    minX, minY, contentWidth, contentHeight,
    0, 0, contentWidth, contentHeight
  );

  // Add to PDF
  pdfDoc.addImage(
    outputCanvas.toDataURL('image/png'),
    'PNG',
    margin,
    yPos,
    finalWidth,
    finalHeight,
    undefined,
    'FAST'
  );

  return { width: finalWidth, height: finalHeight };
};

const addImagesToPdf = async (
  pdfDoc: jsPDF,
  images: BidImage[],
  startY: number,
  margin: number,
  pageWidth: number
): Promise<number> => {
  if (!images || images.length === 0) return startY;

  let yPos = startY;
  const imagesPerRow = 4;
  const padding = 4;
  const availableWidth = pageWidth - (2 * margin);
  const maxImageWidth = (availableWidth - (padding * (imagesPerRow - 1))) / imagesPerRow;
  const maxImageHeight = maxImageWidth;

  for (let i = 0; i < images.length; i += imagesPerRow) {
    const rowImages = images.slice(i, i + imagesPerRow);
    let maxRowHeight = 0;
    
    const imageDimensions = await Promise.all(rowImages.map(async (image) => {
      const img = await loadImage(image.url);
      const aspectRatio = img.width / img.height;
      let width = maxImageWidth;
      let height = width / aspectRatio;
      
      if (height > maxImageHeight) {
        height = maxImageHeight;
        width = height * aspectRatio;
      }
      
      maxRowHeight = Math.max(maxRowHeight, height);
      return { img, width, height };
    }));

    if (yPos + maxRowHeight + 15 > pdfDoc.internal.pageSize.getHeight() - margin - 8) {
      pdfDoc.addPage();
      yPos = margin + 20;
    }

    for (let j = 0; j < rowImages.length; j++) {
      const { img, width, height } = imageDimensions[j];
      const xPos = margin + (j * (maxImageWidth + padding)) + ((maxImageWidth - width) / 2);
      
      pdfDoc.addImage(
        img,
        'JPEG',
        xPos,
        yPos + ((maxRowHeight - height) / 2),
        width,
        height,
        undefined,
        'FAST'
      );

      if (rowImages[j].caption) {
        pdfDoc.setFontSize(8);
        pdfDoc.setFont('helvetica', 'normal');
        const captionY = yPos + maxRowHeight + 3;
        pdfDoc.text(rowImages[j].caption, xPos, captionY, {
          maxWidth: width
        });
      }
    }

    yPos += maxRowHeight + 12;
  }

  return yPos;
};

export const generatePdf = async (bid: Bid, profile: Profile, doc?: jsPDF) => {
  const pdfDoc = doc || new jsPDF({
    unit: 'mm',
    format: 'a4',
    putOnlyUsedFonts: true,
    floatPrecision: 16
  });

  // Only add logo for pro and elite tiers
  const shouldShowLogo = profile.subscriptionTier !== 'free';
  const shouldShowBanners = profile.subscriptionTier !== 'free' && profile.showBanners;

  const pageWidth = pdfDoc.internal.pageSize.getWidth();
  const pageHeight = pdfDoc.internal.pageSize.getHeight();
  const margin = 20;
  const bottomMargin = 2;
  let yPos = margin + 12;

  // Helper function to check if we need a new page
  const checkNewPage = (requiredSpace: number) => {
    if (yPos + requiredSpace > pageHeight - bottomMargin - 0) {
      pdfDoc.addPage();
      yPos = margin + 12;
      return true;
    }
    return false;
  };

  const calculateScopeHeight = (scope: LineItem): number => {
    let height = 7;
    
    scope.tasks.forEach(task => {
      const taskText = `• ${task.description}`;
      const splitTask = pdfDoc.splitTextToSize(taskText, pageWidth - (2 * margin) - (scope.showTaskPrices ? 30 : 0));
      height += (splitTask.length * 5) + 2;
    });

    if (scope.showPrices) {
      height += 5;
    }

    if (scope.showImages && scope.images.length > 0) {
      const imagesPerRow = 4;
      const rows = Math.ceil(scope.images.length / imagesPerRow);
      height += (rows * (maxImageWidth + 15)) + 10;
    }

    return height;
  };

  // Process logo if available and allowed
  let logoHeight = 0;
  if (shouldShowLogo && profile.logo) {
    try {
      const maxLogoWidth = (pageWidth - (2 * margin)) * 0.5;
      const { height } = await processLogo(pdfDoc, profile.logo, margin, yPos, maxLogoWidth);
      logoHeight = height;
    } catch (error) {
      console.error('Error processing logo:', error);
    }
  }

  // Company Information - adjusted to align with logo
  const rightColumnX = pageWidth - margin - 80;
  pdfDoc.setFontSize(16);
  pdfDoc.setFont('helvetica', 'bold');
  pdfDoc.text(profile.businessName, rightColumnX, yPos + 5);
  
  pdfDoc.setFontSize(10);
  pdfDoc.setFont('helvetica', 'normal');
  let infoYPos = yPos + 12;
  
  const addressLines = profile.businessAddress.split('\n');
  addressLines.forEach(line => {
    pdfDoc.text(line.trim(), rightColumnX, infoYPos);
    infoYPos += 5;
  });
  
  if (profile.email) {
    pdfDoc.text(profile.email, rightColumnX, infoYPos);
    infoYPos += 5;
  }
  
  if (profile.website) {
    pdfDoc.text(profile.website, rightColumnX, infoYPos);
    infoYPos += 5;
  }
  
  pdfDoc.text(`License: ${profile.licenseNumber}`, rightColumnX, infoYPos);
  
  // Update position based on the taller of logo or company info
  yPos = Math.max(infoYPos + 10, yPos + logoHeight + 10);

  // Add separator line
  pdfDoc.setDrawColor(100);
  pdfDoc.line(margin, yPos, pageWidth - margin, yPos);
  yPos += 10;

  // Client Information
  pdfDoc.setFontSize(11);
  pdfDoc.setFont('helvetica', 'bold');
  pdfDoc.text('Prepared For:', margin, yPos);
  pdfDoc.text(`Date: ${new Date().toLocaleDateString()}`, rightColumnX, yPos);
  yPos += 7;
  
  pdfDoc.setFontSize(10);
  pdfDoc.setFont('helvetica', 'normal');
  pdfDoc.text(bid.clientName, margin, yPos);
  yPos += 5;
  
  const clientAddressLines = bid.clientAddress.split('\n');
  clientAddressLines.forEach(line => {
    pdfDoc.text(line.trim(), margin, yPos);
    yPos += 5;
  });

  yPos += 8;

  // Project Description
  pdfDoc.setFontSize(11);
  pdfDoc.setFont('helvetica', 'bold');
  pdfDoc.text('PROJECT DESCRIPTION', margin, yPos);
  yPos += 7;
  
  pdfDoc.setFontSize(10);
  pdfDoc.setFont('helvetica', 'normal');
  const splitDescription = pdfDoc.splitTextToSize(bid.projectDescription, pageWidth - (2 * margin));
  pdfDoc.text(splitDescription, margin, yPos);
  yPos += (splitDescription.length * 5) + 8;

  // Scope of Work
  pdfDoc.setFontSize(11);
  pdfDoc.setFont('helvetica', 'bold');
  pdfDoc.text('SCOPE OF WORK', margin, yPos);
  yPos += 7;

  // Process each scope
  for (const scope of bid.lineItems) {
    const scopeHeight = calculateScopeHeight(scope);
    
    if (yPos + scopeHeight > pageHeight - bottomMargin - 8) {
      pdfDoc.addPage();
      yPos = margin + 12;
    }

    pdfDoc.setFontSize(10);
    pdfDoc.setFont('helvetica', 'bold');
    pdfDoc.text(scope.scopeName, margin, yPos);
    yPos += 5;
    
    pdfDoc.setFont('helvetica', 'normal');
    
    for (const task of scope.tasks) {
      const taskText = `• ${task.description}`;
      const splitTask = pdfDoc.splitTextToSize(taskText, pageWidth - (2 * margin) - (scope.showTaskPrices ? 30 : 0));
      
      pdfDoc.text(splitTask, margin + 5, yPos);
      
      if (scope.showTaskPrices && task.price !== null) {
        pdfDoc.text(formatCurrency(task.price), pageWidth - margin - 5, yPos, { align: 'right' });
      }
      
      yPos += (splitTask.length * 5) + 2;
    }

    if (scope.showPrices) {
      const total = scope.overridePrice ?? scope.tasks.reduce((sum, task) => sum + (task.price || 0), 0);
      pdfDoc.setFont('helvetica', 'bold');
      pdfDoc.text(formatCurrency(total), pageWidth - margin - 5, yPos, { align: 'right' });
      yPos += 5;
    }

    if (scope.showImages && scope.images.length > 0) {
      yPos = await addImagesToPdf(pdfDoc, scope.images, yPos + 5, margin, pageWidth);
    }

    yPos += 6;
  }

  // Calculate totals
  const subtotal = bid.lineItems.reduce((sum, item) => {
    return sum + (item.overridePrice ?? item.tasks.reduce((taskSum, task) => taskSum + (task.price || 0), 0));
  }, 0);
  
  const tax = bid.applyTax ? subtotal * (profile.taxRate / 100) : 0;
  const total = subtotal + tax;

  // Check if we need a new page for totals
  const totalsHeight = bid.hasPaymentPlan ? 60 : 45; // Increased height for larger font
  if (yPos + totalsHeight > pageHeight - bottomMargin - 20) {
    pdfDoc.addPage();
    yPos = margin + 12;
  }

  // Add totals separator
  pdfDoc.setDrawColor(100);
  pdfDoc.line(pageWidth - margin - 80, yPos, pageWidth - margin, yPos);
  yPos += 10;

  // Subtotal line
  pdfDoc.setFontSize(12); // Increased from 10
  pdfDoc.setFont('helvetica', 'bold');
  pdfDoc.text('Subtotal:', pageWidth - margin - 80, yPos);
  pdfDoc.setFont('helvetica', 'normal');
  pdfDoc.text(formatCurrency(subtotal), pageWidth - margin - 5, yPos, { align: 'right' });
  yPos += 10;

  // Tax line (if applicable)
  if (bid.applyTax) {
    pdfDoc.setFont('helvetica', 'normal');
    pdfDoc.text(`Tax (${profile.taxRate}%):`, pageWidth - margin - 80, yPos);
    pdfDoc.text(formatCurrency(tax), pageWidth - margin - 5, yPos, { align: 'right' });
    yPos += 10;
  }

  // Total line
  pdfDoc.setFont('helvetica', 'bold');
  pdfDoc.text('Total:', pageWidth - margin - 80, yPos);
  pdfDoc.text(formatCurrency(total), pageWidth - margin - 5, yPos, { align: 'right' });
  yPos += 14;

  // Add second separator line
  pdfDoc.setDrawColor(100);
  pdfDoc.line(pageWidth - margin - 80, yPos, pageWidth - margin, yPos);
  yPos += 10;

  // Add deposit line if payment schedule exists and has at least one payment
  if (bid.hasPaymentPlan && bid.payments.length > 0) {
    const deposit = bid.payments[0];
    const depositAmount = deposit.amount 
      ? deposit.amount 
      : deposit.percentage 
        ? total * (deposit.percentage / 100)
        : null;

    if (depositAmount !== null) {
      pdfDoc.setFont('helvetica', 'bold');
      pdfDoc.text('Deposit Due:', pageWidth - margin - 80, yPos);
      pdfDoc.text(formatCurrency(depositAmount), pageWidth - margin - 5, yPos, { align: 'right' });
      yPos += 14;
    }
  }

  // Reset font size for the rest of the document
  pdfDoc.setFontSize(10);

  // Payment Schedule
  if (bid.hasPaymentPlan && bid.payments.length > 0) {
    const requiredSpace = 15 + (bid.payments.length * 7);
    
    if (yPos + requiredSpace > pageHeight - bottomMargin - 20) {
      pdfDoc.addPage();
      yPos = margin + 12;
      pdfDoc.setFontSize(11);
      pdfDoc.setFont('helvetica', 'bold');
      pdfDoc.text('PAYMENT SCHEDULE', margin, yPos);
      yPos += 7;
    } else {
      yPos += 4;
      pdfDoc.setFontSize(11);
      pdfDoc.setFont('helvetica', 'bold');
      pdfDoc.text('PAYMENT SCHEDULE', margin, yPos);
      yPos += 7;
    }

    pdfDoc.setFontSize(10);
    pdfDoc.setFont('helvetica', 'normal');

    for (const payment of bid.payments) {
      if (yPos + 7 > pageHeight - bottomMargin - 20) {
        pdfDoc.addPage();
        yPos = margin + 12;
        pdfDoc.setFont('helvetica', 'normal');
      }

      const paymentAmount = payment.amount 
        ? formatCurrency(payment.amount)
        : payment.percentage 
          ? formatCurrency(total * payment.percentage / 100)
          : 'TBD';

      const label = payment.percentage
        ? `${payment.label} (${payment.percentage}%):`
        : `${payment.label}:`;

      pdfDoc.text(label, margin + 5, yPos);
      pdfDoc.text(paymentAmount, pageWidth - margin - 5, yPos, { align: 'right' });
      yPos += 7;
    }
    yPos += 8;
  }

  // Add Notes section if there are notes
  if (bid.notes && bid.notes.trim()) {
    if (checkNewPage(30)) {
      pdfDoc.setFontSize(11);
      pdfDoc.setFont('helvetica', 'bold');
      pdfDoc.text('NOTES', margin, yPos);
      yPos += 7;
    } else {
      yPos += 4;
      pdfDoc.setFontSize(11);
      pdfDoc.setFont('helvetica', 'bold');
      pdfDoc.text('NOTES', margin, yPos);
      yPos += 7;
    }

    pdfDoc.setFontSize(10);
    pdfDoc.setFont('helvetica', 'normal');
    const splitNotes = pdfDoc.splitTextToSize(bid.notes.trim(), pageWidth - (2 * margin));
    pdfDoc.text(splitNotes, margin, yPos);
    yPos += (splitNotes.length * 5) + 8;
  }

  // Additional Images
  if (bid.showAdditionalImages && bid.additionalImages.length > 0) {
    if (checkNewPage(30)) {
      pdfDoc.setFontSize(11);
      pdfDoc.setFont('helvetica', 'bold');
      pdfDoc.text('ADDITIONAL IMAGES', margin, yPos);
      yPos += 7;
    } else {
      yPos += 4;
      pdfDoc.setFontSize(11);
      pdfDoc.setFont('helvetica', 'bold');
      pdfDoc.text('ADDITIONAL IMAGES', margin, yPos);
      yPos += 7;
    }

    yPos = await addImagesToPdf(pdfDoc, bid.additionalImages, yPos + 5, margin, pageWidth);
  }

  // Contract Section
  if (bid.showContract && bid.contractId) {
    const contract = profile.contracts.find(c => c.id === bid.contractId);
    if (contract) {
      // Always start contract on a new page
      pdfDoc.addPage();
      yPos = margin + 12;

      // Contract Title
      pdfDoc.setFontSize(14);
      pdfDoc.setFont('helvetica', 'bold');
      pdfDoc.text(contract.title.toUpperCase(), margin, yPos);
      yPos += 10;

      // Contract Content
      pdfDoc.setFontSize(10);
      pdfDoc.setFont('helvetica', 'normal');
      const splitContent = pdfDoc.splitTextToSize(contract.content, pageWidth - (2 * margin));
      
      for (let i = 0; i < splitContent.length; i++) {
        if (yPos + 5 > pageHeight - bottomMargin - 20) {
          pdfDoc.addPage();
          yPos = margin + 12;
        }
        pdfDoc.text(splitContent[i], margin, yPos);
        yPos += 5;
      }
    }
  }

  // Add signatures after contract
  if (bid.showClientSignature || bid.showMySignature) {
    // Add some space after contract
    yPos += 20;

    // Check if we need a new page
    if (yPos + 60 > pageHeight - bottomMargin - 20) {
      pdfDoc.addPage();
      yPos = margin + 12;
    }

    if (bid.showClientSignature) {
      pdfDoc.setDrawColor(100);
      pdfDoc.line(margin, yPos, margin + 80, yPos);
      yPos += 5;
      pdfDoc.setFontSize(10);
      pdfDoc.setFont('helvetica', 'normal');
      pdfDoc.text('Client Signature', margin, yPos);
      yPos += 5;
      pdfDoc.setFont('helvetica', 'italic');
      pdfDoc.text(bid.clientName, margin, yPos);
      yPos += 20;
    }

    if (bid.showMySignature) {
      pdfDoc.setDrawColor(100);
      pdfDoc.line(margin, yPos, margin + 80, yPos);
      yPos += 5;
      pdfDoc.setFontSize(10);
      pdfDoc.setFont('helvetica', 'normal');
      pdfDoc.text('Contractor Signature', margin, yPos);
      yPos += 5;
      pdfDoc.setFont('helvetica', 'italic');
      pdfDoc.text(profile.name, margin, yPos);
      yPos += 20;
    }
  }

  // Add stripes after all content is added
  addPageStripes(pdfDoc, profile.primaryColor, profile.secondaryColor, shouldShowBanners);

  // Add watermark for free tier
  if (profile.subscriptionTier === 'free') {
    addWatermark(pdfDoc);
  }

  // Only save if we're not in preview mode
  if (!doc) {
    pdfDoc.save(`bid-${bid.clientName.toLowerCase().replace(/\s+/g, '-')}.pdf`);
  }

  return pdfDoc;
};