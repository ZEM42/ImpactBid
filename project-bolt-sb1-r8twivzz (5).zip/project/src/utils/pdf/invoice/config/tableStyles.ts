import type { UserOptions } from 'jspdf-autotable';

// Common table styling configuration
export const baseTableConfig: Partial<UserOptions> = {
  styles: {
    fontSize: 10,
    cellPadding: { top: 4, right: 6, bottom: 4, left: 6 },
    lineWidth: 1,
    lineColor: [0, 0, 0],
    textColor: [0, 0, 0],
    minCellHeight: 4
  },
  theme: 'plain',
  headStyles: {
    fillColor: [240, 240, 240],
    textColor: [0, 0, 0],
    fontSize: 10,
    fontStyle: 'bold'
  }
};

// Payment Schedule table configuration
export const paymentScheduleConfig: Partial<UserOptions> = {
  ...baseTableConfig,
  columns: [
    { header: 'Payment', dataKey: 0 },
    { header: 'Percentage', dataKey: 1 },
    { header: 'Amount', dataKey: 2 },
    { header: 'Status', dataKey: 3 }
  ],
  columnStyles: {
    0: { cellWidth: 60 },
    1: { cellWidth: 30, halign: 'right' },
    2: { cellWidth: 40, halign: 'right' },
    3: { cellWidth: 'auto', halign: 'right' }
  }
};

// Change Orders table configuration
export const changeOrdersConfig: Partial<UserOptions> = {
  ...baseTableConfig,
  columns: [
    { header: 'Change Order', dataKey: 0 },
    { header: 'Amount', dataKey: 1 },
    { header: 'Status', dataKey: 2 }
  ],
  columnStyles: {
    0: { cellWidth: 60 },
    1: { cellWidth: 40, halign: 'right' },
    2: { cellWidth: 'auto', halign: 'right' }
  }
};

// Payment Summary table configuration
export const paymentSummaryConfig: Partial<UserOptions> = {
  ...baseTableConfig,
  columns: [
    { header: 'Type', dataKey: 0 },
    { header: 'Amount', dataKey: 1 }
  ],
  columnStyles: {
    0: { cellWidth: 100 },
    1: { cellWidth: 'auto', halign: 'right' }
  }
};