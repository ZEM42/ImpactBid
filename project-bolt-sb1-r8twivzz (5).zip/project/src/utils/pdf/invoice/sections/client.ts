import type { jsPDF } from 'jspdf';
import type { Invoice } from '../../../../types';

export function addClientInfo(
  doc: jsPDF,
  invoice: Invoice,
  margin: number,
  rightColumnX: number,
  startY: number
): number {
  let yPos = startY + 4; // Added 4 units of spacing here

  doc.setFontSize(24);
  doc.setFont('helvetica', 'bold');
  doc.text('INVOICE', margin, yPos);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Invoice #: ${invoice.invoiceNumber}`, margin, yPos + 8);
  doc.text(`Date: ${new Date().toLocaleDateString()}`, margin, yPos + 13);

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('BILL TO:', rightColumnX, yPos);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(invoice.clientName, rightColumnX, yPos + 8);
  
  let clientYPos = yPos + 13;
  const clientAddressLines = invoice.clientAddress.split('\n');
  clientAddressLines.forEach(line => {
    doc.text(line.trim(), rightColumnX, clientYPos);
    clientYPos += 5;
  });

  return Math.max(clientYPos + 4, yPos + 20);
}