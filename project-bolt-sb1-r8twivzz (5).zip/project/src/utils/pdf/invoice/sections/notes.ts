import type { jsPDF } from 'jspdf';
import type { Invoice } from '../../../../types';

export function addNotes(
  doc: jsPDF,
  invoice: Invoice,
  margin: number,
  startY: number
): number {
  if (!invoice.notes) return startY;

  let yPos = startY;

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('NOTES', margin, yPos);
  yPos += 7;

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const splitNotes = doc.splitTextToSize(
    invoice.notes, 
    doc.internal.pageSize.getWidth() - (2 * margin)
  );
  doc.text(splitNotes, margin, yPos);

  return yPos + (splitNotes.length * 5);
}