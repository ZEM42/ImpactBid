import type { jsPDF } from 'jspdf';
import type { Profile } from '../../../../types';
import { processLogo } from '../images';

export async function addHeader(
  doc: jsPDF,
  profile: Profile,
  margin: number,
  rightColumnX: number,
  startY: number
): Promise<number> {
  let yPos = startY;
  let logoHeight = 0;

  if (profile.logo) {
    try {
      const maxLogoWidth = (doc.internal.pageSize.getWidth() - (2 * margin)) * 0.25;
      const { height } = await processLogo(doc, profile.logo, margin, yPos, maxLogoWidth);
      logoHeight = height;
    } catch (error) {
      console.error('Error processing logo:', error);
    }
  }

  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(profile.businessName, rightColumnX, yPos + 5);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  let infoYPos = yPos + 15;
  
  const addressLines = profile.businessAddress.split('\n');
  addressLines.forEach(line => {
    doc.text(line.trim(), rightColumnX, infoYPos);
    infoYPos += 5;
  });
  
  if (profile.email) {
    doc.text(profile.email, rightColumnX, infoYPos);
    infoYPos += 5;
  }
  
  if (profile.website) {
    doc.text(profile.website, rightColumnX, infoYPos);
    infoYPos += 5;
  }
  
  doc.text(`License: ${profile.licenseNumber}`, rightColumnX, infoYPos);
  
  return Math.max(infoYPos + 10, yPos + logoHeight + 15);
}