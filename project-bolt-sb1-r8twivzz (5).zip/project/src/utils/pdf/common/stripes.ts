import type { jsPDF } from 'jspdf';
import { hexToRgb } from './colors';

export function addPageStripes(doc: jsPDF, primaryColor: string, secondaryColor: string, showBanners: boolean = true) {
  if (!showBanners) return;

  const pageCount = doc.internal.getNumberOfPages();
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  
  const primary = hexToRgb(primaryColor) || { r: 26, g: 54, b: 93 };
  const secondary = hexToRgb(secondaryColor) || { r: 74, g: 85, b: 104 };

  const stripeHeight = 8;
  const stripeWidths = [8, 6, 4, 2];
  const stripeGap = 2;
  const rightMargin = 20;
  const topMargin = 5;

  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);

    doc.setFillColor(primary.r, primary.g, primary.b);
    doc.rect(0, topMargin, pageWidth, stripeHeight, 'F');
    doc.rect(0, pageHeight - stripeHeight - 2, pageWidth, stripeHeight, 'F');

    doc.setFillColor(secondary.r, secondary.g, secondary.b);
    let currentX = pageWidth - rightMargin;

    stripeWidths.forEach(width => {
      doc.rect(currentX - width, topMargin, width, stripeHeight, 'F');
      doc.rect(currentX - width, pageHeight - stripeHeight - 2, width, stripeHeight, 'F');
      currentX -= (width + stripeGap);
    });

    doc.setFontSize(10);
    doc.setTextColor(255, 255, 255);
    doc.text(
      `Page ${i} of ${pageCount}`,
      pageWidth / 2,
      pageHeight - (stripeHeight / 2) - 2,
      { align: 'center', baseline: 'middle' }
    );
  }
}