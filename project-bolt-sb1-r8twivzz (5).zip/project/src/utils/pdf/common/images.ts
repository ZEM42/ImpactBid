import type { jsPDF } from 'jspdf';

export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

export async function processLogo(
  pdfDoc: jsPDF,
  logoUrl: string,
  margin: number,
  yPos: number,
  maxWidth: number
): Promise<{ width: number; height: number }> {
  const img = await loadImage(logoUrl);
  
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Could not get canvas context');
  }

  canvas.width = img.width;
  canvas.height = img.height;
  ctx.drawImage(img, 0, 0);

  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;

  let minX = canvas.width;
  let maxX = 0;
  let minY = canvas.height;
  let maxY = 0;

  for (let y = 0; y < canvas.height; y++) {
    for (let x = 0; x < canvas.width; x++) {
      const i = (y * canvas.width + x) * 4;
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      const a = data[i + 3];

      if (a > 20 && (r < 245 || g < 245 || b < 245)) {
        minX = Math.min(minX, x);
        maxX = Math.max(maxX, x);
        minY = Math.min(minY, y);
        maxY = Math.max(maxY, y);
      }
    }
  }

  const padding = 10;
  minX = Math.max(0, minX - padding);
  maxX = Math.min(canvas.width, maxX + padding);
  minY = Math.max(0, minY - padding);
  maxY = Math.min(canvas.height, maxY + padding);

  const contentWidth = maxX - minX;
  const contentHeight = maxY - minY;
  const aspectRatio = contentWidth / contentHeight;

  const maxHeight = 35;
  let finalWidth = maxWidth;
  let finalHeight = finalWidth / aspectRatio;

  if (finalHeight > maxHeight) {
    finalHeight = maxHeight;
    finalWidth = finalHeight * aspectRatio;
  }

  const outputCanvas = document.createElement('canvas');
  outputCanvas.width = contentWidth;
  outputCanvas.height = contentHeight;
  const outputCtx = outputCanvas.getContext('2d');
  if (!outputCtx) {
    throw new Error('Could not get canvas context');
  }

  outputCtx.drawImage(
    canvas,
    minX, minY, contentWidth, contentHeight,
    0, 0, contentWidth, contentHeight
  );

  pdfDoc.addImage(
    outputCanvas.toDataURL('image/png'),
    'PNG',
    margin,
    yPos,
    finalWidth,
    finalHeight,
    undefined,
    'FAST'
  );

  return { width: finalWidth, height: finalHeight };
}