import React, { useRef, useState } from 'react';
import { Upload, X } from 'lucide-react';
import type { BidImage } from '../types';

interface ImageUploadProps {
  images: BidImage[];
  onImagesChange: (images: BidImage[]) => void;
  maxImages?: number;
  className?: string;
}

export function ImageUpload({ images, onImagesChange, maxImages, className = '' }: ImageUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState<string | null>(null);

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setError(null);

    // Check if adding new images would exceed the limit
    if (maxImages && images.length + files.length > maxImages) {
      setError(`You can only add up to ${maxImages} images`);
      return;
    }

    // Validate files
    for (const file of files) {
      if (!file.type.startsWith('image/')) {
        setError('Please select only image files.');
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        setError('Images must be less than 5MB.');
        return;
      }
    }

    // Process each file
    const newImages: BidImage[] = await Promise.all(
      files.map(async (file) => {
        return new Promise<BidImage>((resolve) => {
          const reader = new FileReader();
          reader.onload = (event) => {
            if (event.target?.result) {
              // Create an image element to get dimensions
              const img = new Image();
              img.onload = () => {
                // Create a canvas to resize the image if needed
                const canvas = document.createElement('canvas');
                const maxDimension = 1200;
                const aspectRatio = img.width / img.height;
                
                let width = img.width;
                let height = img.height;
                
                // Scale down if image is too large while maintaining aspect ratio
                if (width > maxDimension || height > maxDimension) {
                  if (width > height) {
                    width = maxDimension;
                    height = width / aspectRatio;
                  } else {
                    height = maxDimension;
                    width = height * aspectRatio;
                  }
                }
                
                canvas.width = width;
                canvas.height = height;
                
                const ctx = canvas.getContext('2d');
                ctx?.drawImage(img, 0, 0, width, height);
                
                resolve({
                  id: crypto.randomUUID(),
                  url: canvas.toDataURL('image/jpeg', 0.8),
                  caption: ''
                });
              };
              img.src = event.target.result as string;
            }
          };
          reader.readAsDataURL(file);
        });
      })
    );

    onImagesChange([...images, ...newImages]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeImage = (imageId: string) => {
    onImagesChange(images.filter(img => img.id !== imageId));
  };

  const updateCaption = (imageId: string, caption: string) => {
    onImagesChange(
      images.map(img => 
        img.id === imageId ? { ...img, caption } : img
      )
    );
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className={className}>
      {error && (
        <div className="mb-4 p-3 bg-red-50 border-l-4 border-red-500 text-red-700">
          {error}
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {images.map((image) => (
          <div key={image.id} className="relative group">
            <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
              <img
                src={image.url}
                alt={image.caption}
                className="w-full h-full object-contain"
              />
            </div>
            <input
              type="text"
              value={image.caption}
              onChange={(e) => updateCaption(image.id, e.target.value)}
              placeholder="Add caption"
              className="mt-2 w-full text-sm border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
            <button
              type="button"
              onClick={() => removeImage(image.id)}
              className="absolute -top-2 -right-2 p-1 bg-red-100 rounded-full text-red-600 hover:bg-red-200"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}

        {(!maxImages || images.length < maxImages) && (
          <button
            type="button"
            onClick={handleUploadClick}
            className="aspect-square border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-blue-500 hover:bg-gray-50 transition-colors"
            aria-label="Add images"
          >
            <Upload className="w-8 h-8 text-gray-400" />
            <span className="mt-2 text-sm text-gray-500">Add Images</span>
            {maxImages && (
              <span className="mt-1 text-xs text-gray-400">
                {images.length} of {maxImages} used
              </span>
            )}
            <span className="mt-1 text-xs text-gray-400">Up to 5MB each</span>
          </button>
        )}
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleImageChange}
        className="hidden"
        multiple
      />
    </div>
  );
}