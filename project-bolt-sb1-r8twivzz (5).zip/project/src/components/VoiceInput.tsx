import React from 'react';
import { Mic, MicOff } from 'lucide-react';

interface VoiceInputProps {
  isListening: boolean;
  onStart: () => void;
  onStop: () => void;
  error?: string | null;
}

export function VoiceInput({ isListening, onStart, onStop, error }: VoiceInputProps) {
  return (
    <div className="relative">
      <button
        onClick={isListening ? onStop : onStart}
        className={`relative flex items-center gap-2 px-4 py-2 rounded-md transition-all duration-200 ${
          isListening 
            ? 'bg-red-100 text-red-600 hover:bg-red-200 animate-pulse' 
            : 'bg-blue-100 text-blue-900 hover:bg-blue-200'
        }`}
        title={isListening ? 'Stop recording' : 'Start recording'}
      >
        {isListening ? (
          <>
            <div className="absolute -left-1 -right-1 -top-1 -bottom-1 bg-red-100 rounded-md animate-ping opacity-75"></div>
            <MicOff className="w-4 h-4 relative" />
            <span className="text-sm relative">Stop</span>
          </>
        ) : (
          <>
            <Mic className="w-4 h-4" />
            <span className="text-sm">Speak</span>
          </>
        )}
      </button>
      {error && (
        <div className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 whitespace-nowrap bg-red-100 text-red-600 text-xs px-2 py-1 rounded shadow-sm">
          {error}
        </div>
      )}
    </div>
  );
}