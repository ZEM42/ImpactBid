import React, { useState } from 'react';
import { Save } from 'lucide-react';
import type { Invoice, Profile } from '../types';
import { HeaderSection } from './invoice/sections/HeaderSection';
import { ClientSection } from './invoice/sections/ClientSection';
import { PaymentScheduleSection } from './invoice/sections/PaymentScheduleSection';
import { NotesSection } from './invoice/sections/NotesSection';

interface InvoiceFormProps {
  profile: Profile;
  onSave: (invoice: Invoice) => void;
  existingInvoice?: Invoice;
}

export function InvoiceForm({ profile, onSave, existingInvoice }: InvoiceFormProps) {
  const [invoice, setInvoice] = useState<Omit<Invoice, 'id' | 'createdAt'>>({
    bidId: existingInvoice?.bidId || null,
    clientName: existingInvoice?.clientName || '',
    clientAddress: existingInvoice?.clientAddress || '',
    projectDescription: existingInvoice?.projectDescription || '',
    lineItems: existingInvoice?.lineItems || [],
    applyTax: existingInvoice?.applyTax ?? false,
    status: existingInvoice?.status || 'draft',
    invoiceNumber: existingInvoice?.invoiceNumber || `INV-${new Date().getFullYear()}-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`,
    notes: existingInvoice?.notes || '',
    additionalImages: existingInvoice?.additionalImages || [],
    showAdditionalImages: existingInvoice?.showAdditionalImages || false,
    hasPaymentPlan: existingInvoice?.hasPaymentPlan || false,
    payments: existingInvoice?.payments.map(p => ({
      ...p,
      includeDueDate: p.dueDate !== null
    })) || []
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...invoice,
      id: existingInvoice?.id || crypto.randomUUID(),
      createdAt: existingInvoice?.createdAt || new Date()
    });
  };

  const total = invoice.lineItems.reduce((sum, item) => {
    return sum + (item.overridePrice ?? item.tasks.reduce((taskSum, task) => taskSum + (task.price || 0), 0));
  }, 0);

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <HeaderSection invoice={invoice} setInvoice={setInvoice} />
      <ClientSection invoice={invoice} setInvoice={setInvoice} />
      <PaymentScheduleSection invoice={invoice} setInvoice={setInvoice} total={total} />
      <NotesSection invoice={invoice} setInvoice={setInvoice} />

      <button
        type="submit"
        className="flex items-center justify-center w-full px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
      >
        <Save className="w-4 h-4 mr-2" />
        Save Invoice
      </button>
    </form>
  );
}