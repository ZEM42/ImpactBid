import React from 'react';
import { X } from 'lucide-react';
import type { Invoice, Payment } from '../../../types';
import { PaymentStatusSelector } from './PaymentStatusSelector';
import { PaymentMethodSelector } from './PaymentMethodSelector';

interface PaymentScheduleSectionProps {
  invoice: Omit<Invoice, 'id' | 'createdAt'>;
  setInvoice: React.Dispatch<React.SetStateAction<Omit<Invoice, 'id' | 'createdAt'>>>;
  total: number;
}

export function PaymentScheduleSection({ invoice, setInvoice, total }: PaymentScheduleSectionProps) {
  const addPayment = () => {
    const currentPayments = invoice.payments || [];
    const newPaymentNumber = currentPayments.length + 1;
    
    setInvoice({
      ...invoice,
      hasPaymentPlan: true,
      payments: [
        ...currentPayments,
        {
          id: crypto.randomUUID(),
          label: `Payment ${newPaymentNumber}`,
          percentage: null,
          amount: null,
          status: 'upcoming',
          includeDueDate: false,
          dueDate: null,
          paidDate: null
        }
      ]
    });
  };

  const removePayment = (paymentId: string) => {
    const updatedPayments = invoice.payments.filter(payment => payment.id !== paymentId);
    setInvoice({
      ...invoice,
      payments: updatedPayments,
      hasPaymentPlan: updatedPayments.length > 0
    });
  };

  const updatePayment = (paymentId: string, updates: Partial<Payment>) => {
    setInvoice({
      ...invoice,
      payments: invoice.payments.map(payment => {
        if (payment.id !== paymentId) return payment;
        
        // If we're updating the percentage, calculate the new amount
        if (updates.percentage !== undefined) {
          return {
            ...payment,
            ...updates,
            amount: updates.percentage ? (total * updates.percentage / 100) : null
          };
        }
        
        // If we're updating the amount, clear the percentage
        if (updates.amount !== undefined) {
          return {
            ...payment,
            ...updates,
            percentage: null
          };
        }

        // If we're updating the status to paid, set the paid date to today if not already set
        if (updates.status === 'paid' && !payment.paidDate) {
          return {
            ...payment,
            ...updates,
            paidDate: new Date()
          };
        }

        // If we're disabling the due date, clear it
        if (updates.includeDueDate === false) {
          return {
            ...payment,
            ...updates,
            dueDate: null
          };
        }
        
        return {
          ...payment,
          ...updates
        };
      })
    });
  };

  return (
    <div className="border-t border-gray-200 pt-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900">Payment Schedule</h3>
        <button
          type="button"
          onClick={addPayment}
          className="text-sm text-blue-900 hover:text-blue-800 font-medium"
        >
          Add Payment
        </button>
      </div>

      <div className="space-y-4">
        {invoice.payments.map((payment, index) => (
          <div key={payment.id} className="bg-gray-50 p-4 rounded-lg space-y-4">
            <div className="flex justify-between items-start">
              <h4 className="text-sm font-medium text-gray-900">{payment.label}</h4>
              {index > 0 && (
                <button
                  type="button"
                  onClick={() => removePayment(payment.id)}
                  className="text-gray-400 hover:text-red-600"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Amount
                </label>
                <input
                  type="number"
                  value={payment.amount?.toFixed(2) || ''}
                  onChange={(e) => {
                    const value = e.target.value;
                    updatePayment(payment.id, {
                      amount: value === '' ? null : parseFloat(value),
                      percentage: null
                    });
                  }}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  min="0"
                  step="0.01"
                  placeholder="Enter $"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Percentage
                </label>
                <input
                  type="number"
                  value={payment.percentage || ''}
                  onChange={(e) => {
                    const value = e.target.value;
                    updatePayment(payment.id, {
                      percentage: value === '' ? null : parseFloat(value)
                    });
                  }}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  min="0"
                  max="100"
                  step="0.1"
                  placeholder="Enter %"
                />
              </div>
            </div>

            <PaymentStatusSelector 
              payment={payment} 
              onUpdate={(updates) => updatePayment(payment.id, updates)} 
            />

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-gray-700">
                  Due Date
                </label>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={payment.includeDueDate}
                    onChange={(e) => updatePayment(payment.id, { 
                      includeDueDate: e.target.checked,
                      dueDate: e.target.checked ? payment.dueDate || new Date() : null
                    })}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-900"></div>
                  <span className="ml-3 text-sm font-medium text-gray-700">
                    {payment.includeDueDate ? 'Due date included' : 'Due upon receipt'}
                  </span>
                </label>
              </div>

              {payment.includeDueDate && (
                <input
                  type="date"
                  value={payment.dueDate ? new Date(payment.dueDate).toISOString().split('T')[0] : ''}
                  onChange={(e) => updatePayment(payment.id, {
                    dueDate: e.target.value ? new Date(e.target.value) : null
                  })}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required={payment.includeDueDate}
                />
              )}
            </div>

            {payment.status === 'paid' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Paid Date
                  </label>
                  <input
                    type="date"
                    value={payment.paidDate ? new Date(payment.paidDate).toISOString().split('T')[0] : ''}
                    onChange={(e) => updatePayment(payment.id, {
                      paidDate: e.target.value ? new Date(e.target.value) : null
                    })}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>

                <PaymentMethodSelector 
                  payment={payment} 
                  onUpdate={(updates) => updatePayment(payment.id, updates)} 
                />
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}