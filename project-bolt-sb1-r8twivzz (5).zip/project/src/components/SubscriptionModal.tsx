import React from 'react';
import { X } from 'lucide-react';
import type { SubscriptionTier } from '../types';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  requiredTier: SubscriptionTier;
  feature: string;
}

export function SubscriptionModal({ isOpen, onClose, requiredTier, feature }: SubscriptionModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-xl font-semibold text-gray-900">Upgrade Required</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-6">
          <p className="text-gray-600 mb-4">
            The {feature} feature is available with our Pro plan.
          </p>

          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold text-gray-900 mb-2">Pro Plan Features</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Save and edit documents</li>
                <li>• Change orders</li>
                <li>• Custom logo</li>
                <li>• Colored banners</li>
                <li>• No watermark</li>
                <li>• Priority email support</li>
              </ul>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold text-gray-900 mb-2">Elite Plan Features</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Everything in Pro</li>
                <li>• Advanced analytics (Coming soon)</li>
                <li>• Custom templates (Coming soon)</li>
                <li>• API access (Coming soon)</li>
                <li>• 24/7 phone support (Coming soon)</li>
              </ul>
            </div>
          </div>

          <div className="mt-6 flex flex-col gap-3">
            <button
              onClick={() => {
                // TODO: Implement subscription flow
                alert('Subscription flow will be implemented here');
                onClose();
              }}
              className="w-full px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Upgrade Now
            </button>
            <button
              onClick={onClose}
              className="w-full px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Maybe Later
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}