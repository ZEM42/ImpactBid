import React, { useState } from 'react';
import { Save } from 'lucide-react';
import type { Invoice, ChangeOrder } from '../types';
import { ClientInfo } from './bid/sections/ClientInfo';
import { ScopeOfWork } from './bid/sections/ScopeOfWork';
import { AdditionalImagesSection } from './bid/sections/AdditionalImagesSection';
import { SignaturesSection } from './bid/sections/SignaturesSection';
import { PaymentStatusSelector } from './invoice/sections/PaymentStatusSelector';

interface ChangeOrderFormProps {
  invoice: Invoice;
  onSave: (changeOrder: ChangeOrder) => void;
  existingChangeOrder?: ChangeOrder;
}

export function ChangeOrderForm({ invoice, onSave, existingChangeOrder }: ChangeOrderFormProps) {
  const [changeOrder, setChangeOrder] = useState<Omit<ChangeOrder, 'id' | 'createdAt'>>({
    invoiceId: invoice.id,
    clientName: existingChangeOrder?.clientName || invoice.clientName,
    clientAddress: existingChangeOrder?.clientAddress || invoice.clientAddress,
    projectDescription: existingChangeOrder?.projectDescription || '',
    lineItems: existingChangeOrder?.lineItems ? existingChangeOrder.lineItems.map(item => ({
      ...item,
      images: item.images || [],
      showImages: item.images?.length > 0 || false
    })) : [],
    applyTax: existingChangeOrder?.applyTax ?? invoice.applyTax,
    notes: existingChangeOrder?.notes || '',
    additionalImages: existingChangeOrder?.additionalImages || [],
    showAdditionalImages: existingChangeOrder?.showAdditionalImages || false,
    showClientSignature: existingChangeOrder?.showClientSignature ?? false,
    showMySignature: existingChangeOrder?.showMySignature ?? false,
    paymentStatus: existingChangeOrder?.paymentStatus || 'upcoming'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...changeOrder,
      id: existingChangeOrder?.id || crypto.randomUUID(),
      createdAt: existingChangeOrder?.createdAt || new Date()
    });
  };

  // Calculate total for display
  const subtotal = changeOrder.lineItems.reduce((sum, item) => {
    return sum + (item.overridePrice ?? item.tasks.reduce((taskSum, task) => taskSum + (task.price || 0), 0));
  }, 0);
  const tax = changeOrder.applyTax ? subtotal * (8.9 / 100) : 0;
  const total = subtotal + tax;

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-gray-50 p-4 rounded-lg">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Client Information</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm font-medium text-gray-500">Client Name</p>
            <p className="mt-1">{changeOrder.clientName}</p>
          </div>
          <div className="col-span-2">
            <p className="text-sm font-medium text-gray-500">Client Address</p>
            <p className="mt-1 whitespace-pre-line">{changeOrder.clientAddress}</p>
          </div>
        </div>
      </div>

      <div>
        <label htmlFor="projectDescription" className="block text-sm font-medium text-gray-700">
          Change Order Description
        </label>
        <textarea
          id="projectDescription"
          value={changeOrder.projectDescription}
          onChange={(e) => setChangeOrder({ ...changeOrder, projectDescription: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          rows={4}
          required
          placeholder="Describe the changes or additions to the original scope of work..."
        />
      </div>

      <ScopeOfWork 
        bid={changeOrder} 
        setBid={setChangeOrder as any} 
        profile={{ taxRate: 8.9, defaultShowScopePrices: true, defaultShowTaskPrices: true }}
      />

      <div className="border-t border-gray-200 pt-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Payment Status</h3>
        <PaymentStatusSelector 
          payment={{
            id: 'temp',
            label: 'Change Order Payment',
            percentage: null,
            amount: total,
            status: changeOrder.paymentStatus,
            includeDueDate: false,
            dueDate: null,
            paidDate: null
          }}
          onUpdate={(updates) => {
            if (updates.status) {
              setChangeOrder({ ...changeOrder, paymentStatus: updates.status });
            }
          }}
        />
      </div>

      <div>
        <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
          Notes
        </label>
        <textarea
          id="notes"
          value={changeOrder.notes}
          onChange={(e) => setChangeOrder({ ...changeOrder, notes: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          rows={4}
          placeholder="Any additional notes or comments..."
        />
      </div>

      <AdditionalImagesSection 
        bid={changeOrder} 
        setBid={setChangeOrder as any} 
      />

      <SignaturesSection 
        bid={changeOrder} 
        setBid={setChangeOrder as any} 
      />

      <button
        type="submit"
        className="flex items-center justify-center w-full px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
      >
        <Save className="w-4 h-4 mr-2" />
        Save Change Order
      </button>
    </form>
  );
}