import React, { useState, useRef, useEffect } from 'react';
import { Save } from 'lucide-react';
import type { Bid, Profile } from '../../types';
import { BusinessInfo } from './sections/BusinessInfo';
import { ClientInfo } from './sections/ClientInfo';
import { ScopeOfWork } from './sections/ScopeOfWork';
import { PaymentSection } from './sections/PaymentSection';
import { ContractSection } from './sections/ContractSection';
import { SignaturesSection } from './sections/SignaturesSection';
import { AdditionalImagesSection } from './sections/AdditionalImagesSection';

interface BidFormProps {
  profile: Profile;
  onSave: (bid: Bid) => void;
  existingBid?: Bid;
}

function BidForm({ profile, onSave, existingBid }: BidFormProps) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const [bid, setBid] = useState<Omit<Bid, 'id' | 'createdAt'>>({
    clientName: existingBid?.clientName || '',
    clientAddress: existingBid?.clientAddress || '',
    projectDescription: existingBid?.projectDescription || '',
    lineItems: existingBid?.lineItems ? existingBid.lineItems.map(item => ({
      ...item,
      images: item.images || [],
      showImages: item.images?.length > 0 || false
    })) : [],
    applyTax: existingBid?.applyTax ?? true,
    hasPaymentPlan: existingBid?.hasPaymentPlan || false,
    payments: existingBid?.payments || [
      {
        id: crypto.randomUUID(),
        label: 'Deposit',
        percentage: null,
        amount: null
      }
    ],
    additionalImages: existingBid?.additionalImages || [],
    showAdditionalImages: existingBid?.additionalImages?.length > 0 || false,
    notes: existingBid?.notes || '',
    contractId: existingBid?.contractId || profile.contracts[0]?.id || null,
    showContract: existingBid?.showContract ?? true,
    showClientSignature: existingBid?.showClientSignature ?? true,
    showMySignature: existingBid?.showMySignature ?? false
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...bid,
      id: existingBid?.id || crypto.randomUUID(),
      createdAt: existingBid?.createdAt || new Date(),
    });
  };

  return (
    <div className="relative">
      {/* Floating Save Button */}
      <div
        className={`fixed top-0 right-0 left-0 z-50 transition-all duration-200 ${
          scrolled ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="max-w-4xl mx-auto px-4">
          <div className="bg-white py-2 px-4 rounded-lg shadow-md float-right mt-4">
            <button
              type="submit"
              form="bidForm"
              className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Bid
            </button>
          </div>
        </div>
      </div>

      <form id="bidForm" onSubmit={handleSubmit} className="space-y-6">
        <BusinessInfo profile={profile} />
        <ClientInfo bid={bid} setBid={setBid} />
        <ScopeOfWork bid={bid} setBid={setBid} profile={profile} />
        <PaymentSection bid={bid} setBid={setBid} profile={profile} />
        <ContractSection bid={bid} setBid={setBid} profile={profile} />
        <SignaturesSection bid={bid} setBid={setBid} />
        <AdditionalImagesSection bid={bid} setBid={setBid} />
      </form>
    </div>
  );
}

export default BidForm;