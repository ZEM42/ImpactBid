import React from 'react';
import type { Bid } from '../../../types';

interface ClientInfoProps {
  bid: Omit<Bid, 'id' | 'createdAt'>;
  setBid: React.Dispatch<React.SetStateAction<Omit<Bid, 'id' | 'createdAt'>>>;
}

export function ClientInfo({ bid, setBid }: ClientInfoProps) {
  return (
    <div className="space-y-4">
      <div>
        <label htmlFor="clientName" className="block text-sm font-medium text-gray-700">
          Client Name
        </label>
        <input
          type="text"
          id="clientName"
          value={bid.clientName}
          onChange={(e) => setBid({ ...bid, clientName: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          required
        />
      </div>

      <div>
        <label htmlFor="clientAddress" className="block text-sm font-medium text-gray-700">
          Client Address
        </label>
        <textarea
          id="clientAddress"
          value={bid.clientAddress}
          onChange={(e) => setBid({ ...bid, clientAddress: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          rows={3}
          required
        />
      </div>

      <div>
        <label htmlFor="projectDescription" className="block text-sm font-medium text-gray-700">
          Project Description
        </label>
        <textarea
          id="projectDescription"
          value={bid.projectDescription}
          onChange={(e) => setBid({ ...bid, projectDescription: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          rows={4}
          required
        />
      </div>
    </div>
  );
}