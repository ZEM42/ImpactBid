import React from 'react';
import type { Bid } from '../../../types';
import { ImageUpload } from '../../ImageUpload';

interface AdditionalImagesSectionProps {
  bid: Omit<Bid, 'id' | 'createdAt'>;
  setBid: React.Dispatch<React.SetStateAction<Omit<Bid, 'id' | 'createdAt'>>>;
}

export function AdditionalImagesSection({ bid, setBid }: AdditionalImagesSectionProps) {
  const toggleAdditionalImages = () => {
    setBid({
      ...bid,
      showAdditionalImages: !bid.showAdditionalImages
    });
  };

  return (
    <div className="border-t border-gray-200 pt-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900">Additional Images</h3>
        <label className="relative inline-flex items-center cursor-pointer">
          <input
            type="checkbox"
            className="sr-only peer"
            checked={bid.showAdditionalImages}
            onChange={toggleAdditionalImages}
          />
          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-900"></div>
          <span className="ml-3 text-sm font-medium text-gray-700">
            Include Additional Images
          </span>
        </label>
      </div>
      {bid.showAdditionalImages && (
        <ImageUpload
          images={bid.additionalImages}
          onImagesChange={(images) => setBid({ ...bid, additionalImages: images })}
          maxImages={20}
        />
      )}
    </div>
  );
}