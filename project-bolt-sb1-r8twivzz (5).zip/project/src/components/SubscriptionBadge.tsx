import React from 'react';
import type { SubscriptionTier } from '../types';

interface SubscriptionBadgeProps {
  tier: SubscriptionTier;
  className?: string;
}

export function SubscriptionBadge({ tier, className = '' }: SubscriptionBadgeProps) {
  const colors = {
    free: 'bg-gray-100 text-gray-800',
    pro: 'bg-blue-100 text-blue-800',
    elite: 'bg-purple-100 text-purple-800'
  };

  const labels = {
    free: 'Free',
    pro: 'Pro',
    elite: 'Elite'
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${colors[tier]} ${className}`}>
      {labels[tier]}
    </span>
  );
}