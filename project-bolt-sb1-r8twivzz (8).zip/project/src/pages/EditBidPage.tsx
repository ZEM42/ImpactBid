import React from 'react';
import { useNavigate, useParams, Navigate } from 'react-router-dom';
import BidForm from '../components/BidForm';
import type { Profile, Bid } from '../types';

interface EditBidPageProps {
  profile: Profile;
  bids: Bid[];
  onSave: (bid: Bid) => void;
}

export function EditBidPage({ profile, bids, onSave }: EditBidPageProps) {
  const navigate = useNavigate();
  const { bidId } = useParams();
  const currentBid = bids.find(b => b.id === bidId);

  if (!currentBid) {
    return <Navigate to="/bids" replace />;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Edit Bid</h1>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <BidForm 
          profile={profile} 
          onSave={(bid) => {
            onSave(bid);
            navigate(`/bids/${bid.id}/preview`);
          }}
          existingBid={currentBid}
        />
      </div>
    </div>
  );
}