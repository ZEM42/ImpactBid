import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, Loader2, Save, FileText, Brain } from 'lucide-react';
import type { Profile, AIConversation, Bid } from '../types';
import { useAI } from '../hooks/useAI';
import { useVoice } from '../hooks/useVoice';
import { VoiceInput } from '../components/VoiceInput';

interface AIBidAssistantPageProps {
  profile: Profile;
  onCreateBid: (bid: Bid) => void;
  onSaveConversation: (conversation: AIConversation) => void;
}

export function AIBidAssistantPage({ profile, onCreateBid, onSaveConversation }: AIBidAssistantPageProps) {
  const navigate = useNavigate();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [message, setMessage] = useState('');
  const [hasStartedConversation, setHasStartedConversation] = useState(false);
  const [conversation, setConversation] = useState<AIConversation>({
    id: crypto.randomUUID(),
    messages: [],
    createdAt: new Date()
  });
  
  const { sendMessage, generateBid, isProcessing, error } = useAI(profile);

  const handleVoiceResult = async (transcript: string) => {
    if (!transcript.trim()) return;
    
    // Add user's message to conversation
    const newMessage = {
      id: crypto.randomUUID(),
      role: 'user' as const,
      content: transcript,
      timestamp: new Date()
    };

    setConversation(prev => ({
      ...prev,
      messages: [...prev.messages, newMessage]
    }));

    try {
      const response = await sendMessage(conversation, transcript);
      
      if (response) {
        setConversation(prev => ({
          ...prev,
          messages: [...prev.messages, {
            id: crypto.randomUUID(),
            role: 'assistant',
            content: response.content,
            timestamp: new Date()
          }]
        }));

        // If the response includes a bid, automatically generate it
        if (response.bid) {
          try {
            const generatedBid = await generateBid(conversation);
            onCreateBid(generatedBid);
            onSaveConversation(conversation);
            navigate(`/bids/${generatedBid.id}/preview`);
          } catch (error) {
            console.error('Failed to generate bid:', error);
          }
        }
      }
    } catch (err) {
      console.error('Failed to process message:', err);
    }
  };

  const { isListening, error: voiceError, startListening, stopListening } = useVoice({
    onResult: handleVoiceResult,
    onError: (error) => console.error('Voice Error:', error),
    onStart: () => {
      // Only add the initial message once
      if (!hasStartedConversation) {
        setHasStartedConversation(true);
        setConversation(prev => ({
          ...prev,
          messages: [...prev.messages, {
            id: crypto.randomUUID(),
            role: 'assistant',
            content: "Hi! I'm here to help you create a detailed bid. What kind of project are we working on today?",
            timestamp: new Date()
          }]
        }));
      }
    }
  });

  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversation.messages]);

  const handleSendMessage = async () => {
    if (!message.trim() || isProcessing) return;

    const newMessage = {
      id: crypto.randomUUID(),
      role: 'user' as const,
      content: message.trim(),
      timestamp: new Date()
    };

    setConversation(prev => ({
      ...prev,
      messages: [...prev.messages, newMessage]
    }));
    setMessage('');

    try {
      const response = await sendMessage(conversation, message);
      
      if (response) {
        setConversation(prev => ({
          ...prev,
          messages: [...prev.messages, {
            id: crypto.randomUUID(),
            role: 'assistant',
            content: response.content,
            timestamp: new Date()
          }]
        }));

        if (response.bid) {
          try {
            const generatedBid = await generateBid(conversation);
            onCreateBid(generatedBid);
            onSaveConversation(conversation);
            navigate(`/bids/${generatedBid.id}/preview`);
          } catch (error) {
            console.error('Failed to generate bid:', error);
          }
        }
      }
    } catch (err) {
      console.error('Failed to process message:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => navigate('/profile')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-gray-900">AI Bid Assistant</h1>
            <p className="text-sm text-gray-600 mt-1">
              Describe your project and I'll help you create a professional bid
            </p>
          </div>
          <div className="flex gap-4">
            {conversation.messages.length > 0 && (
              <button
                onClick={async () => {
                  try {
                    const bid = await generateBid(conversation);
                    onCreateBid(bid);
                    onSaveConversation(conversation);
                    navigate(`/bids/${bid.id}/preview`);
                  } catch (err) {
                    console.error('Failed to generate bid:', err);
                  }
                }}
                disabled={isProcessing}
                className="flex items-center px-4 py-2 text-sm font-medium text-white bg-green-600 hover:bg-green-700 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
              >
                <FileText className="w-4 h-4 mr-2" />
                Generate Bid
              </button>
            )}
            <button
              onClick={() => {
                onSaveConversation(conversation);
                navigate('/profile');
              }}
              className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Conversation
            </button>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="h-[calc(100vh-300px)] overflow-y-auto p-6">
            {conversation.messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center text-gray-500">
                <Brain className="w-12 h-12 mb-4" />
                <h3 className="text-lg font-medium mb-2">Let's Create Your Bid</h3>
                <p className="max-w-md mb-6">
                  Click the "Speak" button below to start a conversation, and I'll help you create a detailed bid based on your requirements.
                </p>
                <VoiceInput
                  isListening={isListening}
                  onStart={startListening}
                  onStop={stopListening}
                  error={voiceError}
                />
              </div>
            ) : (
              <>
                {conversation.messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`mb-4 ${
                      msg.role === 'user' ? 'flex justify-end' : 'flex justify-start'
                    }`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-4 ${
                        msg.role === 'user'
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-900'
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{msg.content}</p>
                      <p
                        className={`text-xs mt-1 ${
                          msg.role === 'user' ? 'text-blue-100' : 'text-gray-500'
                        }`}
                      >
                        {new Date(msg.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                ))}
                
                {isListening && (
                  <div className="flex justify-end mb-4">
                    <div className="max-w-[80%] rounded-lg p-4 bg-blue-50 text-blue-900 border border-blue-100">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                        <span className="text-sm text-blue-500">Listening...</span>
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}
            
            {isProcessing && (
              <div className="flex justify-start mb-4">
                <div className="bg-gray-100 rounded-lg p-4">
                  <Loader2 className="w-5 h-5 animate-spin text-gray-600" />
                </div>
              </div>
            )}
            
            {error && (
              <div className="mb-4 p-4 bg-red-50 border-l-4 border-red-500 text-red-700">
                {error}
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          <div className="border-t border-gray-200 p-4">
            <div className="flex gap-4">
              <div className="flex-1 min-h-[44px] flex items-end">
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  placeholder={isListening ? 'Listening...' : 'Type your message or click Speak...'}
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 resize-none"
                  rows={1}
                  disabled={isListening}
                />
              </div>
              
              <div className="flex items-center gap-2">
                <VoiceInput
                  isListening={isListening}
                  onStart={startListening}
                  onStop={stopListening}
                  error={voiceError}
                />
                
                <button
                  onClick={handleSendMessage}
                  disabled={!message.trim() || isProcessing || isListening}
                  className={`flex items-center px-4 py-2 text-sm font-medium text-white rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 h-11 ${
                    !message.trim() || isProcessing || isListening
                      ? 'bg-gray-400 cursor-not-allowed'
                      : 'bg-blue-900 hover:bg-blue-800'
                  }`}
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}