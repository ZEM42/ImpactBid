import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, ArrowLeft } from 'lucide-react';
import type { Profile, SubscriptionTier } from '../types';

interface SubscriptionPageProps {
  profile: Profile;
  onUpdateSubscription: (tier: SubscriptionTier) => void;
}

export function SubscriptionPage({ profile, onUpdateSubscription }: SubscriptionPageProps) {
  const navigate = useNavigate();

  const plans = [
    {
      name: 'Free',
      tier: 'free' as const,
      price: '$0',
      description: 'Get started with basic features',
      features: [
        'Create bids and invoices',
        'Export to PDF',
        'Basic templates',
        'Single user'
      ]
    },
    {
      name: 'Pro',
      tier: 'pro' as const,
      price: '$29',
      description: 'Perfect for growing businesses',
      features: [
        'Everything in Free',
        'Save and edit documents',
        'Change orders',
        'Custom logo',
        'Colored banners',
        'No watermark',
        'Priority email support'
      ]
    },
    {
      name: 'Elite',
      tier: 'elite' as const,
      price: '$49',
      description: 'For businesses that need it all',
      features: [
        'Everything in Pro',
        'Advanced analytics (Coming soon)',
        'Custom templates (Coming soon)',
        'API access (Coming soon)',
        '24/7 phone support (Coming soon)',
        'Early access to new features'
      ]
    }
  ];

  const handleSelectPlan = (tier: SubscriptionTier) => {
    // In a real app, this would open a payment flow
    onUpdateSubscription(tier);
    navigate('/profile');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate('/profile')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Subscription Plans</h1>
            <p className="text-gray-600 mt-1">Choose the plan that best fits your needs</p>
          </div>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.tier}
              className={`relative bg-white rounded-lg shadow-sm border-2 ${
                profile.subscriptionTier === plan.tier
                  ? 'border-blue-500'
                  : 'border-gray-200'
              } p-6`}
            >
              {profile.subscriptionTier === plan.tier && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-blue-500 text-white text-sm font-medium px-3 py-1 rounded-full">
                    Current Plan
                  </span>
                </div>
              )}

              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold text-gray-900">{plan.name}</h2>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                  <span className="text-gray-500 ml-2">/month</span>
                </div>
                <p className="mt-2 text-gray-500">{plan.description}</p>
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="w-5 h-5 text-green-500 mr-2 flex-shrink-0" />
                    <span className="text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => handleSelectPlan(plan.tier)}
                disabled={profile.subscriptionTier === plan.tier}
                className={`w-full px-4 py-2 text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 ${
                  profile.subscriptionTier === plan.tier
                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                    : 'text-white bg-blue-900 hover:bg-blue-800 focus:ring-blue-500'
                }`}
              >
                {profile.subscriptionTier === plan.tier ? 'Current Plan' : 'Select Plan'}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}