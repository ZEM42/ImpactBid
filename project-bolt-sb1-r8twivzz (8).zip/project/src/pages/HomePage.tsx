import React from 'react';
import { FileText, Receipt } from 'lucide-react';
import { Link } from 'react-router-dom';

export function HomePage() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Welcome to ImpactBid</h1>
      
      <div className="grid gap-6 md:grid-cols-2">
        <Link
          to="/bids"
          className="block p-6 bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
        >
          <div className="flex items-center mb-4">
            <FileText className="w-8 h-8 text-blue-900 mr-3" />
            <h2 className="text-xl font-semibold text-gray-900">Bids</h2>
          </div>
          <p className="text-gray-600">
            Create and manage detailed construction bids with scope of work, pricing, and contracts.
          </p>
        </Link>

        <Link
          to="/invoices"
          className="block p-6 bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
        >
          <div className="flex items-center mb-4">
            <Receipt className="w-8 h-8 text-blue-900 mr-3" />
            <h2 className="text-xl font-semibold text-gray-900">Invoices</h2>
          </div>
          <p className="text-gray-600">
            Generate and track invoices, manage payments, and monitor payment status.
          </p>
        </Link>
      </div>
    </div>
  );
}