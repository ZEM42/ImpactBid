import React from 'react';
import { PlusCircle, ArrowLeft, Eye, FileDown, Pencil } from 'lucide-react';
import { useNavigate, Link, useParams, Navigate } from 'react-router-dom';
import type { Invoice, ChangeOrder, Profile } from '../types';
import { generateChangeOrderPdf } from '../utils/pdf/changeOrder/generator';

interface ChangeOrdersPageProps {
  profile: Profile;
  invoices: Invoice[];
  changeOrders: ChangeOrder[];
}

export function ChangeOrdersPage({ profile, invoices, changeOrders }: ChangeOrdersPageProps) {
  const navigate = useNavigate();
  const { invoiceId } = useParams();
  const invoice = invoices.find(i => i.id === invoiceId);

  if (!invoice) {
    return <Navigate to="/invoices" replace />;
  }

  const invoiceChangeOrders = changeOrders.filter(co => co.invoiceId === invoice.id);

  const handleExport = async (changeOrder: ChangeOrder) => {
    await generateChangeOrderPdf(changeOrder, profile);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(`/invoices/${invoice.id}/preview`)}
              className="text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-2xl font-bold text-gray-900">Change Orders</h1>
          </div>
          <Link
            to={`/invoices/${invoice.id}/change-orders/new`}
            className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <PlusCircle className="w-4 h-4 mr-2" />
            New Change Order
          </Link>
        </div>

        {invoiceChangeOrders.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="text-center py-12">
              <h3 className="mt-2 text-sm font-medium text-gray-900">No change orders yet</h3>
              <p className="mt-1 text-sm text-gray-500">Get started by creating a new change order.</p>
            </div>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2">
            {invoiceChangeOrders.map((changeOrder) => (
              <div
                key={changeOrder.id}
                className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Change Order #{changeOrder.id.slice(-4)}
                </h3>
                <p className="text-sm text-gray-500 mb-4">
                  Created on {new Date(changeOrder.createdAt).toLocaleDateString()}
                </p>
                <p className="text-sm text-gray-700 mb-4 line-clamp-3">
                  {changeOrder.projectDescription}
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold text-gray-900">
                    ${changeOrder.lineItems.reduce((sum, item) => {
                      const itemTotal = item.overridePrice !== null
                        ? item.overridePrice
                        : item.tasks.reduce((taskSum, task) => taskSum + (task.price || 0), 0);
                      return sum + itemTotal;
                    }, 0).toFixed(2)}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleExport(changeOrder)}
                      className="flex items-center px-3 py-1 text-sm font-medium text-yellow-600 hover:text-yellow-700"
                    >
                      <FileDown className="w-4 h-4 mr-1" />
                      Export
                    </button>
                    <button
                      onClick={() => navigate(`/invoices/${invoice.id}/change-orders/${changeOrder.id}/edit`)}
                      className="flex items-center px-3 py-1 text-sm font-medium text-gray-600 hover:text-gray-700"
                    >
                      <Pencil className="w-4 h-4 mr-1" />
                      Edit
                    </button>
                    <button
                      onClick={() => navigate(`/invoices/${invoice.id}/change-orders/${changeOrder.id}/preview`)}
                      className="flex items-center px-3 py-1 text-sm font-medium text-blue-900 hover:text-blue-800"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      Preview
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}