import React, { useRef, useEffect, useState } from 'react';
import { useNavigate, useParams, Navigate } from 'react-router-dom';
import { FileDown, ArrowLeft, Edit2 } from 'lucide-react';
import { jsPDF } from 'jspdf';
import type { ChangeOrder, Profile, Invoice } from '../types';
import { generateChangeOrderPdf } from '../utils/pdf/changeOrder/generator';

interface ChangeOrderPreviewPageProps {
  profile: Profile;
  invoices: Invoice[];
  changeOrders: ChangeOrder[];
}

export function ChangeOrderPreviewPage({ profile, invoices, changeOrders }: ChangeOrderPreviewPageProps) {
  const navigate = useNavigate();
  const { invoiceId, changeOrderId } = useParams();
  const changeOrder = changeOrders.find(co => co.id === changeOrderId);
  const invoice = invoices.find(i => i.id === invoiceId);

  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const previousChangeOrderRef = useRef<string>('');

  // Redirect if change order or invoice not found
  if (!changeOrder || !invoice) {
    return <Navigate to="/invoices" replace />;
  }

  useEffect(() => {
    const currentChangeOrderString = JSON.stringify(changeOrder);
    
    if (currentChangeOrderString !== previousChangeOrderRef.current) {
      previousChangeOrderRef.current = currentChangeOrderString;
      
      const generatePreview = async () => {
        try {
          if (pdfUrl) {
            URL.revokeObjectURL(pdfUrl);
          }

          const previewDoc = new jsPDF({
            unit: 'mm',
            format: 'a4',
            putOnlyUsedFonts: true,
            floatPrecision: 16
          });
          
          await generateChangeOrderPdf(changeOrder, profile, previewDoc);
          
          const pdfData = previewDoc.output('bloburi');
          const enhancedPdfUrl = `${pdfData}#toolbar=0&navpanes=0&scrollbar=0&statusbar=0&messages=0`;
          setPdfUrl(enhancedPdfUrl);
        } catch (error) {
          console.error('Error generating PDF preview:', error);
        }
      };

      generatePreview();
    }

    return () => {
      if (pdfUrl) {
        URL.revokeObjectURL(pdfUrl);
      }
    };
  }, [changeOrder, profile, pdfUrl]);

  const handleExport = async () => {
    await generateChangeOrderPdf(changeOrder, profile);
  };

  const handleBack = () => {
    navigate(`/invoices/${invoice.id}/change-orders`);
  };

  const handleEdit = () => {
    navigate(`/invoices/${invoice.id}/change-orders/${changeOrder.id}/edit`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-4">
            <button
              onClick={handleBack}
              className="text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-2xl font-bold text-gray-900">Change Order Preview</h1>
          </div>
          <div className="flex gap-4">
            <button
              onClick={handleEdit}
              className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <Edit2 className="w-4 h-4 mr-2" />
              Edit
            </button>
            <button
              onClick={handleExport}
              className="flex items-center px-4 py-2 text-sm font-medium text-white bg-yellow-600 hover:bg-yellow-700 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500"
            >
              <FileDown className="w-4 h-4 mr-2" />
              Export PDF
            </button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden" style={{ height: 'calc(100vh - 140px)' }}>
          {pdfUrl ? (
            <iframe
              src={pdfUrl}
              className="w-full h-full"
              title="PDF Preview"
              style={{
                border: 'none',
                backgroundColor: 'white'
              }}
            />
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-900"></div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}