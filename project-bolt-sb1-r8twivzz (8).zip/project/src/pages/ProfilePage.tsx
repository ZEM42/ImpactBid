import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusCircle, FileText, Pencil, Trash2, CreditCard, Brain, MessageSquare } from 'lucide-react';
import { ProfileForm } from '../components/ProfileForm';
import { ContractForm } from '../components/ContractForm';
import { SubscriptionBadge } from '../components/SubscriptionBadge';
import type { Profile, Contract } from '../types';

interface ProfilePageProps {
  profile?: Profile;
  onSaveProfile: (profile: Profile) => void;
}

export function ProfilePage({ profile, onSaveProfile }: ProfilePageProps) {
  const navigate = useNavigate();
  const [showContractForm, setShowContractForm] = useState(false);
  const [editingContract, setEditingContract] = useState<Contract | undefined>();

  const handleSaveProfile = (updatedProfile: Profile) => {
    onSaveProfile(updatedProfile);
    navigate('/');
  };

  const handleSaveContract = (contract: Contract) => {
    const updatedProfile = {
      ...profile!,
      contracts: profile?.contracts 
        ? profile.contracts.some(c => c.id === contract.id)
          ? profile.contracts.map(c => c.id === contract.id ? contract : c)
          : [...profile.contracts, contract]
        : [contract]
    };
    onSaveProfile(updatedProfile);
    setShowContractForm(false);
    setEditingContract(undefined);
  };

  const handleDeleteContract = (contractId: string) => {
    if (!profile) return;
    
    const updatedProfile = {
      ...profile,
      contracts: profile.contracts.filter(c => c.id !== contractId)
    };
    onSaveProfile(updatedProfile);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Business Profile</h1>
        <div className="flex items-center gap-4">
          <SubscriptionBadge tier={profile?.subscriptionTier || 'free'} />
          <button
            onClick={() => navigate('/subscription')}
            className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <CreditCard className="w-4 h-4 mr-2" />
            Manage Subscription
          </button>
        </div>
      </div>
      
      {profile?.subscriptionTier === 'elite' && (
        <div className="mb-6 grid grid-cols-2 gap-4">
          <button
            onClick={() => navigate('/ai-training')}
            className="flex items-center justify-center px-4 py-3 text-sm font-medium text-blue-900 bg-blue-50 hover:bg-blue-100 rounded-lg border-2 border-blue-200"
          >
            <Brain className="w-4 h-4 mr-2" />
            Train AI Assistant
          </button>
          <button
            onClick={() => navigate('/ai-assistant')}
            className="flex items-center justify-center px-4 py-3 text-sm font-medium text-blue-900 bg-blue-50 hover:bg-blue-100 rounded-lg border-2 border-blue-200"
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            AI Bid Assistant
          </button>
        </div>
      )}
      
      {showContractForm ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-6">
            {editingContract ? 'Edit Contract' : 'Add New Contract'}
          </h2>
          <ContractForm
            onSave={handleSaveContract}
            onCancel={() => {
              setShowContractForm(false);
              setEditingContract(undefined);
            }}
            existingContract={editingContract}
          />
        </div>
      ) : (
        <>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
            <ProfileForm onSave={handleSaveProfile} initialProfile={profile} />
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-gray-900">Contracts</h2>
              <button
                onClick={() => setShowContractForm(true)}
                className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <PlusCircle className="w-4 h-4 mr-2" />
                Add Contract
              </button>
            </div>

            {profile?.contracts && profile.contracts.length > 0 ? (
              <div className="space-y-4">
                {profile.contracts.map(contract => (
                  <div
                    key={contract.id}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center">
                      <FileText className="w-5 h-5 text-gray-500 mr-3" />
                      <div>
                        <h3 className="text-sm font-medium text-gray-900">
                          {contract.title}
                        </h3>
                        <p className="text-sm text-gray-500">
                          Added {new Date(contract.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => {
                          setEditingContract(contract);
                          setShowContractForm(true);
                        }}
                        className="p-2 text-gray-500 hover:text-blue-900"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteContract(contract.id)}
                        className="p-2 text-gray-500 hover:text-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-lg">
                <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-sm font-medium text-gray-900">No contracts yet</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Add your first contract to include in your bids
                </p>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}