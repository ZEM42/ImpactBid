import React, { useRef, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Edit2, FileDown, Receipt } from 'lucide-react';
import jsPDF from 'jspdf';
import type { Bid, Profile, Invoice } from '../types';
import { generatePdf } from '../utils/generatePdf';

interface BidPreviewPageProps {
  profile: Profile;
  bids: Bid[];
  invoices: Invoice[];
  onCreateInvoice: (invoice: Invoice) => void;
}

export function BidPreviewPage({ profile, bids, invoices, onCreateInvoice }: BidPreviewPageProps) {
  const navigate = useNavigate();
  const { bidId } = useParams();
  const bid = bids.find(b => b.id === bidId);
  const existingInvoice = invoices.find(i => i.bidId === bidId);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const previousBidRef = useRef<string>('');

  useEffect(() => {
    if (!bid) {
      navigate('/bids');
      return;
    }

    const currentBidString = JSON.stringify(bid);
    
    if (currentBidString !== previousBidRef.current) {
      previousBidRef.current = currentBidString;
      
      const generatePreview = async () => {
        try {
          if (pdfUrl) {
            URL.revokeObjectURL(pdfUrl);
          }

          const previewDoc = new jsPDF({
            unit: 'mm',
            format: 'a4',
            putOnlyUsedFonts: true,
            floatPrecision: 16
          });
          
          await generatePdf(bid, profile, previewDoc);
          
          const pdfData = previewDoc.output('bloburi');
          const enhancedPdfUrl = `${pdfData}#toolbar=0&navpanes=0&scrollbar=0&statusbar=0&messages=0`;
          setPdfUrl(enhancedPdfUrl);
        } catch (error) {
          console.error('Error generating PDF preview:', error);
        }
      };

      generatePreview();
    }

    return () => {
      if (pdfUrl) {
        URL.revokeObjectURL(pdfUrl);
      }
    };
  }, [bid, profile, pdfUrl, navigate]);

  const handleExport = async () => {
    if (!bid) return;
    await generatePdf(bid, profile);
  };

  const handleEdit = () => {
    if (!bid) return;
    navigate(`/bids/${bid.id}/edit`);
  };

  const handleInvoiceAction = () => {
    if (!bid) return;
    
    if (existingInvoice) {
      navigate(`/invoices/${existingInvoice.id}/preview`);
      return;
    }

    const invoice: Invoice = {
      id: crypto.randomUUID(),
      bidId: bid.id,
      clientName: bid.clientName,
      clientAddress: bid.clientAddress,
      projectDescription: bid.projectDescription,
      lineItems: bid.lineItems,
      applyTax: bid.applyTax,
      createdAt: new Date(),
      status: 'draft',
      invoiceNumber: `INV-${new Date().getFullYear()}-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`,
      notes: '',
      additionalImages: [],
      showAdditionalImages: false,
      hasPaymentPlan: true,
      payments: bid.payments.map(p => ({
        ...p,
        status: 'upcoming',
        includeDueDate: false,
        dueDate: null,
        paidDate: null
      }))
    };

    onCreateInvoice(invoice);
    navigate(`/invoices/${invoice.id}/preview`);
  };

  if (!bid) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Bid Preview</h1>
          <div className="flex gap-4">
            <button
              onClick={handleInvoiceAction}
              className={`flex items-center px-4 py-2 text-sm font-medium text-white rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 ${
                existingInvoice
                  ? 'bg-green-600 hover:bg-green-700 focus:ring-green-500'
                  : 'bg-blue-900 hover:bg-blue-800 focus:ring-blue-500'
              }`}
            >
              <Receipt className="w-4 h-4 mr-2" />
              {existingInvoice ? 'View Invoice' : 'Create Invoice'}
            </button>
            <button
              onClick={handleEdit}
              className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <Edit2 className="w-4 h-4 mr-2" />
              Edit Bid
            </button>
            <button
              onClick={handleExport}
              className="flex items-center px-4 py-2 text-sm font-medium text-white bg-yellow-600 hover:bg-yellow-700 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500"
            >
              <FileDown className="w-4 h-4 mr-2" />
              Export PDF
            </button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden" style={{ height: 'calc(100vh - 140px)' }}>
          {pdfUrl ? (
            <iframe
              src={pdfUrl}
              className="w-full h-full"
              title="PDF Preview"
              style={{
                border: 'none',
                backgroundColor: 'white'
              }}
            />
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-900"></div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}