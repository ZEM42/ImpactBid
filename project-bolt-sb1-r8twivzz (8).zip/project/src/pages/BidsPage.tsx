import React from 'react';
import { PlusCircle, Eye } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Bid } from '../types';
import { useSubscription } from '../hooks/useSubscription';
import { SubscriptionModal } from '../components/SubscriptionModal';

interface BidsPageProps {
  bids: Bid[];
  profile: Profile;
}

export function BidsPage({ bids, profile }: BidsPageProps) {
  const { showUpgradeModal, hideUpgradeModal, isModalOpen, modalFeature, modalRequiredTier, checkFeatureAccess } = useSubscription();

  const canCreateNewBid = profile.subscriptionTier !== 'free' || bids.length === 0;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Your Bids</h1>
        {canCreateNewBid ? (
          <Link
            to="/new-bid"
            className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <PlusCircle className="w-4 h-4 mr-2" />
            Create New Bid
          </Link>
        ) : (
          <button
            onClick={() => showUpgradeModal('Multiple Bids', 'pro')}
            className="flex items-center px-4 py-2 text-sm font-medium text-gray-500 bg-gray-100 rounded-md cursor-not-allowed"
          >
            <PlusCircle className="w-4 h-4 mr-2" />
            Create New Bid
            <span className="ml-2 text-xs bg-gray-200 text-gray-600 px-1.5 py-0.5 rounded">
              Pro
            </span>
          </button>
        )}
      </div>

      {bids.length === 0 ? (
        <div className="text-center py-12">
          <h3 className="mt-2 text-sm font-medium text-gray-900">No bids yet</h3>
          <p className="mt-1 text-sm text-gray-500">Get started by creating a new bid.</p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {bids.map((bid, index) => (
            <div
              key={bid.id}
              className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
            >
              <h3 className="text-lg font-medium text-gray-900 mb-2">{bid.clientName}</h3>
              <p className="text-sm text-gray-500 mb-4">
                Created on {new Date(bid.createdAt).toLocaleDateString()}
              </p>
              <p className="text-sm text-gray-700 mb-4 line-clamp-3">{bid.projectDescription}</p>
              <div className="flex justify-between items-center">
                <span className="text-lg font-bold text-gray-900">
                  ${bid.lineItems.reduce((sum, item) => {
                    const itemTotal = item.overridePrice !== null
                      ? item.overridePrice
                      : item.tasks.reduce((taskSum, task) => taskSum + (task.price || 0), 0);
                    return sum + itemTotal;
                  }, 0).toFixed(2)}
                </span>
                <Link
                  to={`/bids/${bid.id}/preview`}
                  className="flex items-center text-blue-900 hover:text-blue-800 font-medium text-sm"
                >
                  <Eye className="w-4 h-4 mr-1" />
                  Preview
                </Link>
              </div>
              {profile.subscriptionTier === 'free' && index > 0 && (
                <div className="mt-4 text-center text-sm text-gray-500">
                  Upgrade to Pro to edit this bid
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <SubscriptionModal
        isOpen={isModalOpen}
        onClose={hideUpgradeModal}
        feature={modalFeature}
        requiredTier={modalRequiredTier}
      />
    </div>
  );
}