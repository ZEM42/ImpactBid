import React, { useRef, useEffect, useState } from 'react';
import { useNavigate, useParams, Navigate } from 'react-router-dom';
import { Edit2, FileDown, ClipboardList } from 'lucide-react';
import { jsPDF } from 'jspdf';
import type { Invoice, Profile, ChangeOrder } from '../types';
import { generateInvoicePdf } from '../utils/pdf/invoice/generator';
import { useSubscription } from '../hooks/useSubscription';
import { SubscriptionModal } from '../components/SubscriptionModal';

interface InvoicePreviewPageProps {
  profile: Profile;
  invoices: Invoice[];
  changeOrders: ChangeOrder[];
}

export function InvoicePreviewPage({ profile, invoices, changeOrders }: InvoicePreviewPageProps) {
  const navigate = useNavigate();
  const { invoiceId } = useParams();
  const invoice = invoices.find(i => i.id === invoiceId);
  const invoiceIndex = invoices.findIndex(i => i.id === invoiceId);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const previousInvoiceRef = useRef<string>('');
  const { showUpgradeModal, hideUpgradeModal, isModalOpen, modalFeature, modalRequiredTier, checkFeatureAccess } = useSubscription();

  useEffect(() => {
    if (!invoice) {
      navigate('/invoices');
      return;
    }

    const currentInvoiceString = JSON.stringify({ invoice, changeOrders });
    
    if (currentInvoiceString !== previousInvoiceRef.current) {
      previousInvoiceRef.current = currentInvoiceString;
      
      const generatePreview = async () => {
        try {
          if (pdfUrl) {
            URL.revokeObjectURL(pdfUrl);
          }

          const previewDoc = new jsPDF({
            unit: 'mm',
            format: 'a4',
            putOnlyUsedFonts: true,
            floatPrecision: 16
          });
          
          await generateInvoicePdf(invoice, profile, changeOrders, previewDoc);
          
          const pdfData = previewDoc.output('bloburi');
          const enhancedPdfUrl = `${pdfData}#toolbar=0&navpanes=0&scrollbar=0&statusbar=0&messages=0`;
          setPdfUrl(enhancedPdfUrl);
        } catch (error) {
          console.error('Error generating PDF preview:', error);
        }
      };

      generatePreview();
    }

    return () => {
      if (pdfUrl) {
        URL.revokeObjectURL(pdfUrl);
      }
    };
  }, [invoice, profile, pdfUrl, navigate, changeOrders]);

  const handleExport = async () => {
    if (!invoice) return;
    await generateInvoicePdf(invoice, profile, changeOrders);
  };

  const handleEdit = () => {
    if (!checkFeatureAccess('Edit Documents', 'pro', profile.subscriptionTier, { isFirstItem: invoiceIndex === 0 })) {
      showUpgradeModal('Edit Documents', 'pro');
      return;
    }
    if (!invoice) return;
    navigate(`/invoices/${invoice.id}/edit`);
  };

  const handleChangeOrders = () => {
    if (!checkFeatureAccess('Change Orders', 'pro', profile.subscriptionTier)) {
      showUpgradeModal('Change Orders', 'pro');
      return;
    }
    if (!invoice) return;
    navigate(`/invoices/${invoice.id}/change-orders`);
  };

  if (!invoice) return null;

  const canEdit = profile.subscriptionTier !== 'free' || invoiceIndex === 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Invoice Preview</h1>
          <div className="flex gap-4">
            <button
              onClick={handleChangeOrders}
              className={`flex items-center px-4 py-2 text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 ${
                profile.subscriptionTier !== 'free'
                  ? 'text-white bg-purple-600 hover:bg-purple-700 focus:ring-purple-500'
                  : 'text-gray-500 bg-gray-100 cursor-not-allowed'
              }`}
            >
              <ClipboardList className="w-4 h-4 mr-2" />
              Change Orders
              {profile.subscriptionTier === 'free' && (
                <span className="ml-2 text-xs bg-gray-200 text-gray-600 px-1.5 py-0.5 rounded">
                  Pro
                </span>
              )}
            </button>
            <button
              onClick={handleEdit}
              className={`flex items-center px-4 py-2 text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 ${
                canEdit
                  ? 'text-white bg-blue-900 hover:bg-blue-800 focus:ring-blue-500'
                  : 'text-gray-500 bg-gray-100 cursor-not-allowed'
              }`}
            >
              <Edit2 className="w-4 h-4 mr-2" />
              Edit Invoice
              {!canEdit && (
                <span className="ml-2 text-xs bg-gray-200 text-gray-600 px-1.5 py-0.5 rounded">
                  Pro
                </span>
              )}
            </button>
            <button
              onClick={handleExport}
              className="flex items-center px-4 py-2 text-sm font-medium text-white bg-yellow-600 hover:bg-yellow-700 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500"
            >
              <FileDown className="w-4 h-4 mr-2" />
              Export PDF
            </button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden" style={{ height: 'calc(100vh - 140px)' }}>
          {pdfUrl ? (
            <iframe
              src={pdfUrl}
              className="w-full h-full"
              title="PDF Preview"
              style={{
                border: 'none',
                backgroundColor: 'white'
              }}
            />
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-900"></div>
            </div>
          )}
        </div>
      </div>

      <SubscriptionModal
        isOpen={isModalOpen}
        onClose={hideUpgradeModal}
        feature={modalFeature}
        requiredTier={modalRequiredTier}
      />
    </div>
  );
}