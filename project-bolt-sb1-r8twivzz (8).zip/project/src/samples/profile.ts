export const sampleProfile = {
  businessName: "ZEM Construction",
  logo: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=200&auto=format&fit=crop&q=80",
  businessAddress: "3128 W Hoffman Ave.\nSpokane, WA 99205",
  licenseNumber: "ZEMCOC*89104154",
  taxRate: 8.9,
  defaultShowScopePrices: true,
  defaultShowTaskPrices: true,
  email: "info@zemconstruction.com",
  website: "www.zemconstruction.com",
  primaryColor: "#1A365D",
  secondaryColor: "#4A5568",
  name: "John Smith",
  contracts: [],
  showBanners: true,
  subscriptionTier: 'free' as const
};