export const sampleChangeOrder = {
  id: crypto.randomUUID(),
  invoiceId: crypto.randomUUID(),
  clientName: "John & Sarah Thompson",
  clientAddress: "4521 Pine Valley Drive\nSpokane, WA 99223",
  projectDescription: "Addition of custom built-in shelving units in the home office and upgrade of bathroom fixtures to premium finishes.",
  lineItems: [
    {
      id: crypto.randomUUID(),
      scopeName: "Custom Built-in Shelving",
      tasks: [
        { id: crypto.randomUUID(), description: "Design and fabricate custom hardwood shelving units", price: 3800 },
        { id: crypto.randomUUID(), description: "Install LED accent lighting in shelves", price: 600 },
        { id: crypto.randomUUID(), description: "Paint and finish to match existing trim", price: 900 }
      ],
      overridePrice: null,
      showPrices: true,
      showTaskPrices: true,
      images: [],
      showImages: false
    },
    {
      id: crypto.randomUUID(),
      scopeName: "Bathroom Upgrades",
      tasks: [
        { id: crypto.randomUUID(), description: "Upgrade to premium faucets and fixtures", price: 1200 },
        { id: crypto.randomUUID(), description: "Install custom frameless shower door", price: 1800 },
        { id: crypto.randomUUID(), description: "Upgrade tile to premium porcelain", price: 2400 }
      ],
      overridePrice: null,
      showPrices: true,
      showTaskPrices: true,
      images: [],
      showImages: false
    }
  ],
  applyTax: true,
  notes: "Changes requested by client during construction phase to enhance office functionality and bathroom aesthetics.",
  additionalImages: [],
  showAdditionalImages: false,
  createdAt: new Date(),
  showClientSignature: false,
  showMySignature: false
};