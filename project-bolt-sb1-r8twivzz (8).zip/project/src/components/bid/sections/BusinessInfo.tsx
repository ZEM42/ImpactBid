import React from 'react';
import type { Profile } from '../../../types';

interface BusinessInfoProps {
  profile: Profile;
}

export function BusinessInfo({ profile }: BusinessInfoProps) {
  return (
    <div className="bg-gray-50 p-4 rounded-lg">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Business Information</h3>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-sm font-medium text-gray-500">Business Name</p>
          <p className="mt-1">{profile.businessName}</p>
        </div>
        <div>
          <p className="text-sm font-medium text-gray-500">License Number</p>
          <p className="mt-1">{profile.licenseNumber}</p>
        </div>
        <div className="col-span-2">
          <p className="text-sm font-medium text-gray-500">Business Address</p>
          <p className="mt-1 whitespace-pre-line">{profile.businessAddress}</p>
        </div>
      </div>
    </div>
  );
}