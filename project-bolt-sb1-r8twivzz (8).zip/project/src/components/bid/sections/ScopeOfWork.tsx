import React, { useRef } from 'react';
import { PlusCircle, Trash2 } from 'lucide-react';
import type { Bid, LineItem, Task, Profile } from '../../../types';
import { ImageUpload } from '../../ImageUpload';

interface ScopeOfWorkProps {
  bid: Omit<Bid, 'id' | 'createdAt'>;
  setBid: React.Dispatch<React.SetStateAction<Omit<Bid, 'id' | 'createdAt'>>>;
  profile: Profile;
}

export function ScopeOfWork({ bid, setBid, profile }: ScopeOfWorkProps) {
  const taskInputRefs = useRef<{ [key: string]: HTMLInputElement }>({});

  const addScope = () => {
    const newScope: LineItem = {
      id: crypto.randomUUID(),
      scopeName: '',
      tasks: [],
      overridePrice: null,
      showPrices: profile.defaultShowScopePrices,
      showTaskPrices: profile.defaultShowTaskPrices,
      images: [],
      showImages: false
    };
    setBid({ ...bid, lineItems: [...bid.lineItems, newScope] });
  };

  const removeScope = (scopeId: string) => {
    setBid({
      ...bid,
      lineItems: bid.lineItems.filter((item) => item.id !== scopeId),
    });
  };

  const addTask = (scopeId: string, focusTaskId?: string) => {
    const newTask: Task = {
      id: crypto.randomUUID(),
      description: '',
      price: null,
    };
    setBid({
      ...bid,
      lineItems: bid.lineItems.map((item) =>
        item.id === scopeId
          ? { ...item, tasks: [...item.tasks, newTask] }
          : item
      ),
    });

    if (focusTaskId) {
      setTimeout(() => {
        const inputRef = taskInputRefs.current[newTask.id];
        if (inputRef) {
          inputRef.focus();
        }
      }, 0);
    }
  };

  const removeTask = (scopeId: string, taskId: string) => {
    setBid({
      ...bid,
      lineItems: bid.lineItems.map((item) =>
        item.id === scopeId
          ? { ...item, tasks: item.tasks.filter((task) => task.id !== taskId) }
          : item
      ),
    });
  };

  const updateScope = (scopeId: string, updates: Partial<LineItem>) => {
    setBid({
      ...bid,
      lineItems: bid.lineItems.map((item) =>
        item.id === scopeId ? { ...item, ...updates } : item
      ),
    });
  };

  const updateTask = (scopeId: string, taskId: string, updates: Partial<Task>) => {
    setBid({
      ...bid,
      lineItems: bid.lineItems.map((item) =>
        item.id === scopeId
          ? {
              ...item,
              tasks: item.tasks.map((task) =>
                task.id === taskId ? { ...task, ...updates } : task
              ),
            }
          : item
      ),
    });
  };

  const toggleTaskPrices = (scopeId: string) => {
    setBid({
      ...bid,
      lineItems: bid.lineItems.map((item) =>
        item.id === scopeId
          ? { ...item, showTaskPrices: !item.showTaskPrices }
          : item
      ),
    });
  };

  const toggleScopePrices = (scopeId: string) => {
    setBid({
      ...bid,
      lineItems: bid.lineItems.map((item) =>
        item.id === scopeId
          ? {
              ...item,
              showPrices: !item.showPrices,
              showTaskPrices: !item.showPrices ? false : item.showTaskPrices
            }
          : item
      ),
    });
  };

  const toggleScopeImages = (scopeId: string) => {
    setBid({
      ...bid,
      lineItems: bid.lineItems.map((item) =>
        item.id === scopeId ? { ...item, showImages: !item.showImages } : item
      ),
    });
  };

  const getScopeTotal = (scope: LineItem) => {
    if (scope.overridePrice !== null) {
      return scope.overridePrice;
    }
    return scope.tasks.reduce((sum, task) => sum + (task.price || 0), 0);
  };

  const subtotal = bid.lineItems.reduce((sum, item) => sum + getScopeTotal(item), 0);
  const tax = bid.applyTax ? subtotal * (profile.taxRate / 100) : 0;
  const total = subtotal + tax;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900">Scope of Work</h3>
        <button
          type="button"
          onClick={addScope}
          className="flex items-center px-3 py-2 text-sm font-medium text-blue-900 hover:text-blue-800"
        >
          <PlusCircle className="w-4 h-4 mr-2" />
          Add Scope
        </button>
      </div>

      <div className="space-y-6">
        {bid.lineItems.map((scope) => (
          <div key={scope.id} className="bg-gray-50 p-4 rounded-lg">
            <div className="flex gap-4 items-start mb-4">
              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Scope Name
                </label>
                <input
                  type="text"
                  value={scope.scopeName}
                  onChange={(e) => updateScope(scope.id, { scopeName: e.target.value })}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
              <button
                type="button"
                onClick={() => removeScope(scope.id)}
                className="p-2 text-red-600 hover:text-red-800"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium text-gray-700">Tasks</h4>
                <button
                  type="button"
                  onClick={() => addTask(scope.id)}
                  className="flex items-center px-2 py-1 text-sm text-blue-900 hover:text-blue-800"
                >
                  <PlusCircle className="w-4 h-4 mr-1" />
                  Add Task
                </button>
              </div>

              {scope.tasks.map((task) => (
                <div key={task.id} className="flex gap-4 items-start bg-white p-3 rounded-md">
                  <div className="flex-1">
                    <input
                      type="text"
                      value={task.description}
                      onChange={(e) =>
                        updateTask(scope.id, task.id, { description: e.target.value })
                      }
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          addTask(scope.id, task.id);
                        }
                      }}
                      ref={el => {
                        if (el) taskInputRefs.current[task.id] = el;
                      }}
                      placeholder="Task description"
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      required
                    />
                  </div>
                  <div className="w-32">
                    <input
                      type="number"
                      value={task.price || ''}
                      onChange={(e) =>
                        updateTask(scope.id, task.id, {
                          price: e.target.value === '' ? null : parseFloat(e.target.value)
                        })
                      }
                      placeholder="Price"
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      min="0"
                      disabled={scope.overridePrice !== null}
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => removeTask(scope.id, task.id)}
                    className="p-2 text-red-600 hover:text-red-800"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            <div className="mt-4 border-t border-gray-200 pt-4">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Override Scope Price
                  </label>
                  <div className="flex gap-4 items-center">
                    <input
                      type="number"
                      value={scope.overridePrice ?? ''}
                      onChange={(e) => {
                        const value = e.target.value;
                        updateScope(scope.id, {
                          overridePrice: value === '' ? null : parseFloat(value)
                        });
                      }}
                      placeholder="Enter total scope price"
                      className="block w-48 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      min="0"
                    />
                    {scope.overridePrice !== null && (
                      <button
                        type="button"
                        onClick={() => updateScope(scope.id, { overridePrice: null })}
                        className="text-sm text-red-600 hover:text-red-800"
                      >
                        Clear Override
                      </button>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-lg font-medium text-gray-900">
                    ${getScopeTotal(scope).toFixed(2)}
                  </p>
                </div>
              </div>

              <div className="mt-4 flex items-center justify-end space-x-6">
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={scope.showPrices}
                    onChange={() => toggleScopePrices(scope.id)}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-900"></div>
                  <span className="ml-3 text-sm font-medium text-gray-700">
                    Show scope pricing in PDF
                  </span>
                </label>

                <label className={`relative inline-flex items-center ${scope.showPrices ? 'cursor-pointer' : 'cursor-not-allowed opacity-50'}`}>
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={scope.showTaskPrices}
                    disabled={!scope.showPrices}
                    onChange={() => toggleTaskPrices(scope.id)}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-900"></div>
                  <span className="ml-3 text-sm font-medium text-gray-700">
                    Show task pricing in PDF
                  </span>
                </label>
              </div>

              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-sm font-medium text-gray-700">Scope Images</h4>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      className="sr-only peer"
                      checked={scope.showImages}
                      onChange={() => toggleScopeImages(scope.id)}
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-900"></div>
                    <span className="ml-3 text-sm font-medium text-gray-700">
                      Include Images
                    </span>
                  </label>
                </div>
                {scope.showImages && (
                  <ImageUpload
                    images={scope.images || []}
                    onImagesChange={(images) => updateScope(scope.id, { images })}
                    maxImages={4}
                    className="mb-4"
                  />
                )}
              </div>
            </div>
          </div>
        ))}

        {/* Add bottom "Add Scope" button if there are existing scopes */}
        {bid.lineItems.length > 0 && (
          <button
            type="button"
            onClick={addScope}
            className="w-full flex items-center justify-center px-4 py-3 text-sm font-medium text-blue-900 hover:text-blue-800 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300 hover:border-blue-500 hover:bg-gray-100 transition-colors"
          >
            <PlusCircle className="w-4 h-4 mr-2" />
            Add Another Scope
          </button>
        )}
      </div>

      <div className="flex gap-4 items-center mt-6">
        <div className="flex items-center">
          <input
            type="checkbox"
            id="applyTax"
            checked={bid.applyTax}
            onChange={(e) => setBid({ ...bid, applyTax: e.target.checked })}
            className="h-4 w-4 text-blue-900 focus:ring-blue-500 border-gray-300 rounded"
          />
          <label htmlFor="applyTax" className="ml-2 block text-sm text-gray-700">
            Apply Tax ({profile.taxRate}%)
          </label>
        </div>
        <div className="flex-1 space-y-1 text-right">
          <p className="text-sm font-medium text-gray-500">Subtotal: ${subtotal.toFixed(2)}</p>
          {bid.applyTax && (
            <p className="text-sm font-medium text-gray-500">
              Tax ({profile.taxRate}%): ${tax.toFixed(2)}
            </p>
          )}
          <p className="text-lg font-bold">Total: ${total.toFixed(2)}</p>
        </div>
      </div>
    </div>
  );
}