import React, { useRef, useState } from 'react';
import { PlusCircle, Trash2, AlertTriangle } from 'lucide-react';
import type { Bid, Payment } from '../../../types';

interface PaymentSectionProps {
  bid: Omit<Bid, 'id' | 'createdAt'>;
  setBid: React.Dispatch<React.SetStateAction<Omit<Bid, 'id' | 'createdAt'>>>;
  profile: { taxRate: number };
}

export function PaymentSection({ bid, setBid, profile }: PaymentSectionProps) {
  const [paymentWarning, setPaymentWarning] = useState<string | null>(null);
  const paymentInputRefs = useRef<{ [key: string]: HTMLInputElement }>({});

  const addPayment = (focusPaymentId?: string) => {
    const currentPayments = bid.payments;
    const newPaymentNumber = currentPayments.length + 1;
    
    const newPayment: Payment = {
      id: crypto.randomUUID(),
      label: `Payment ${newPaymentNumber}`,
      amount: null,
      percentage: null
    };
    
    setBid({
      ...bid,
      payments: [...currentPayments, newPayment]
    });

    if (focusPaymentId) {
      setTimeout(() => {
        const inputRef = paymentInputRefs.current[newPayment.id];
        if (inputRef) {
          inputRef.focus();
        }
      }, 0);
    }
  };

  const removePayment = (paymentId: string) => {
    const updatedPayments = bid.payments.filter(payment => payment.id !== paymentId);
    
    const relabeledPayments = updatedPayments.map((payment, index) => {
      if (index === 0) {
        return { ...payment, label: 'Deposit' };
      }
      return { ...payment, label: `Payment ${index + 1}` };
    });

    setBid({
      ...bid,
      payments: relabeledPayments
    });
  };

  const updatePayment = (paymentId: string, updates: Partial<Payment>) => {
    const updatedPayments = bid.payments.map(payment =>
      payment.id === paymentId ? { ...payment, ...updates } : payment
    );

    const totalPercentage = updatedPayments.reduce((sum, payment) => 
      sum + (payment.percentage || 0), 0
    );

    if (totalPercentage === 100) {
      updatedPayments[updatedPayments.length - 1] = {
        ...updatedPayments[updatedPayments.length - 1],
        label: 'Final'
      };
    } else {
      setPaymentWarning(null);
      const lastPayment = updatedPayments[updatedPayments.length - 1];
      if (lastPayment.label === 'Final') {
        lastPayment.label = `Payment ${updatedPayments.length}`;
      }
    }

    setBid({
      ...bid,
      payments: updatedPayments
    });
  };

  // Calculate total for payment amounts
  const subtotal = bid.lineItems.reduce((sum, item) => {
    return sum + (item.overridePrice ?? item.tasks.reduce((taskSum, task) => taskSum + (task.price || 0), 0));
  }, 0);
  const tax = bid.applyTax ? subtotal * (profile.taxRate / 100) : 0;
  const total = subtotal + tax;

  return (
    <div className="border-t border-gray-200 pt-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <input
            type="checkbox"
            id="hasPaymentPlan"
            checked={bid.hasPaymentPlan}
            onChange={(e) => setBid({ ...bid, hasPaymentPlan: e.target.checked })}
            className="h-4 w-4 text-blue-900 focus:ring-blue-500 border-gray-300 rounded"
          />
          <label htmlFor="hasPaymentPlan" className="ml-2 block text-sm text-gray-700">
            Include Payment Schedule
          </label>
        </div>
      </div>

      {bid.hasPaymentPlan && (
        <div className="space-y-4">
          {paymentWarning && (
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
              <div className="flex items-center">
                <AlertTriangle className="h-5 w-5 text-yellow-400" />
                <p className="ml-3 text-sm text-yellow-700">{paymentWarning}</p>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between">
            <h4 className="text-sm font-medium text-gray-700">Payment Schedule</h4>
            <button
              type="button"
              onClick={() => addPayment()}
              className="flex items-center px-2 py-1 text-sm text-blue-900 hover:text-blue-800"
            >
              <PlusCircle className="w-4 h-4 mr-1" />
              Add Payment
            </button>
          </div>

          {bid.payments.map((payment, index) => (
            <div key={payment.id} className="grid grid-cols-3 gap-4 items-start bg-white p-4 rounded-md">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Label
                </label>
                <input
                  type="text"
                  value={payment.label}
                  onChange={(e) => updatePayment(payment.id, { label: e.target.value })}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                  disabled={index === 0 || payment.label === 'Final'}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Percentage
                </label>
                <input
                  type="number"
                  value={payment.percentage || ''}
                  onChange={(e) => {
                    const value = e.target.value;
                    const percentage = value === '' ? null : parseFloat(value);
                    const amount = percentage ? (total * percentage / 100) : null;
                    updatePayment(payment.id, {
                      percentage,
                      amount
                    });
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addPayment(payment.id);
                    }
                  }}
                  ref={el => {
                    if (el) paymentInputRefs.current[payment.id] = el;
                  }}
                  placeholder="Enter percentage"
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  min="0"
                  max="100"
                  step="0.1"
                />
              </div>
              <div className="flex items-start gap-2">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Amount
                  </label>
                  <input
                    type="number"
                    value={payment.amount?.toFixed(2) || ''}
                    onChange={(e) => {
                      const value = e.target.value;
                      updatePayment(payment.id, {
                        amount: value === '' ? null : parseFloat(value),
                        percentage: null
                      });
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addPayment(payment.id);
                      }
                    }}
                    placeholder="Enter amount"
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    min="0"
                    step="0.01"
                  />
                </div>
                {index > 0 && payment.label !== 'Final' && (
                  <button
                    type="button"
                    onClick={() => removePayment(payment.id)}
                    className="mt-7 p-2 text-red-600 hover:text-red-800"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}