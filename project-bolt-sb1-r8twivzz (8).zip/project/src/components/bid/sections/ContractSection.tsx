import React from 'react';
import type { Bid, Profile } from '../../../types';

interface ContractSectionProps {
  bid: Omit<Bid, 'id' | 'createdAt'>;
  setBid: React.Dispatch<React.SetStateAction<Omit<Bid, 'id' | 'createdAt'>>>;
  profile: Profile;
}

export function ContractSection({ bid, setBid, profile }: ContractSectionProps) {
  return (
    <div className="border-t border-gray-200 pt-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900">Contract</h3>
        <label className="relative inline-flex items-center cursor-pointer">
          <input
            type="checkbox"
            className="sr-only peer"
            checked={bid.showContract}
            onChange={(e) => setBid({ ...bid, showContract: e.target.checked })}
          />
          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-900"></div>
          <span className="ml-3 text-sm font-medium text-gray-700">
            Include Contract
          </span>
        </label>
      </div>
      {bid.showContract && (
        <div className="space-y-4">
          <div>
            <label htmlFor="contractId" className="block text-sm font-medium text-gray-700">
              Select Contract
            </label>
            <select
              id="contractId"
              value={bid.contractId || ''}
              onChange={(e) => setBid({ ...bid, contractId: e.target.value || null })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required={bid.showContract}
            >
              <option value="">Select a contract...</option>
              {profile.contracts.map(contract => (
                <option key={contract.id} value={contract.id}>
                  {contract.title}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}
    </div>
  );
}