import React, { useState } from 'react';
import { Save } from 'lucide-react';
import type { Contract } from '../types';

interface ContractFormProps {
  onSave: (contract: Contract) => void;
  onCancel: () => void;
  existingContract?: Contract;
}

export function ContractForm({ onSave, onCancel, existingContract }: ContractFormProps) {
  const [contract, setContract] = useState<Omit<Contract, 'id' | 'createdAt'>>({
    title: existingContract?.title || '',
    content: existingContract?.content || ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...contract,
      id: existingContract?.id || crypto.randomUUID(),
      createdAt: existingContract?.createdAt || new Date()
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="title" className="block text-sm font-medium text-gray-700">
          Contract Title
        </label>
        <input
          type="text"
          id="title"
          value={contract.title}
          onChange={(e) => setContract({ ...contract, title: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          required
          placeholder="e.g., Standard Service Agreement"
        />
      </div>

      <div>
        <label htmlFor="content" className="block text-sm font-medium text-gray-700">
          Contract Content
        </label>
        <textarea
          id="content"
          value={contract.content}
          onChange={(e) => setContract({ ...contract, content: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          rows={20}
          required
          placeholder="Enter your contract text here..."
        />
      </div>

      <div className="flex justify-end space-x-4">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          <Save className="w-4 h-4 mr-2" />
          Save Contract
        </button>
      </div>
    </form>
  );
}