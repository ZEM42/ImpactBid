import React from 'react';
import { Building2, Home, FileText, Receipt } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

export function Navigation() {
  const location = useLocation();
  
  return (
    <nav className="bg-blue-900 text-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            <Link to="/" className="flex items-center space-x-2 font-bold text-xl">
              <Building2 className="text-yellow-400" />
              <span>ImpactBid</span>
            </Link>
            
            <div className="flex space-x-4">
              <Link
                to="/"
                className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium ${
                  location.pathname === '/' 
                    ? 'bg-blue-800 text-white'
                    : 'text-gray-300 hover:bg-blue-800 hover:text-white'
                }`}
              >
                <Home size={18} />
                <span>Home</span>
              </Link>
              
              <Link
                to="/bids"
                className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium ${
                  location.pathname.startsWith('/bids')
                    ? 'bg-blue-800 text-white'
                    : 'text-gray-300 hover:bg-blue-800 hover:text-white'
                }`}
              >
                <FileText size={18} />
                <span>Bids</span>
              </Link>

              <Link
                to="/invoices"
                className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium ${
                  location.pathname.startsWith('/invoices')
                    ? 'bg-blue-800 text-white'
                    : 'text-gray-300 hover:bg-blue-800 hover:text-white'
                }`}
              >
                <Receipt size={18} />
                <span>Invoices</span>
              </Link>
              
              <Link
                to="/profile"
                className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium ${
                  location.pathname === '/profile'
                    ? 'bg-blue-800 text-white'
                    : 'text-gray-300 hover:bg-blue-800 hover:text-white'
                }`}
              >
                <Building2 size={18} />
                <span>Profile</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}