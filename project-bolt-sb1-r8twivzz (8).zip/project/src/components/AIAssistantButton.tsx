import React, { useState } from 'react';
import { Brain } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useSubscription } from '../hooks/useSubscription';
import { SubscriptionModal } from './SubscriptionModal';
import type { Profile } from '../types';

interface AIAssistantButtonProps {
  profile: Profile;
}

export function AIAssistantButton({ profile }: AIAssistantButtonProps) {
  const navigate = useNavigate();
  const { showUpgradeModal, hideUpgradeModal, isModalOpen, modalFeature, modalRequiredTier } = useSubscription();
  const [isHovered, setIsHovered] = useState(false);

  const handleClick = () => {
    if (profile.subscriptionTier !== 'elite') {
      showUpgradeModal('AI Assistant', 'elite');
      return;
    }
    navigate('/ai-assistant');
  };

  return (
    <>
      <button
        onClick={handleClick}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className="fixed bottom-6 right-6 flex items-center gap-2 px-4 py-3 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-full shadow-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
      >
        <Brain className={`w-5 h-5 ${isHovered ? 'animate-pulse' : ''}`} />
        {isHovered && (
          <span className="max-w-0 overflow-hidden whitespace-nowrap transition-all duration-200 group-hover:max-w-xs">
            AI Assistant
          </span>
        )}
      </button>

      <SubscriptionModal
        isOpen={isModalOpen}
        onClose={hideUpgradeModal}
        feature={modalFeature}
        requiredTier={modalRequiredTier}
      />
    </>
  );
}