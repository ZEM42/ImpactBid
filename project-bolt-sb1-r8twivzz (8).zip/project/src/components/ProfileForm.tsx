import React, { useState, useRef } from 'react';
import { Save, Upload, X } from 'lucide-react';
import type { Profile } from '../types';
import { useSubscription } from '../hooks/useSubscription';
import { SubscriptionModal } from './SubscriptionModal';
import { analyzeImageColors } from '../utils/colorAnalysis';

interface ProfileFormProps {
  onSave: (profile: Profile) => void;
  initialProfile?: Profile;
}

export function ProfileForm({ onSave, initialProfile }: ProfileFormProps) {
  const { showUpgradeModal, hideUpgradeModal, isModalOpen, modalFeature, modalRequiredTier, checkFeatureAccess } = useSubscription();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [profile, setProfile] = useState<Profile>({
    businessName: '',
    logo: null,
    businessAddress: '',
    licenseNumber: '',
    taxRate: 0,
    defaultShowScopePrices: false,
    defaultShowTaskPrices: false,
    email: '',
    website: '',
    primaryColor: '#1A365D',
    secondaryColor: '#4A5568',
    name: '',
    contracts: [],
    showBanners: true,
    subscriptionTier: 'free',
    ...initialProfile,
  });

  const handleLogoClick = () => {
    if (!checkFeatureAccess('Custom Logo', 'pro', profile.subscriptionTier)) {
      showUpgradeModal('Custom Logo', 'pro');
      return;
    }
    fileInputRef.current?.click();
  };

  const handleBannerToggle = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!checkFeatureAccess('Colored Banners', 'pro', profile.subscriptionTier)) {
      showUpgradeModal('Colored Banners', 'pro');
      return;
    }
    setProfile({ ...profile, showBanners: e.target.checked });
  };

  const handleLogoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.match(/^image\/(jpeg|png)$/)) {
      alert('Please select a JPEG or PNG image file.');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = async (event) => {
      if (event.target?.result) {
        const img = new Image();
        img.onload = async () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          const maxWidth = 800;
          const maxHeight = 400;
          
          if (width > maxWidth || height > maxHeight) {
            const ratio = Math.min(maxWidth / width, maxHeight / height);
            width *= ratio;
            height *= ratio;
          }
          
          canvas.width = width;
          canvas.height = height;
          
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          
          const resizedImage = canvas.toDataURL('image/png');

          try {
            // Analyze colors from the resized image
            const [primaryColor, secondaryColor] = await analyzeImageColors(resizedImage);
            
            setProfile(prev => ({
              ...prev,
              logo: resizedImage,
              primaryColor,
              secondaryColor
            }));
          } catch (error) {
            console.error('Error analyzing colors:', error);
            // Still set the logo even if color analysis fails
            setProfile(prev => ({
              ...prev,
              logo: resizedImage
            }));
          }
        };
        img.src = event.target.result as string;
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(profile);
  };

  return (
    <>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-2 gap-8">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Business Logo
            </label>
            <div className="space-y-4">
              {profile.logo ? (
                <div className="relative w-48 h-48">
                  <img
                    src={profile.logo}
                    alt="Business Logo"
                    className={`w-full h-full object-contain rounded-lg border border-gray-200 ${
                      profile.subscriptionTier === 'free' ? 'opacity-50' : ''
                    }`}
                  />
                  {profile.subscriptionTier === 'free' && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-sm text-gray-500">Pro feature</span>
                    </div>
                  )}
                  {profile.subscriptionTier !== 'free' && (
                    <button
                      type="button"
                      onClick={() => setProfile({ ...profile, logo: null })}
                      className="absolute -top-2 -right-2 p-1 bg-red-100 rounded-full text-red-600 hover:bg-red-200"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ) : (
                <div
                  onClick={handleLogoClick}
                  className={`w-48 h-48 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center ${
                    profile.subscriptionTier !== 'free' ? 'cursor-pointer hover:border-blue-500' : 'opacity-50'
                  } transition-colors`}
                >
                  <Upload className="w-8 h-8 text-gray-400" />
                  <span className="mt-2 text-sm text-gray-500">
                    {profile.subscriptionTier === 'free' ? 'Pro feature' : 'Click to upload logo'}
                  </span>
                  {profile.subscriptionTier !== 'free' && (
                    <span className="mt-1 text-xs text-gray-400">JPEG or PNG only</span>
                  )}
                </div>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png"
                onChange={handleLogoChange}
                className="hidden"
                disabled={profile.subscriptionTier === 'free'}
              />
            </div>
          </div>

          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-4">Document Appearance</h3>
            <div className="space-y-6">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="showBanners"
                  checked={profile.showBanners}
                  onChange={handleBannerToggle}
                  disabled={profile.subscriptionTier === 'free'}
                  className="h-4 w-4 text-blue-900 focus:ring-blue-500 border-gray-300 rounded disabled:opacity-50"
                />
                <label 
                  htmlFor="showBanners" 
                  className={`ml-2 block text-sm ${
                    profile.subscriptionTier === 'free' ? 'text-gray-400' : 'text-gray-700'
                  }`}
                >
                  Show colored banners on documents
                  {profile.subscriptionTier === 'free' && (
                    <span className="ml-2 text-xs text-gray-400">(Pro feature)</span>
                  )}
                </label>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Primary Color
                  </label>
                  <div className="flex items-center space-x-2">
                    <input
                      type="color"
                      value={profile.primaryColor}
                      onChange={(e) => setProfile({ ...profile, primaryColor: e.target.value })}
                      className="h-10 w-20 p-1 rounded border border-gray-300"
                      disabled={profile.subscriptionTier === 'free' || !profile.showBanners}
                    />
                    <span className="text-sm text-gray-600">{profile.primaryColor}</span>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Secondary Color
                  </label>
                  <div className="flex items-center space-x-2">
                    <input
                      type="color"
                      value={profile.secondaryColor}
                      onChange={(e) => setProfile({ ...profile, secondaryColor: e.target.value })}
                      className="h-10 w-20 p-1 rounded border border-gray-300"
                      disabled={profile.subscriptionTier === 'free' || !profile.showBanners}
                    />
                    <span className="text-sm text-gray-600">{profile.secondaryColor}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Rest of the form fields */}
        <div className="mt-4">
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">
            Your Name
          </label>
          <input
            type="text"
            id="name"
            value={profile.name}
            onChange={(e) => setProfile({ ...profile, name: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
            placeholder="Enter your full name"
          />
        </div>

        <div className="mt-4">
          <label htmlFor="businessName" className="block text-sm font-medium text-gray-700">
            Business Name
          </label>
          <input
            type="text"
            id="businessName"
            value={profile.businessName}
            onChange={(e) => setProfile({ ...profile, businessName: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          />
        </div>

        <div className="mt-4">
          <label htmlFor="businessAddress" className="block text-sm font-medium text-gray-700">
            Business Address
          </label>
          <textarea
            id="businessAddress"
            value={profile.businessAddress}
            onChange={(e) => setProfile({ ...profile, businessAddress: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            rows={3}
            required
          />
        </div>

        <div className="mt-4 grid grid-cols-2 gap-4">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">
              Email Address
            </label>
            <input
              type="email"
              id="email"
              value={profile.email}
              onChange={(e) => setProfile({ ...profile, email: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label htmlFor="website" className="block text-sm font-medium text-gray-700">
              Website
            </label>
            <input
              type="text"
              id="website"
              value={profile.website}
              onChange={(e) => setProfile({ ...profile, website: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              placeholder="www.example.com"
            />
          </div>
        </div>

        <div className="mt-4">
          <label htmlFor="licenseNumber" className="block text-sm font-medium text-gray-700">
            License Number
          </label>
          <input
            type="text"
            id="licenseNumber"
            value={profile.licenseNumber}
            onChange={(e) => setProfile({ ...profile, licenseNumber: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          />
        </div>

        <div className="mt-4">
          <label htmlFor="taxRate" className="block text-sm font-medium text-gray-700">
            Default Tax Rate (%)
          </label>
          <input
            type="number"
            id="taxRate"
            value={profile.taxRate || ''}
            onChange={(e) => {
              const value = e.target.value;
              if (value === '') {
                setProfile({ ...profile, taxRate: 0 });
                return;
              }
              
              const numValue = parseFloat(value);
              if (!isNaN(numValue)) {
                setProfile({ ...profile, taxRate: numValue });
              }
            }}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            min="0"
            max="100"
            step="0.1"
            required
          />
        </div>

        <div className="mt-6 space-y-4">
          <div className="flex items-center">
            <input
              type="checkbox"
              id="defaultShowScopePrices"
              checked={profile.defaultShowScopePrices}
              onChange={(e) => {
                const showScopePrices = e.target.checked;
                setProfile({
                  ...profile,
                  defaultShowScopePrices: showScopePrices,
                  defaultShowTaskPrices: showScopePrices ? profile.defaultShowTaskPrices : false
                });
              }}
              className="h-4 w-4 text-blue-900 focus:ring-blue-500 border-gray-300 rounded"
            />
            <label htmlFor="defaultShowScopePrices" className="ml-2 block text-sm text-gray-700">
              Show scope price breakdowns by default
            </label>
          </div>

          <div className="flex items-center ml-6">
            <input
              type="checkbox"
              id="defaultShowTaskPrices"
              checked={profile.defaultShowTaskPrices}
              disabled={!profile.defaultShowScopePrices}
              onChange={(e) => setProfile({ ...profile, defaultShowTaskPrices: e.target.checked })}
              className="h-4 w-4 text-blue-900 focus:ring-blue-500 border-gray-300 rounded disabled:opacity-50"
            />
            <label
              htmlFor="defaultShowTaskPrices"
              className={`ml-2 block text-sm ${profile.defaultShowScopePrices ? 'text-gray-700' : 'text-gray-400'}`}
            >
              Show individual task prices by default
            </label>
          </div>
        </div>

        <button
          type="submit"
          className="flex items-center justify-center w-full px-4 py-2 text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          <Save className="w-4 h-4 mr-2" />
          Save Profile
        </button>
      </form>

      <SubscriptionModal
        isOpen={isModalOpen}
        onClose={hideUpgradeModal}
        feature={modalFeature}
        requiredTier={modalRequiredTier}
      />
    </>
  );
}