import React from 'react';
import type { Invoice } from '../../../types';

interface ClientSectionProps {
  invoice: Omit<Invoice, 'id' | 'createdAt'>;
  setInvoice: React.Dispatch<React.SetStateAction<Omit<Invoice, 'id' | 'createdAt'>>>;
}

export function ClientSection({ invoice, setInvoice }: ClientSectionProps) {
  return (
    <div className="space-y-4">
      <div>
        <label htmlFor="clientName" className="block text-sm font-medium text-gray-700">
          Client Name
        </label>
        <input
          type="text"
          id="clientName"
          value={invoice.clientName}
          onChange={(e) => setInvoice({ ...invoice, clientName: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          required
        />
      </div>

      <div>
        <label htmlFor="clientAddress" className="block text-sm font-medium text-gray-700">
          Client Address
        </label>
        <textarea
          id="clientAddress"
          value={invoice.clientAddress}
          onChange={(e) => setInvoice({ ...invoice, clientAddress: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          rows={3}
          required
        />
      </div>

      <div>
        <label htmlFor="projectDescription" className="block text-sm font-medium text-gray-700">
          Project Description
        </label>
        <textarea
          id="projectDescription"
          value={invoice.projectDescription}
          onChange={(e) => setInvoice({ ...invoice, projectDescription: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          rows={3}
          required
        />
      </div>
    </div>
  );
}