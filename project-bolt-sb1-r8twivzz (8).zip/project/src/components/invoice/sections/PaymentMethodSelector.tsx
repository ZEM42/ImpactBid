import React from 'react';
import type { Payment } from '../../../types';

interface PaymentMethodSelectorProps {
  payment: Payment;
  onUpdate: (updates: Partial<Payment>) => void;
}

export function PaymentMethodSelector({ payment, onUpdate }: PaymentMethodSelectorProps) {
  if (payment.status !== 'paid') return null;

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">
        Payment Method
      </label>
      <div className="space-y-2">
        {(['check', 'cash', 'bank_transfer', 'card', 'other'] as const).map((method) => (
          <label key={method} className="flex items-center">
            <input
              type="radio"
              checked={payment.paymentMethod?.type === method}
              onChange={() => onUpdate({
                paymentMethod: { type: method }
              })}
              className="h-4 w-4 text-blue-900 focus:ring-blue-500 border-gray-300"
            />
            <span className="ml-2 text-sm text-gray-700 capitalize">
              {method.replace('_', ' ')}
            </span>
          </label>
        ))}
      </div>

      {payment.paymentMethod?.type === 'other' && (
        <input
          type="text"
          value={payment.paymentMethod.otherDescription || ''}
          onChange={(e) => onUpdate({
            paymentMethod: {
              type: 'other',
              otherDescription: e.target.value
            }
          })}
          placeholder="Specify payment method"
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
      )}
    </div>
  );
}