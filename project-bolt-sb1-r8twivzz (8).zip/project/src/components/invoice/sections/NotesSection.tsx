import React from 'react';
import type { Invoice } from '../../../types';

interface NotesSectionProps {
  invoice: Omit<Invoice, 'id' | 'createdAt'>;
  setInvoice: React.Dispatch<React.SetStateAction<Omit<Invoice, 'id' | 'createdAt'>>>;
}

export function NotesSection({ invoice, setInvoice }: NotesSectionProps) {
  return (
    <div>
      <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
        Notes
      </label>
      <textarea
        id="notes"
        value={invoice.notes}
        onChange={(e) => setInvoice({ ...invoice, notes: e.target.value })}
        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        rows={4}
      />
    </div>
  );
}