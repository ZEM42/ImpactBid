import React from 'react';
import { CheckCircle2, Clock, AlertCircle } from 'lucide-react';
import type { Payment } from '../../../types';

interface PaymentStatusSelectorProps {
  payment: Payment;
  onUpdate: (updates: Partial<Payment>) => void;
}

export function PaymentStatusSelector({ payment, onUpdate }: PaymentStatusSelectorProps) {
  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700 mb-2">
        Payment Status
      </label>
      <div className="flex flex-col gap-2">
        <button
          type="button"
          onClick={() => onUpdate({ status: 'paid' })}
          className={`flex items-center px-3 py-2 rounded-md text-sm ${
            payment.status === 'paid'
              ? 'bg-green-100 text-green-800 ring-2 ring-green-600'
              : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
          }`}
        >
          <CheckCircle2 className={`w-4 h-4 ${payment.status === 'paid' ? 'text-green-600' : 'text-gray-400'} mr-2`} />
          Paid
        </button>
        
        <button
          type="button"
          onClick={() => onUpdate({ status: 'due' })}
          className={`flex items-center px-3 py-2 rounded-md text-sm ${
            payment.status === 'due'
              ? 'bg-red-100 text-red-800 ring-2 ring-red-600'
              : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
          }`}
        >
          <AlertCircle className={`w-4 h-4 ${payment.status === 'due' ? 'text-red-600' : 'text-gray-400'} mr-2`} />
          Due Now
        </button>
        
        <button
          type="button"
          onClick={() => onUpdate({ status: 'upcoming' })}
          className={`flex items-center px-3 py-2 rounded-md text-sm ${
            payment.status === 'upcoming'
              ? 'bg-blue-100 text-blue-800 ring-2 ring-blue-600'
              : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
          }`}
        >
          <Clock className={`w-4 h-4 ${payment.status === 'upcoming' ? 'text-blue-600' : 'text-gray-400'} mr-2`} />
          Upcoming
        </button>
      </div>
    </div>
  );
}