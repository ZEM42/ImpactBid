import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import type { ChangeOrder, Profile } from '../../../types';
import { addPageStripes } from '../common/stripes';
import { addHeader } from '../common/sections/header';
import { formatCurrency } from '../common/formatting';
import { addWatermark } from '../common/watermark';

export async function generateChangeOrderPdf(changeOrder: ChangeOrder, profile: Profile, doc?: jsPDF) {
  // Only elite tier can generate change orders
  if (profile.subscriptionTier !== 'elite') {
    throw new Error('Change orders are only available with the Elite plan');
  }

  const pdfDoc = doc || new jsPDF({
    unit: 'mm',
    format: 'a4',
    putOnlyUsedFonts: true,
    floatPrecision: 16
  });

  const pageWidth = pdfDoc.internal.pageSize.getWidth();
  const margin = 20;
  const rightColumnX = pageWidth - margin - 80;
  let yPos = margin + 12;

  // Add header with logo and company info
  yPos = await addHeader(pdfDoc, profile, margin, rightColumnX, yPos);

  // Add separator line
  pdfDoc.setDrawColor(100);
  pdfDoc.setLineWidth(0.5);
  pdfDoc.line(margin, yPos, pageWidth - margin, yPos);
  yPos += 10;

  // Add change order title and number
  pdfDoc.setFontSize(24);
  pdfDoc.setFont('helvetica', 'bold');
  pdfDoc.text('CHANGE ORDER', margin, yPos);
  
  pdfDoc.setFontSize(10);
  pdfDoc.setFont('helvetica', 'normal');
  pdfDoc.text(`Change Order #: ${changeOrder.id.slice(-4)}`, margin, yPos + 10);
  pdfDoc.text(`Date: ${new Date(changeOrder.createdAt).toLocaleDateString()}`, margin, yPos + 15);

  // Add client information
  pdfDoc.setFontSize(11);
  pdfDoc.setFont('helvetica', 'bold');
  pdfDoc.text('CLIENT:', rightColumnX, yPos);
  
  pdfDoc.setFontSize(10);
  pdfDoc.setFont('helvetica', 'normal');
  pdfDoc.text(changeOrder.clientName, rightColumnX, yPos + 10);
  
  let clientYPos = yPos + 15;
  const clientAddressLines = changeOrder.clientAddress.split('\n');
  clientAddressLines.forEach(line => {
    pdfDoc.text(line.trim(), rightColumnX, clientYPos);
    clientYPos += 5;
  });

  yPos = Math.max(clientYPos + 8, yPos + 25);

  // Add separator line
  pdfDoc.setDrawColor(100);
  pdfDoc.setLineWidth(0.5);
  pdfDoc.line(margin, yPos, pageWidth - margin, yPos);
  yPos += 8;

  // Add change order description
  pdfDoc.setFontSize(11);
  pdfDoc.setFont('helvetica', 'bold');
  pdfDoc.text('DESCRIPTION OF CHANGES', margin, yPos);
  yPos += 7;
  
  pdfDoc.setFontSize(10);
  pdfDoc.setFont('helvetica', 'normal');
  const splitDescription = pdfDoc.splitTextToSize(changeOrder.projectDescription, pageWidth - (2 * margin));
  pdfDoc.text(splitDescription, margin, yPos);
  yPos += (splitDescription.length * 5) + 8;

  // Add scope of work
  pdfDoc.setFontSize(11);
  pdfDoc.setFont('helvetica', 'bold');
  pdfDoc.text('SCOPE OF WORK', margin, yPos);
  yPos += 7;

  // Process each scope
  for (const scope of changeOrder.lineItems) {
    pdfDoc.setFontSize(10);
    pdfDoc.setFont('helvetica', 'bold');
    pdfDoc.text(scope.scopeName, margin, yPos);
    yPos += 5;
    
    pdfDoc.setFont('helvetica', 'normal');
    
    for (const task of scope.tasks) {
      const taskText = `• ${task.description}`;
      const splitTask = pdfDoc.splitTextToSize(taskText, pageWidth - (2 * margin) - (scope.showTaskPrices ? 30 : 0));
      
      pdfDoc.text(splitTask, margin + 5, yPos);
      
      if (scope.showTaskPrices && task.price !== null) {
        pdfDoc.text(formatCurrency(task.price), pageWidth - margin - 5, yPos, { align: 'right' });
      }
      
      yPos += (splitTask.length * 5) + 2;
    }

    if (scope.showPrices) {
      const total = scope.overridePrice ?? scope.tasks.reduce((sum, task) => sum + (task.price || 0), 0);
      pdfDoc.setFont('helvetica', 'bold');
      pdfDoc.text(formatCurrency(total), pageWidth - margin - 5, yPos, { align: 'right' });
      yPos += 5;
    }

    yPos += 6;
  }

  // Calculate totals
  const subtotal = changeOrder.lineItems.reduce((sum, item) => {
    return sum + (item.overridePrice ?? item.tasks.reduce((taskSum, task) => taskSum + (task.price || 0), 0));
  }, 0);
  
  const tax = changeOrder.applyTax ? subtotal * (profile.taxRate / 100) : 0;
  const total = subtotal + tax;

  // Add totals
  const totalsX = pageWidth - margin - 80;
  pdfDoc.setFontSize(10);
  
  pdfDoc.setFont('helvetica', 'normal');
  pdfDoc.text('Subtotal:', totalsX, yPos);
  pdfDoc.text(formatCurrency(subtotal), pageWidth - margin, yPos, { align: 'right' });
  yPos += 6;

  if (changeOrder.applyTax) {
    pdfDoc.text(`Tax (${profile.taxRate}%):`, totalsX, yPos);
    pdfDoc.text(formatCurrency(tax), pageWidth - margin, yPos, { align: 'right' });
    yPos += 6;
  }

  pdfDoc.setFont('helvetica', 'bold');
  pdfDoc.text('Total Change Order Amount:', totalsX, yPos);
  pdfDoc.text(
    `${formatCurrency(total)}${changeOrder.paymentStatus === 'paid' ? ' (Paid)' : ''}`, 
    pageWidth - margin, 
    yPos, 
    { align: 'right' }
  );
  yPos += 15;

  // Add Amount Due if status is 'due'
  if (changeOrder.paymentStatus === 'due') {
    pdfDoc.setFontSize(20);
    pdfDoc.setFont('helvetica', 'bold');
    pdfDoc.text('Amount Due:', totalsX, yPos);
    pdfDoc.text(formatCurrency(total), pageWidth - margin, yPos, { align: 'right' });
    yPos += 15;
  }

  // Add notes if any
  if (changeOrder.notes) {
    pdfDoc.setFontSize(11);
    pdfDoc.setFont('helvetica', 'bold');
    pdfDoc.text('NOTES', margin, yPos);
    yPos += 7;

    pdfDoc.setFontSize(10);
    pdfDoc.setFont('helvetica', 'normal');
    const splitNotes = pdfDoc.splitTextToSize(changeOrder.notes, pageWidth - (2 * margin));
    pdfDoc.text(splitNotes, margin, yPos);
    yPos += (splitNotes.length * 5) + 8;
  }

  // Add signature lines if enabled
  if (changeOrder.showClientSignature || changeOrder.showMySignature) {
    yPos += 20;
    
    if (changeOrder.showClientSignature) {
      pdfDoc.setDrawColor(100);
      pdfDoc.line(margin, yPos, margin + 80, yPos);
      yPos += 5;
      pdfDoc.setFontSize(10);
      pdfDoc.setFont('helvetica', 'normal');
      pdfDoc.text('Client Signature', margin, yPos);
      yPos += 5;
      pdfDoc.setFont('helvetica', 'italic');
      pdfDoc.text(changeOrder.clientName, margin, yPos);
      yPos += 20;
    }

    if (changeOrder.showMySignature) {
      pdfDoc.setDrawColor(100);
      pdfDoc.line(margin, yPos, margin + 80, yPos);
      yPos += 5;
      pdfDoc.setFontSize(10);
      pdfDoc.setFont('helvetica', 'normal');
      pdfDoc.text('Contractor Signature', margin, yPos);
      yPos += 5;
      pdfDoc.setFont('helvetica', 'italic');
      pdfDoc.text(profile.name, margin, yPos);
    }
  }

  // Add page stripes with profile preference
  const shouldShowBanners = profile.showBanners;
  addPageStripes(pdfDoc, profile.primaryColor, profile.secondaryColor, shouldShowBanners);

  // Save if not in preview mode
  if (!doc) {
    pdfDoc.save(`change-order-${changeOrder.id.slice(-4)}.pdf`);
  }

  return pdfDoc;
}