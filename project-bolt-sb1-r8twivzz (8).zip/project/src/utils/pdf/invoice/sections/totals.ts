import type { jsPDF } from 'jspdf';
import type { Invoice, Profile } from '../../../../types';
import { formatCurrency } from '../../common/formatting';

export function addTotals(
  doc: jsPDF,
  invoice: Invoice,
  profile: Profile,
  subtotal: number,
  margin: number,
  startY: number
): number {
  let yPos = startY;
  const pageWidth = doc.internal.pageSize.getWidth();
  const totalsX = pageWidth - margin - 80;

  const tax = invoice.applyTax ? subtotal * (profile.taxRate / 100) : 0;
  const total = subtotal + tax;

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  
  doc.text('Subtotal:', totalsX, yPos);
  doc.text(formatCurrency(subtotal), pageWidth - margin, yPos, { align: 'right' });
  yPos += 5;

  if (invoice.applyTax) {
    doc.text(`Tax (${profile.taxRate}%):`, totalsX, yPos);
    doc.text(formatCurrency(tax), pageWidth - margin, yPos, { align: 'right' });
    yPos += 5;
  }

  doc.setFont('helvetica', 'bold');
  doc.text('Total:', totalsX, yPos);
  doc.text(formatCurrency(total), pageWidth - margin, yPos, { align: 'right' });
  yPos += 8;

  return yPos;
}