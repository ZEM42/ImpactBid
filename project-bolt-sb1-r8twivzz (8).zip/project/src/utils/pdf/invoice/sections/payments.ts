import jsPDF from 'jspdf';
import 'jspdf-autotable';
import type { Invoice, ChangeOrder } from '../../../../types';
import { formatCurrency } from '../../common/formatting';

export function addPaymentInfo(
  doc: jsPDF,
  invoice: Invoice,
  changeOrders: ChangeOrder[],
  total: number,
  margin: number,
  startY: number
): number {
  let yPos = startY - 2;
  const pageWidth = doc.internal.pageSize.getWidth();

  // Add separator line before the tables
  doc.setDrawColor(100);
  doc.setLineWidth(0.5);
  doc.line(margin, yPos, pageWidth - margin, yPos);
  yPos += 6;

  // Add Payment Summary title at the top
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('PAYMENT SUMMARY', margin, yPos);
  yPos += 6;

  // Calculate payment totals
  let totalPaid = 0;
  let totalDue = 0;
  let totalUpcoming = 0;

  invoice.payments.forEach(payment => {
    const amount = payment.amount || (payment.percentage ? (total * payment.percentage / 100) : 0);
    if (payment.status === 'paid') totalPaid += amount;
    if (payment.status === 'due') totalDue += amount;
    if (payment.status === 'upcoming') totalUpcoming += amount;
  });

  changeOrders.forEach(co => {
    const coTotal = co.lineItems.reduce((sum, item) => {
      return sum + (item.overridePrice ?? item.tasks.reduce((taskSum, task) => taskSum + (task.price || 0), 0));
    }, 0);
    const coFinalTotal = coTotal + (co.applyTax ? coTotal * 0.089 : 0);
    
    if (co.paymentStatus === 'paid') totalPaid += coFinalTotal;
    if (co.paymentStatus === 'due') totalDue += coFinalTotal;
    if (co.paymentStatus === 'upcoming') totalUpcoming += coFinalTotal;
  });

  // Add payment schedule table
  const paymentData = invoice.payments.map(payment => {
    const amount = payment.amount || (payment.percentage ? (total * payment.percentage / 100) : 0);
    let status = '';
    
    if (payment.status === 'paid') {
      status = `Paid ${payment.paidDate ? new Date(payment.paidDate).toLocaleDateString() : ''}`;
      if (payment.paymentMethod) {
        status += ` via ${payment.paymentMethod.type === 'other' 
          ? payment.paymentMethod.otherDescription 
          : payment.paymentMethod.type.replace('_', ' ')}`;
      }
    } else if (payment.status === 'due') {
      status = payment.includeDueDate && payment.dueDate 
        ? `Due ${new Date(payment.dueDate).toLocaleDateString()}`
        : 'Due Upon Receipt';
    } else {
      status = payment.includeDueDate && payment.dueDate 
        ? `Upcoming ${new Date(payment.dueDate).toLocaleDateString()}`
        : 'Upcoming';
    }

    const percentageText = payment.percentage ? `(${payment.percentage}%)` : '';
    const label = payment.percentage ? `${payment.label} ${percentageText}` : payment.label;

    return [label, formatCurrency(amount), status];
  });

  if (paymentData.length > 0) {
    (doc as any).autoTable({
      startY: yPos,
      body: paymentData,
      showHead: false,
      styles: {
        fontSize: 10,
        cellPadding: { top: 1, right: 6, bottom: 1, left: 6 },
        lineWidth: 0,
        textColor: [0, 0, 0],
        minCellHeight: 0
      },
      columnStyles: {
        0: { cellWidth: 80 }, // Increased width to accommodate percentage
        1: { cellWidth: 40, halign: 'right' },
        2: { cellWidth: 60, halign: 'right' }
      },
      theme: 'plain'
    });

    yPos = (doc as any).lastAutoTable.finalY;
  }

  // Add change order table
  const changeOrderData = changeOrders
    .filter(co => co.invoiceId === invoice.id)
    .map(co => {
      const coTotal = co.lineItems.reduce((sum, item) => {
        return sum + (item.overridePrice ?? item.tasks.reduce((taskSum, task) => taskSum + (task.price || 0), 0));
      }, 0);
      const coFinalTotal = coTotal + (co.applyTax ? coTotal * 0.089 : 0);

      return [
        `Change Order #${co.id.slice(-4)}`,
        formatCurrency(coFinalTotal),
        co.paymentStatus === 'paid' ? 'Paid' : 
        co.paymentStatus === 'due' ? 'Due Upon Receipt' : 
        'Upcoming'
      ];
    });

  if (changeOrderData.length > 0) {
    // Add thin grey separator line
    doc.setDrawColor(200, 200, 200);
    doc.setLineWidth(0.2);
    doc.line(margin, yPos + 2, pageWidth - margin, yPos + 2);

    (doc as any).autoTable({
      startY: yPos + 4,
      body: changeOrderData,
      showHead: false,
      styles: {
        fontSize: 10,
        cellPadding: { top: 1, right: 6, bottom: 1, left: 6 },
        lineWidth: 0,
        textColor: [0, 0, 0],
        minCellHeight: 0
      },
      columnStyles: {
        0: { cellWidth: 80 }, // Match width with payment table
        1: { cellWidth: 40, halign: 'right' },
        2: { cellWidth: 60, halign: 'right' }
      },
      theme: 'plain'
    });

    yPos = (doc as any).lastAutoTable.finalY + 4;
  }

  // Add dividing line before summary table
  doc.setDrawColor(100);
  doc.setLineWidth(0.5);
  doc.line(margin, yPos + 4, pageWidth - margin, yPos + 4);
  yPos += 8;

  // Add summary table with right alignment and larger font for Amount Due
  const summaryTableWidth = 120;
  const summaryTableMargin = pageWidth - margin - summaryTableWidth;
  const summaryData = [];
  
  if (totalPaid > 0) {
    summaryData.push(['Amount Paid', formatCurrency(totalPaid)]);
  }
  if (totalUpcoming > 0) {
    summaryData.push(['Remaining Payments', formatCurrency(totalUpcoming)]);
  }
  if (totalDue > 0) {
    summaryData.push(['Amount Due', formatCurrency(totalDue)]);
  }

  if (summaryData.length > 0) {
    (doc as any).autoTable({
      startY: yPos,
      margin: { left: summaryTableMargin, right: margin },
      body: summaryData,
      showHead: false,
      styles: {
        fontSize: 10,
        cellPadding: { top: 0, right: 4, bottom: 0, left: 4 }, // Reduced padding
        lineWidth: 0,
        textColor: [0, 0, 0],
        minCellHeight: 0,
        fontStyle: 'normal'
      },
      columnStyles: {
        0: { cellWidth: 70 },
        1: { cellWidth: 50, halign: 'right' }
      },
      didParseCell: function(data: any) {
        if (data.row.raw[0] === 'Amount Due') {
          data.cell.styles.fontSize = 20; // Changed from 24 to 20
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.cellPadding = { top: 2, right: 4, bottom: 2, left: 4 }; // Slightly more padding for Amount Due
        }
      },
      theme: 'plain'
    });

    yPos = (doc as any).lastAutoTable.finalY + 6;
  }

  return yPos;
}