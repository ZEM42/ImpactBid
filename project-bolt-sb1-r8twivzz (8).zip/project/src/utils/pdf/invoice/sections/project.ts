import type { jsPDF } from 'jspdf';
import type { Invoice } from '../../../../types';

export function addProjectInfo(
  doc: jsPDF,
  invoice: Invoice,
  margin: number,
  startY: number
): number {
  let yPos = startY;

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('PROJECT', margin, yPos);
  yPos += 5;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const splitDescription = doc.splitTextToSize(
    invoice.projectDescription, 
    doc.internal.pageSize.getWidth() - (2 * margin)
  );
  doc.text(splitDescription, margin, yPos);
  
  return yPos + (splitDescription.length * 5) + 4;
}