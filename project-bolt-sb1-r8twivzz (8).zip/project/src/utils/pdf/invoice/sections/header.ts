import type { jsPDF } from 'jspdf';
import type { Profile } from '../../../../types';
import { processLogo } from '../../common/images';

export async function addHeader(
  doc: jsPDF,
  profile: Profile,
  margin: number,
  rightColumnX: number,
  startY: number
): Promise<number> {
  let yPos = startY - 4; // Reduced top margin
  let logoHeight = 0;

  if (profile.logo) {
    try {
      const maxLogoWidth = (doc.internal.pageSize.getWidth() - (2 * margin)) * 0.25;
      const { height } = await processLogo(doc, profile.logo, margin, yPos, maxLogoWidth);
      logoHeight = height;
    } catch (error) {
      console.error('Error processing logo:', error);
    }
  }

  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(profile.businessName, rightColumnX, yPos + 4);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  let infoYPos = yPos + 12; // Reduced spacing
  
  const addressLines = profile.businessAddress.split('\n');
  addressLines.forEach(line => {
    doc.text(line.trim(), rightColumnX, infoYPos);
    infoYPos += 4; // Reduced line spacing
  });
  
  if (profile.email) {
    doc.text(profile.email, rightColumnX, infoYPos);
    infoYPos += 4;
  }
  
  if (profile.website) {
    doc.text(profile.website, rightColumnX, infoYPos);
    infoYPos += 4;
  }
  
  doc.text(`License: ${profile.licenseNumber}`, rightColumnX, infoYPos);
  
  return Math.max(infoYPos + 6, yPos + logoHeight + 8); // Reduced bottom spacing
}