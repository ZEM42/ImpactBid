import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import type { Invoice, Profile, ChangeOrder } from '../../../types';
import { addPageStripes } from '../common/stripes';
import { addHeader } from '../common/sections/header';
import { addClientInfo } from './sections/client';
import { addProjectInfo } from './sections/project';
import { addTotals } from './sections/totals';
import { addPaymentInfo } from './sections/payments';
import { addNotes } from './sections/notes';
import { addWatermark } from '../common/watermark';

export async function generateInvoicePdf(
  invoice: Invoice, 
  profile: Profile, 
  changeOrders: ChangeOrder[] = [],
  doc?: jsPDF
) {
  const pdfDoc = doc || new jsPDF({
    unit: 'mm',
    format: 'a4',
    putOnlyUsedFonts: true,
    floatPrecision: 16
  });

  // Only show logo for pro and elite tiers
  const shouldShowLogo = profile.subscriptionTier !== 'free';
  const shouldShowBanners = profile.subscriptionTier !== 'free' && profile.showBanners;

  const pageWidth = pdfDoc.internal.pageSize.getWidth();
  const margin = 20;
  const rightColumnX = pageWidth - margin - 80;
  let yPos = margin + 8;

  // Add header with logo and company info
  yPos = await addHeader(pdfDoc, profile, margin, rightColumnX, yPos);

  // Add separator line
  pdfDoc.setDrawColor(100);
  pdfDoc.setLineWidth(0.5);
  pdfDoc.line(margin, yPos - 2, pageWidth - margin, yPos - 2);
  yPos += 4;

  // Add client information
  yPos = addClientInfo(pdfDoc, invoice, margin, rightColumnX, yPos);

  // Add second separator line
  pdfDoc.setDrawColor(100);
  pdfDoc.setLineWidth(0.5);
  pdfDoc.line(margin, yPos - 2, pageWidth - margin, yPos - 2);
  yPos += 4;

  // Add project description
  yPos = addProjectInfo(pdfDoc, invoice, margin, yPos);

  // Filter change orders for this invoice
  const invoiceChangeOrders = changeOrders?.filter(co => co.invoiceId === invoice.id) || [];

  // Calculate subtotal
  const subtotal = invoice.lineItems.reduce((sum, item) => {
    return sum + (item.overridePrice ?? item.tasks.reduce((taskSum, task) => taskSum + (task.price || 0), 0));
  }, 0);

  // Add totals
  yPos = addTotals(pdfDoc, invoice, profile, subtotal, margin, yPos);

  // Add payment information
  yPos = addPaymentInfo(
    pdfDoc, 
    invoice, 
    invoiceChangeOrders,
    subtotal + (invoice.applyTax ? subtotal * (profile.taxRate / 100) : 0), 
    margin, 
    yPos
  );

  // Add notes if any
  if (invoice.notes) {
    yPos = addNotes(pdfDoc, invoice, margin, yPos);
  }

  // Add page stripes with profile preference
  addPageStripes(pdfDoc, profile.primaryColor, profile.secondaryColor, shouldShowBanners);

  // Add watermark for free tier
  if (profile.subscriptionTier === 'free') {
    addWatermark(pdfDoc);
  }

  // Save if not in preview mode
  if (!doc) {
    pdfDoc.save(`invoice-${invoice.invoiceNumber.toLowerCase()}.pdf`);
  }

  return pdfDoc;
}