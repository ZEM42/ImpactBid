import type { jsPDF } from 'jspdf';

export function addWatermark(doc: jsPDF) {
  const pageCount = doc.internal.getNumberOfPages();
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setTextColor(200, 200, 200);
    doc.setFontSize(10);
    doc.text(
      'Built with ImpactBid',
      pageWidth / 2,
      pageHeight - 5,
      { align: 'center' }
    );
  }
}