import { AITrainingSync } from './aiTrainingSync';
import type { Profile, AITrainingData, Bid, AIConversation, AIMessage, AIConversationContext } from '../types';

interface OpenAIResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

interface AIResponse {
  role: 'assistant';
  content: string;
  bid?: Partial<Bid>;
  context?: AIConversationContext;
}

const SYSTEM_PROMPT = `
You are a professional AI assistant specialized in bid-building for trades professionals. 

## Your Responsibilities:
1. **Generate structured, detailed bids** based on user input.
2. **Analyze past bid history** to ensure consistency and fill in missing details when the user is vague.
3. **Infer project scope and structure** based on previous bids and industry standards.
4. **Suggest accurate pricing** using previous data & market insights.
5. **Ensure all relevant details are included**, such as materials, scope, payment terms.

## User Context:
- Trade: {userTrade}
- Specialties: {userSpecialties}
- Notes: {userNotes}
- Past Bids Summary:
  {pastBidSummaries}

## Task Instructions:
- Use past bid data and user preferences to infer missing details.
- Keep responses concise; if clarification is needed, ask **short, direct questions**.
- If the user starts listing items, infer project context based on historical patterns and categorize them.
- Identify project types based on descriptions and user history.
- Format responses clearly without unnecessary verbosity.
- If **missing information**, ask for a **one-line** clarification question.
`;

export class AIService {
  private apiKey: string;
  private profile: Profile;
  private systemPrompt: string;
  private trainingSync?: AITrainingSync;
  private conversationHistory: AIMessage[] = [];

  constructor(apiKey: string | undefined, profile: Profile) {
    if (!apiKey) {
      throw new Error('OpenAI API key is required. Please check your environment variables.');
    }

    this.apiKey = apiKey;
    this.profile = profile;
    this.systemPrompt = SYSTEM_PROMPT.replace("{userTrade}", profile.tradeType || "Unknown Trade")
      .replace("{userSpecialties}", profile.specialties || "No Specialties Provided")
      .replace("{userNotes}", profile.notes || "No Notes Available")
      .replace("{pastBidSummaries}", this.getPastBidSummaries(profile));
  }

  private getPastBidSummaries(profile: Profile): string {
    if (!profile.pastBids || !Array.isArray(profile.pastBids) || profile.pastBids.length === 0) {
      return "No past bid data available.";
    }
    return profile.pastBids.slice(0, 5).map(bid => `- ${bid.title}: ${bid.scope}`).join("\n");
  }

  async chat(conversation: AIMessage[]): Promise<AIResponse> {
    if (!Array.isArray(conversation)) {
      conversation = [];
    }
    this.conversationHistory = [...this.conversationHistory, ...conversation];
    
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${this.apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4-turbo",
        messages: [
          { role: "system", content: this.systemPrompt },
          ...this.conversationHistory
        ]
      })
    });

    if (!response.ok) {
      throw new Error(`AI Service Error: ${response.statusText}`);
    }
    
    const data: OpenAIResponse = await response.json();
    const aiResponse: AIResponse = {
      role: "assistant",
      content: data.choices[0].message.content,
    };
    
    this.conversationHistory.push(aiResponse);
    return aiResponse;
  }

  async sendMessage(conversation: AIMessage[] | null, message: string): Promise<AIResponse> {
    if (!Array.isArray(conversation)) {
      conversation = [];
    }
    const userMessage: AIMessage = { id: crypto.randomUUID(), role: 'user', content: message, timestamp: new Date() };
    this.conversationHistory.push(userMessage);
    return this.chat([...conversation, userMessage]);
  }
}
